<?php include "includes/db_conn.php"; 

?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Synergy</title>
<meta charset="utf-8">

<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="description" content="Unicat project">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="styles/bootstrap4/bootstrap.min.css">
<link href="plugins/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link href="plugins/colorbox/colorbox.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/owl.carousel.css">
<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/owl.theme.default.css">
<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/animate.css">
<link rel="stylesheet" type="text/css" href="styles/about.css">
<link rel="stylesheet" type="text/css" href="styles/about_responsive.css">
<style>
    .awNotices {
  position: relative;
  color: white;
  font: 400 12px Arial;
}
.awNotices a {
  padding: 8px 25px 8px 10px;
  position: absolute;
  left: 0;
  right: 0;
  opacity: 0;
  color: inherit;
  text-decoration: none;
  visibility: hidden;
  transition: opacity .6s;
  border-radius: 3px;
  text-shadow: 0 0 3px rgba(1, 1, 1, 0.3);
  line-height: 150%;
}
.li{
        color: white;
    }
.awNotices a i.fa {
  padding-right: 8px;
  margin-right: 5px;
  border-right: 1px solid rgba(255, 255, 255, 0.2);
}
.awNotices a[notice-color="orange"] {
  background-color: #ff9800;
}
.awNotices a[notice-color="red"] {
  background-color: #e51c23;
}
.awNotices a[notice-color="blue"] {
  background-color: #3f51b5;
}
.awNotices a[notice-color="green"] {
  background-color: #8bc34a;
}
.awNotices a[notice-color="dark"] {
  background-color: #414141;
}
.awNotices a.active {
  opacity: 1;
  visibility: visible;
}
.awNotices span.controller {
  position: absolute;
  cursor: pointer;
  background: transparent;
  right: 0;
  padding: 8px 10px;
  line-height: 150%;
}

</style>
</head>
<body>
<section class="awNotices">
  <a href="http://adobewordpress.com" notice-color="orange"><i class="fa fa-bell"></i>‘Tomorrowland’ Is a Box-Office Disappointment</a>
  <a notice-color="red"><i class="fa fa-heart"></i>Sunday Book Review: Shakespeare in Love</a>
  <a notice-color="blue"><i class="fa fa-desktop"></i>Overvalued in Silicon Valley, but Don’t Say ‘Tech Bubble’</a>
  <a notice-color="green"><i class="fa fa-leaf"></i>Emergency Fund Created for World Health Agency</a>
  <a notice-color="dark"><i class="fa fa-comments"></i>John Nash, Nobel Winner, Dies in Crash.</a>
</section>

<div class="super_container">

	<!-- Header -->

	<header class="header">
			
		<!-- Top Bar -->
		<div class="top_bar">
			<div class="top_bar_container" style="background-color: #cc9a5e">
				<div class="container">
					<div class="row">
						<div class="col">
							<div class="top_bar_content d-flex flex-row align-items-center justify-content-start">
								<ul class="top_bar_contact_list">
									<li><div class="question">Have any questions?</div></li>
									<li>
										<i class="fa fa-phone" aria-hidden="true"></i>
										<div>001-1234-88888</div>
									</li>
									<li>
										<i class="fa fa-envelope-o" aria-hidden="true"></i>
										<div>info.deercreative@gmail.com</div>
									</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>				
		</div>

                                    <!-- faq section -->
<br>
        <br>
        <br>
        <br>
			<div class="row feature_row">

				<!-- Feature Content -->
				<div class="col-lg-6 feature_col">
					<div class="feature_content">
						<!-- Accordions -->
						<div class="accordions">
							
							<div class="elements_accordions">
        <?php 
                $query = "select * from  faq";
                $result = mysqli_query($conn, $query);
                if(!$result){
                    die("Something went wrong".mysqli_error($conn));
                }
                while($row = mysqli_fetch_array($result)){
                    $que = $row['que'];
                    $ans = $row['ans'];
                
								echo "<div class='accordion_container'>
									<div class='accordion d-flex flex-row align-items-center'><div>$que</div></div>
									<div class='accordion_panel'>
										<p>$ans</p>
									</div>
								</div>"; }?>

							</div>

						</div>
						<!-- Accordions End -->
					</div>
				</div>

				<!-- Feature Video -->
				<div class="col-lg-6 feature_col">
					<div class="feature_video d-flex flex-column align-items-center justify-content-center">
						<div class="feature_video_background" style="background-image:url(images/video.jpg)"></div>
						<a class="vimeo feature_video_button" href="https://player.vimeo.com/video/99340873?title=0" title="OH, PORTUGAL - IN 4K - Basti Hansen - Stock Footage">
							<img src="images/play.png" alt="">
						</a>
					</div>
				</div>
			</div>

<br>
<br>
<br>
<br>
<br>


<!-- Footer -->

	<footer class="footer" style="background-color: #141313">
		<div class="footer_background" style="background-image:url(images/footer_background.png)"></div>
		<div class="container">
			<div class="row footer_row">
				<div class="col">
					<div class="footer_content">
						<div class="row">

							<div class="col-lg-3 footer_col">
					
								<!-- Footer About -->
								<div class="footer_section footer_about">
									<div class="footer_logo_container">
										<a href="#">
											<div class="footer_logo_text">S<span style="color: #d8731a">y</span>nerg<span style="color: #d8731a">y</span></div>
											<br>
											<h4 style="color: white">academy of science</h4>
										</a>
									</div>
									<div class="footer_about_text">
										<p>Lorem ipsum dolor sit ametium, consectetur adipiscing elit.</p>
									</div>
									<div class="footer_social">
										<ul>
											<li><a href="https://www.facebook.com/synergyacademyofscience/"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
											<li><a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
											<li><a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
										</ul>
									</div>
								</div>
								
							</div>

							<div class="col-lg-3 footer_col">
					
								<!-- Footer Contact -->
								<div class="footer_section footer_contact">
									<div class="footer_title" style="color: #d8731a">Contact Us</div>
									<div class="footer_contact_info">
										<ul>
											<li style="color: white">Email: Info.deercreative@gmail.com</li>
											<li style="color: white">Phone:  +(88) 111 555 666</li>
											<li style="color: white">40 Baria Sreet 133/2 New York City, United States</li>
										</ul>
									</div>
								</div>
								
							</div>

							<div class="col-lg-3 footer_col">
					
								
							</div>

							<div class="col-lg-3 footer_col clearfix">
					
								
							</div>

						</div>
					</div>
				</div>
			</div>

			<div class="row copyright_row">
				<div class="col">
					<div class="copyright d-flex flex-lg-row flex-column align-items-center justify-content-start">
						
					</div>
				</div>
			</div>
		</div>
	</footer>

<script type="text/javascript">
    $('.awNotices').append('<span class="controller fa fa-pause"></span>');
$('.awNotices a:nth-of-type(1)').addClass('active');

function awNotice() {
  if(!$('.awNotices').hasClass('stopped')){
  var $active = $('.awNotices a.active');
  var $next = $active.next('a');    
  
  if ($next.length){
  $next.addClass('active');
  $active.removeClass('active');
  }else{
    $active.removeClass('active');
		$('.awNotices a:first-of-type').addClass('active');
  }
  }
}

$('.awNotices .controller').click(function(){
  $(this).toggleClass('fa-pause fa-play');
  $('.awNotices').toggleClass('stopped');
})

function awNotices(timer){
    setInterval( "awNotice()", timer);
}

awNotices(4500);

</script>

<script src="js/jquery-3.2.1.min.js"></script>
<script src="styles/bootstrap4/popper.js"></script>
<script src="styles/bootstrap4/bootstrap.min.js"></script>
<script src="plugins/greensock/TweenMax.min.js"></script>
<script src="plugins/greensock/TimelineMax.min.js"></script>
<script src="plugins/scrollmagic/ScrollMagic.min.js"></script>
<script src="plugins/greensock/animation.gsap.min.js"></script>
<script src="plugins/greensock/ScrollToPlugin.min.js"></script>
<script src="plugins/OwlCarousel2-2.2.1/owl.carousel.js"></script>
<script src="plugins/easing/easing.js"></script>
<script src="plugins/parallax-js-master/parallax.min.js"></script>
<script src="plugins/colorbox/jquery.colorbox-min.js"></script>
<script src="js/about.js"></script>
</body>
</html>