-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 22, 2018 at 02:59 PM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 7.2.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `synergy`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `sr. no.` int(10) NOT NULL,
  `username` varchar(255) NOT NULL,
  `user_password` varchar(255) NOT NULL,
  `mobile no.` varchar(255) NOT NULL,
  `fname` varchar(255) NOT NULL,
  `lname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`sr. no.`, `username`, `user_password`, `mobile no.`, `fname`, `lname`, `email`) VALUES
(1, 'Naman', 'papAq5PwY/QQM', '1234567890', 'Naman', 'Lazarus', 'namanlazarus02@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `april`
--

CREATE TABLE `april` (
  `date` date NOT NULL,
  `event` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE `attendance` (
  `sr. no.` int(255) NOT NULL,
  `roll_no` int(255) NOT NULL,
  `date` date NOT NULL,
  `sub1` varchar(255) DEFAULT 'present',
  `sub2` varchar(255) DEFAULT 'present',
  `sub3` varchar(255) DEFAULT 'present',
  `sub4` varchar(255) DEFAULT 'present'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `attendance`
--

INSERT INTO `attendance` (`sr. no.`, `roll_no`, `date`, `sub1`, `sub2`, `sub3`, `sub4`) VALUES
(39, 6, '2018-08-15', 'absent', 'absent', 'absent', 'absent'),
(51, 8, '2018-08-22', 'present', 'present', 'present', 'present'),
(52, 8, '2018-08-14', 'present', 'present', 'present', 'present'),
(53, 26, '2018-08-14', 'present', 'present', 'present', 'present');

-- --------------------------------------------------------

--
-- Table structure for table `august`
--

CREATE TABLE `august` (
  `date` date NOT NULL,
  `event` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `batch1`
--

CREATE TABLE `batch1` (
  `rollno` varchar(255) NOT NULL,
  `sub1` int(255) NOT NULL,
  `sub2` int(255) NOT NULL,
  `sub3` int(255) NOT NULL,
  `sub4` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `batch1`
--

INSERT INTO `batch1` (`rollno`, `sub1`, `sub2`, `sub3`, `sub4`) VALUES
('1', 65, 15, 32, 24);

-- --------------------------------------------------------

--
-- Table structure for table `bio`
--

CREATE TABLE `bio` (
  `quest_id` int(11) NOT NULL,
  `quest` varchar(150) NOT NULL,
  `correct_ans` varchar(80) NOT NULL,
  `opt_1` varchar(80) NOT NULL,
  `opt_2` varchar(80) NOT NULL,
  `opt_3` varchar(80) NOT NULL,
  `opt_4` varchar(80) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bio`
--

INSERT INTO `bio` (`quest_id`, `quest`, `correct_ans`, `opt_1`, `opt_2`, `opt_3`, `opt_4`) VALUES
(1, 'gsud', '667', 'ihsido', '667', 'ashd', ';js'),
(2, 'ifcsacljc', ',jsdcb', '..svnj', ',jsdcb', 'jvd j', ' n,  hscv'),
(3, 'What is the speed of sound', '320', '585', '384', '320', '564');

-- --------------------------------------------------------

--
-- Table structure for table `bio11`
--

CREATE TABLE `bio11` (
  `quest_id` int(255) NOT NULL,
  `quest` varchar(255) NOT NULL,
  `correct_ans` varchar(255) NOT NULL,
  `opt_1` varchar(255) NOT NULL,
  `opt_2` varchar(255) NOT NULL,
  `opt_3` varchar(255) NOT NULL,
  `opt_4` varchar(255) NOT NULL,
  `chap` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bio11`
--

INSERT INTO `bio11` (`quest_id`, `quest`, `correct_ans`, `opt_1`, `opt_2`, `opt_3`, `opt_4`, `chap`) VALUES
(1, 'What is an Atom?', 'd', 'something', 'naman', 'molecule', 'something2', '1');

-- --------------------------------------------------------

--
-- Table structure for table `bio12`
--

CREATE TABLE `bio12` (
  `quest_id` int(255) NOT NULL,
  `quest` varchar(255) NOT NULL,
  `correct_ans` varchar(255) NOT NULL,
  `opt_1` varchar(255) NOT NULL,
  `opt_2` varchar(255) NOT NULL,
  `opt_3` varchar(255) NOT NULL,
  `opt_4` varchar(255) NOT NULL,
  `chap` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `chem`
--

CREATE TABLE `chem` (
  `quest_id` int(11) NOT NULL,
  `quest` varchar(150) NOT NULL,
  `correct_ans` varchar(80) NOT NULL,
  `opt_1` varchar(80) NOT NULL,
  `opt_2` varchar(80) NOT NULL,
  `opt_3` varchar(80) NOT NULL,
  `opt_4` varchar(80) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `chem11`
--

CREATE TABLE `chem11` (
  `quest_id` int(255) NOT NULL,
  `quest` varchar(255) NOT NULL,
  `correct_ans` varchar(255) NOT NULL,
  `opt_1` varchar(255) NOT NULL,
  `opt_2` varchar(255) NOT NULL,
  `opt_3` varchar(255) NOT NULL,
  `opt_4` varchar(255) NOT NULL,
  `chap` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `chem11`
--

INSERT INTO `chem11` (`quest_id`, `quest`, `correct_ans`, `opt_1`, `opt_2`, `opt_3`, `opt_4`, `chap`) VALUES
(1, 'What is the speed of sound', '4', 'frfdr', 'dd', '320', ';js', ''),
(2, 'What is the speed of sound', '4', 'frfdr', 'dd', '320', ';js', ''),
(3, 'What is the speed of sound', 'Naman', 'Naman', 'dd', '320', ';js', ''),
(4, 'What is the speed of sound', 'Naman', 'Naman', 'dd', '320', ';js', '1'),
(5, 'What is the speed of sound', 'Naman', 'Naman', 'dd', '320', ';js', '1'),
(6, 'What is the speed of sound', '4', 'i dont know', 'dd', '320', 'ghfh', '1'),
(7, 'gsud', '320', 'frfdr', '667', '320', 'opt2', '3'),
(8, 'what is atom?', 'Hi', 'Hi', 'dd', '320', ';js', '1'),
(9, 'wow', '667', 'i dont know', '667', 'opt1', 'ghfh', '1'),
(10, 'wow', '667', 'i dont know', '667', 'opt1', 'ghfh', '1'),
(11, 'wow', '667', 'i dont know', '667', 'opt1', 'ghfh', '1'),
(12, 'wow', '667', 'i dont know', '667', 'opt1', 'ghfh', '1'),
(13, 'wow', '667', 'i dont know', '667', 'opt1', 'ghfh', '1'),
(14, 'wow', '667', 'i dont know', '667', 'opt1', 'ghfh', '1'),
(15, 'wow', '667', 'i dont know', '667', 'opt1', 'ghfh', '1');

-- --------------------------------------------------------

--
-- Table structure for table `chem12`
--

CREATE TABLE `chem12` (
  `quest_id` int(255) NOT NULL,
  `quest` varchar(255) NOT NULL,
  `correct_ans` varchar(255) NOT NULL,
  `opt_1` varchar(255) NOT NULL,
  `opt_2` varchar(255) NOT NULL,
  `opt_3` varchar(255) NOT NULL,
  `opt_4` varchar(255) NOT NULL,
  `chap` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `december`
--

CREATE TABLE `december` (
  `date` date NOT NULL,
  `event` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `faq`
--

CREATE TABLE `faq` (
  `sr. no.` int(255) NOT NULL,
  `que` varchar(255) NOT NULL,
  `ans` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `faq`
--

INSERT INTO `faq` (`sr. no.`, `que`, `ans`) VALUES
(6, 'test2', 'test2');

-- --------------------------------------------------------

--
-- Table structure for table `febuary`
--

CREATE TABLE `febuary` (
  `date` date NOT NULL,
  `event` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `febuary`
--

INSERT INTO `febuary` (`date`, `event`) VALUES
('2018-01-01', 'New Year day');

-- --------------------------------------------------------

--
-- Table structure for table `january`
--

CREATE TABLE `january` (
  `date` date NOT NULL,
  `event` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `january`
--

INSERT INTO `january` (`date`, `event`) VALUES
('2018-01-01', 'New year\'s day'),
('2018-01-25', 'something'),
('2018-07-04', 'something'),
('2018-01-23', 'something'),
('2018-01-10', 'hghfh');

-- --------------------------------------------------------

--
-- Table structure for table `july`
--

CREATE TABLE `july` (
  `date` date NOT NULL,
  `event` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `june`
--

CREATE TABLE `june` (
  `date` date NOT NULL,
  `event` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `march`
--

CREATE TABLE `march` (
  `date` date NOT NULL,
  `event` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `marks`
--

CREATE TABLE `marks` (
  `sr.no.` int(255) NOT NULL,
  `roll_no` int(255) NOT NULL,
  `batch` text NOT NULL,
  `sub1` int(255) NOT NULL,
  `sub2` int(255) NOT NULL,
  `sub3` int(255) NOT NULL,
  `sub4` int(255) NOT NULL,
  `test_date` date NOT NULL,
  `test` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `marks`
--

INSERT INTO `marks` (`sr.no.`, `roll_no`, `batch`, `sub1`, `sub2`, `sub3`, `sub4`, `test_date`, `test`) VALUES
(1, 26, 'batch1', 55, 53, 65, 56, '2018-07-15', 'test2'),
(2, 26, 'batch3', 98, 95, 99, 97, '2018-07-15', 'test1'),
(3, 26, 'batch1', 15, 15, 12, 25, '2018-07-31', 'test1'),
(4, 26, 'batch1', 63, 15, 44, 25, '2018-07-16', 'test2'),
(5, 32, '', 65, 53, 74, 56, '2018-08-21', 'test1');

-- --------------------------------------------------------

--
-- Table structure for table `maths`
--

CREATE TABLE `maths` (
  `quest_id` int(11) NOT NULL,
  `quest` varchar(150) NOT NULL,
  `correct_ans` varchar(80) NOT NULL,
  `opt_1` varchar(80) NOT NULL,
  `opt_2` varchar(80) NOT NULL,
  `opt_3` varchar(80) NOT NULL,
  `opt_4` varchar(80) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `maths11`
--

CREATE TABLE `maths11` (
  `quest_id` int(255) NOT NULL,
  `quest` varchar(255) NOT NULL,
  `correct_ans` varchar(255) NOT NULL,
  `opt_1` varchar(255) NOT NULL,
  `opt_2` varchar(255) NOT NULL,
  `opt_3` varchar(255) NOT NULL,
  `opt_4` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `maths12`
--

CREATE TABLE `maths12` (
  `quest_id` int(255) NOT NULL,
  `quest` varchar(255) NOT NULL,
  `correct_ans` varchar(255) NOT NULL,
  `opt_1` varchar(255) NOT NULL,
  `opt_2` varchar(255) NOT NULL,
  `opt_3` varchar(255) NOT NULL,
  `opt_4` varchar(255) NOT NULL,
  `chap` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `may`
--

CREATE TABLE `may` (
  `date` date NOT NULL,
  `event` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `notices`
--

CREATE TABLE `notices` (
  `sr.no.` int(255) NOT NULL,
  `notice1` varchar(255) NOT NULL,
  `notice2` varchar(255) NOT NULL,
  `notice3` varchar(255) NOT NULL,
  `notice4` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notices`
--

INSERT INTO `notices` (`sr.no.`, `notice1`, `notice2`, `notice3`, `notice4`) VALUES
(1, 'notice no 1', 'notice no 2', 'notice no 3', 'notice no 4\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `november`
--

CREATE TABLE `november` (
  `date` date NOT NULL,
  `event` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `october`
--

CREATE TABLE `october` (
  `date` date NOT NULL,
  `event` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `phy`
--

CREATE TABLE `phy` (
  `quest_id` int(11) NOT NULL,
  `quest` varchar(150) NOT NULL,
  `correct_ans` varchar(80) NOT NULL,
  `opt_1` varchar(80) NOT NULL,
  `opt_2` varchar(80) NOT NULL,
  `opt_3` varchar(80) NOT NULL,
  `opt_4` varchar(80) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `phy`
--

INSERT INTO `phy` (`quest_id`, `quest`, `correct_ans`, `opt_1`, `opt_2`, `opt_3`, `opt_4`) VALUES
(1, 'What is the speed of light?', 'i still dont know', 'i dont know', 'i still dont know', 'opt1', 'opt2'),
(2, 'What is the speed of sound', 'i still dont know', 'frfdr', 'i still dont know', 'ashd', ';js'),
(3, 'What is the speed of sound', 'i still dont know', 'frfdr', 'i still dont know', 'ashd', ';js');

-- --------------------------------------------------------

--
-- Table structure for table `phy11`
--

CREATE TABLE `phy11` (
  `quest_id` int(255) NOT NULL,
  `quest` varchar(255) NOT NULL,
  `correct_ans` varchar(255) NOT NULL,
  `opt_1` varchar(255) NOT NULL,
  `opt_2` varchar(255) NOT NULL,
  `opt_3` varchar(255) NOT NULL,
  `opt_4` varchar(255) NOT NULL,
  `image` varchar(30) NOT NULL,
  `chap` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `phy11`
--

INSERT INTO `phy11` (`quest_id`, `quest`, `correct_ans`, `opt_1`, `opt_2`, `opt_3`, `opt_4`, `image`, `chap`) VALUES
(1, 'What is the speed of light?', 'Naman', 'i dont know', 'i still dont know', 'Naman', '', '', '1'),
(2, 'What is the speed of sound', 'ashd', 'Naman 2', 'i still dont know', 'ashd', '', '', '1'),
(3, 'What is the speed of sound', 'ashd', 'Naman 2', 'i still dont know', 'ashd', ';js', '', '1'),
(4, 'What is the speed of sound', 'Naman', 'Naman', 'dd', '320', ';js', '', '1'),
(5, 'What is the speed of sound', 'Naman', 'Naman', 'dd', '320', ';js', '', '1'),
(6, 'What is the speed of sound', '4', 'i dont know', 'dd', '320', 'ghfh', '', '1'),
(7, 'gsud', '320', 'frfdr', '667', '320', 'opt2', '', '3'),
(8, 'what is atom?', 'Hi', 'Hi', 'dd', '320', ';js', '', '1'),
(9, 'this for img', 'i dont know', 'i dont know', 'n,kkn,n', 'khjb', 'nmn', '', '1'),
(10, 'this for img', 'i dont know', 'i dont know', 'n,kkn,n', 'khjb', 'nmn', '', '1'),
(11, '', '', '', '', '', '', '', ''),
(12, '', '', '', '', '', '', '', ''),
(13, '', '', '', '', '', '', '', ''),
(14, '', '', '', '', '', '', '', '1'),
(15, ',cdb', 'jbcmb', 'jbcmb', 'bd,', ',,,', 'b,b', '', '1'),
(16, 'What is the speed of light?', 'i dont know', 'i dont know', 'dn', 'vm', 'dbb ', 'problem.jpeg', '1'),
(17, 'ndcb', 'frfdr', 'frfdr', 'c,dn', 'vjdsn', 'kfn', 'technology1.jpg', '1');

-- --------------------------------------------------------

--
-- Table structure for table `phy12`
--

CREATE TABLE `phy12` (
  `quest_id` int(255) NOT NULL,
  `quest` varchar(255) NOT NULL,
  `correct_ans` varchar(255) NOT NULL,
  `opt_1` varchar(255) NOT NULL,
  `opt_2` varchar(255) NOT NULL,
  `opt_3` varchar(255) NOT NULL,
  `opt_4` varchar(255) NOT NULL,
  `chap` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `quest`
--

CREATE TABLE `quest` (
  `quest_id` int(11) NOT NULL,
  `quest` varchar(150) NOT NULL,
  `correct_ans` varchar(20) NOT NULL,
  `opt_1` varchar(20) NOT NULL,
  `opt_2` varchar(20) NOT NULL,
  `opt_3` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `quest`
--

INSERT INTO `quest` (`quest_id`, `quest`, `correct_ans`, `opt_1`, `opt_2`, `opt_3`) VALUES
(1, 'What are the two binary numbers', '1 and 0', '1 and 2', '1 to 9', '1 and 0'),
(2, 'Part of main memory where it stores data temporarirly.', 'RAM', 'CPU', 'RAM', 'ROM'),
(3, 'The speed of computer is measured by', 'hertz', 'byte', 'hertz', 'bit'),
(20, 'test', 'test1', 'test1', 'test2', 'test3'),
(21, 'how is purvesh', 'very good', 'very good', 'bad', 'worst'),
(22, 'how tough was this', 'very very very much', 'very very very much', 'very very much', 'very much'),
(23, 'What is the speed of sound', '667', 'frfdr', '667', 'ashd'),
(24, 'what is my name?', 'Naizal', 'Naman', 'Naizla', 'Naizal');

-- --------------------------------------------------------

--
-- Table structure for table `september`
--

CREATE TABLE `september` (
  `date` date NOT NULL,
  `event` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `signup`
--

CREATE TABLE `signup` (
  `id` int(255) NOT NULL,
  `roll_no` varchar(255) NOT NULL,
  `fname` varchar(30) NOT NULL,
  `lname` varchar(30) NOT NULL,
  `dob` date NOT NULL,
  `father_name` varchar(30) NOT NULL,
  `mother_name` varchar(30) NOT NULL,
  `father_occ` varchar(30) NOT NULL,
  `school` varchar(255) NOT NULL,
  `school_board` varchar(10) NOT NULL,
  `present_school` varchar(255) NOT NULL,
  `present_school_board` varchar(10) NOT NULL,
  `stud_phone` varchar(10) NOT NULL,
  `par_phone` varchar(10) NOT NULL,
  `stud_email` varchar(30) NOT NULL,
  `par_email` varchar(30) NOT NULL,
  `address` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `course` varchar(20) NOT NULL,
  `class` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `signup`
--

INSERT INTO `signup` (`id`, `roll_no`, `fname`, `lname`, `dob`, `father_name`, `mother_name`, `father_occ`, `school`, `school_board`, `present_school`, `present_school_board`, `stud_phone`, `par_phone`, `stud_email`, `par_email`, `address`, `password`, `course`, `class`) VALUES
(1, '26', 'Naman', 'Lazarus', '2018-08-09', 'hho', 'jui', 'jjhkk', '				ufg			', 'ssc', '				g			', 'hsc', '9874562145', '9898745689', 'jh@gamil.com', 'jg@tv.com', '				\r\n				kugii			', '$2y$10$ydBpgWnOu3vB7t.Z8S9Mb.7qqJ7w1aIOCpTnbBw0fUOz1BMwXjSnG', 'jkk', 'ger'),
(2, '18', 'mdan', 'lvdn', '2018-12-31', 'fnedcjln', 'fldnc', 'kndc', '								ad,m v,a 						', 'cbsc', '								', 'cbse', 'kdnan', 'kndxj', 'jainpurvesh19@gmail.com', 'jainpurvesh19@gmail.com', '				\r\n								\r\n				v;dkc						', '$2y$10$aYfURJkeKClyts53P3yHr.IKdku5kgSCG9x1GSfngw76PmFh6a7X6', 'jee', '12');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `id` int(11) NOT NULL,
  `slot` varchar(10) NOT NULL,
  `V` varchar(20) NOT NULL,
  `VI` varchar(20) NOT NULL,
  `VII` varchar(20) NOT NULL,
  `VIII` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `sr. no.` int(255) NOT NULL,
  `roll_no` int(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `fname` varchar(255) NOT NULL,
  `lname` varchar(255) NOT NULL,
  `user_password` varchar(255) NOT NULL,
  `dob` date NOT NULL,
  `course` varchar(255) NOT NULL,
  `address` varchar(1000) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `doa` date NOT NULL,
  `image` longblob NOT NULL,
  `college` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`sr. no.`, `roll_no`, `username`, `fname`, `lname`, `user_password`, `dob`, `course`, `address`, `phone`, `doa`, `image`, `college`) VALUES
(1, 26, 'username', 'Naman', 'Lazarus', 'papAq5PwY/QQM', '2018-06-12', '2 years intigrated', 'some random address', '1234567890', '2018-08-08', 0xffd8ffe103084578696600004d4d002a00000008000601310002000000150000005687690004000000010000007f01120003000000010001000001010003000000010280000001320002000000140000006b01000003000000010280000000000000506963734172742050686f746f2053747564696f00323031373a31313a31332032333a33393a35340000039208000400000001000000009003000200000014000000a992860002000001d8000000bd00000000323031373a31313a31332032333a33393a3534007b22756964223a2263393164303061322d393737662d343162322d626162612d363164356531386163396630222c226674655f696d6167655f696473223a5b5d2c2272656d69785f64617461223a5b5d2c226f726967696e223a22756e6b6e6f776e222c22746f74616c5f656666656374735f74696d65223a302c22746f74616c5f656666656374735f616374696f6e73223a302c22746f74616c5f647261775f74696d65223a302c22746f74616c5f647261775f616374696f6e73223a302c226c61796572735f75736564223a302c22627275736865735f75736564223a302c22746f74616c5f656469746f725f74696d65223a302c22746f74616c5f656469746f725f616374696f6e73223a7b227371756172655f666974223a317d2c2270686f746f735f6164646564223a302c22656666656374735f6170706c696564223a302c22656666656374735f7472696564223a302c226c6f6e676974756465223a2d312c226c61746974756465223a2d312c2269735f737469636b6572223a66616c73652c226564697465645f73696e63655f6c6173745f737469636b65725f73617665223a747275652c22636f6e7461696e73465445537469636b6572223a66616c73652c22746f6f6c735f75736564223a7b7d7d0000050131000200000015000002d70112000300000001000100000101000300000001028000000132000200000014000002ec01000003000000010280000000000000506963734172742050686f746f2053747564696f00323031373a31313a31332032333a33393a353400ffe000104a46494600010100000100010000ffdb0043000302020302020303030304030304050805050404050a070706080c0a0c0c0b0a0b0b0d0e12100d0e110e0b0b1016101113141515150c0f171816141812141514ffdb00430103040405040509050509140d0b0d1414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414ffc00011080280028003012200021101031101ffc4001f0000010501010101010100000000000000000102030405060708090a0bffc400b5100002010303020403050504040000017d01020300041105122131410613516107227114328191a1082342b1c11552d1f02433627282090a161718191a25262728292a3435363738393a434445464748494a535455565758595a636465666768696a737475767778797a838485868788898a92939495969798999aa2a3a4a5a6a7a8a9aab2b3b4b5b6b7b8b9bac2c3c4c5c6c7c8c9cad2d3d4d5d6d7d8d9dae1e2e3e4e5e6e7e8e9eaf1f2f3f4f5f6f7f8f9faffc4001f0100030101010101010101010000000000000102030405060708090a0bffc400b51100020102040403040705040400010277000102031104052131061241510761711322328108144291a1b1c109233352f0156272d10a162434e125f11718191a262728292a35363738393a434445464748494a535455565758595a636465666768696a737475767778797a82838485868788898a92939495969798999aa2a3a4a5a6a7a8a9aab2b3b4b5b6b7b8b9bac2c3c4c5c6c7c8c9cad2d3d4d5d6d7d8d9dae2e3e4e5e6e7e8e9eaf2f3f4f5f6f7f8f9faffda000c03010002110311003f00fcaaa28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800af79fd967a789ffedd7ff6b578357bdfecaaa5bfe128c7fd3aff00ed6ae7c42bd27fd753bb02ed888fcff267bc29f5e952c69b8700d31976e78aea3e1cf866cbc5de224b0d435dd3fc3b669199e6bdd4a4d8a11594304fef3e092178ce0f35f3f38eecfaa7249367da7fb0d5db5f7c1c36ce4b1b3d5278941eca5227fe6c6bd27f6834b7ff00842ece36923138bc5748cb00cc0238381d4f51d2be4d83f69bf097c05f0a5ef873e18cb3ea534b7064b8d6b58dbe53bedd9986342a71f2a919f7ce6bca7c21f1bfc49e38f8d3a05e6b7a95d6a51df5cbda96b991b6c7bf76022670abb88e3b570d0a13f6bed1ec8f9cafefc9be87d1c9096e0f03daacc56f91c74a548f079ad8d0f40d435db816fa7d9cb7729c02235242f3d49e807b9af6efa9c6d595cfa77e185d2dff00c3ed05c32baada4711c74ca0da47e60d752aa1460702b92f859a0ea3e19f07db69ba9889668998a2c4c5b0ac77618fae4b74e3a575d5ecc76473095ca7c44d1ad6e3c23e23b9fb2c4f7c74bb88567d83cc0be5b1da0f5c64f4aeb2a0bcb74bbb596094068e4428ca7b823069495e2c0fcfdbb87cdd3afa12037996d2a608eb946150e837125b6a1a75d42c566fb0c1728ca70432376f7ce2bdabc0dfb3d6a5e24115fea1750d969cd23a34684b4ff2b956182b81ca91d4fd2bd8fc15f03fc25e088ad7ecba6adedd5b47e547777d892455ce78180a391d4007deb8e099a368ee6c2ee2bfb382e616df0cd1ac88c3ba91907f5ae575cf851e1ff11f8b57c41aa40f7b72b6ab682de461e415576604ae324e588e4e31dabb15ef4eaedb686455b2b1b7d36d62b5b4823b6b68942c7144a151076000e00accf04058fc396f6e8311da3c968bebb6291a319f7c28adc35c9fc3b92429e228642488758b955cf60487ff00d9a97da03ada28a2ac61451450021ae52e2d7caf8976373ff3db4a9e2ffbe6588ffecd5d59e95e43f1bbe397833e09dfe93aaf89b58b7b79024b12d82dc42b72eaf821c23bafcb9888cf4cd6153457047ae545737315a40f2cd22c51202cceed85503a924d7e7f7c4cff0082a0a0bb9adbc11a55b3423f7626bb649e62c73860a928551d3a961f5af0ad4fe35fc62f8d3e2a8347bad7ded6df54c3468677f254b3850bb15b629f9c763c7ad734f116d228da349bddd8fd468fe2bf86b52d6bfb1f47d4e0d7755d8d235ae9b3472b22a9c1663bb0a01207273961c57cedf183f6b4f16f8666d422d13c3715ac76bb91bfb4033cec41619014803a0e39af3dfd87be1b6b1e0ff8d9af5ceb9ad49a8de5b45269eb107664dac2194300700728c338f5af72f8fdf0d6deedf51d562b64f2de16924e3f880627b7e35cb5a12ab4ef3d0a8f2c2565aa3e36bafda0fc5df113c5f3e817b35d5c6a92859e2b2bb76107cc704e3760005b0140c633f376ae9fc1da3f88353d4b59b4d5ae2d2d24b199008ac119410ca083d793c119e9ed58cbe044d1fe3cd97881e441a7b69a88fb387575983f4ef950d8f7435e8d1a8b6d6755bbd2addae2e6eda262b2701517702c7e9b979cff0015702c0e19a7a5d89cddcebb5ef877a0e9561697c35436d7af024e22ba96d2646f9738f2dbcb6e4e3a6efc6bcd759d6668f5691ee110ab6d2af6f0f948ca38c851c0e87a1c57d45acfc1ed37e21fc3dd27cc26c750fb144cb25a88d034823fe26d8cc464fafa57ce3f107e18ddf813551a75db877312c9e6a49b8119619c955c7dd3dbf1af9caf4270bf2a2b991d6784e5b4d6f4692291bcfb1bc85ada75ef865c107dc827f3a97f646d725d213c65f0f2fd99a7d0f54965b4772496b7dcaaa402781901b8e3f795e61e11f1349e18d4816944d68c42c91824f7fbdd7afbd7a141abdbf847e2ef867c5b66a91699adc71e9f76f900162ea0b1edc298db39ec6bcfad53eb5877a7bf1d7eefe9974bdd6d74673df1abc177ba378bf50bf86e5a5885f8b8960738db033963b47a638e3bd72ba6f88f5587c19aa2595ef92b7177109ace32774c823772783c8c80a41cfdf15efdf1efc247c5fa8e9a34fbab7b6b8680c7219d8aa10ae463e504f53c71d01af015b75f0edc5ec5768b13da07924518dae539007a825147b8cd6f2c4cf1894a4fa2f9d9ebf97e260e366ca9a24917f6a5cdcc8eca9648ce5781b8a819fc77608fa1ae93567235cd3eeda38e19d6d11cb4673bf395cf3dcf39f7e6b8abebb6d3fc371c65043717d74b148c78254659c9e7a6770fa115bb3ea6665d3b24f202025b231b8fe9d7f5aefcbe31849a7ebf8ffc3094af729de2acfaf5b5b4ff0031ba629f2b60a9390b8f7c915d9782b4768f5cfb1b2acd76245bb9a291828018604217838553963d01c0cd723aadbc4dabd8dfbbc71af9caea85b007cfc1fd38af64f87da24f6fac5c5dcad14cd35a6d8c6fcb84253071e9f275f7aedacb965392f2febfaff8637b23a6bd9fccd067b4b75b899a5b90515c124fc98c7ea71f4159127c17bc934f9f517d42237f12199b4f009c26338cff007ba0c63f1aef741d362b6b38eeee5bf7acff00b88dc7064030a327b820e3df1562eeee5884176508132490c8470586d27047f7f83ff7c9af9e559a9b549dade9ab5d3d34e9afdcceee55b33e6bf88c6187c19786e0b2059221b414ce3701c026b2fc450e223220247d9063239e86ba7f1ae952ea161acd8bc2f7611595502eee558e180fae0d55bad06e752b5f2a38f6936e2306404007047f5afd06838c6376c3d8d49be5845b21f8480ffc224e49ff0097b93b7b2d118ff8b9ec475fb3367f315ade0ed027f0d689f6398a33991a42c84e39c7a81e9593aaf8dfc05e1bd56e6f752f13695677e13632497b1f980770137673c7a568f15057b6a77d3c9f1353756f53e4dff829a7fcd37ffb897fedad7c3d5f5b7edf9f13fc3ff112e3c151f87e79eee2d3cdfacb71240d1c6e58c18d85b96fb84e718e457c935df465cf0523c9c550786ad2a52776adf95c28a28ad8e40a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800af7ff00d93c64f8a7fedd7ff6b578057d07fb250ff91abfedd3ff006b5615ff0086cedc17f1e3f3fc99ef8532a78aa7710f991b232ee523a1ad331e54f1c54724618f1f9d78e7d3a38db9d16dd278e53190b13ab9083ae0d77bf0f341b993c77e1bb94862b6b68b58b55df33852b999082c7a0500f27eb585796dfba98ede8a48fd6bd02c618fec4f756ea15d2cadf5003fda009edfee575d38de2da3e7f19ee565e67e87785bf67fb58d96e35db9fb4386dcb6f6c71191e8c48c9fc315eafa3e8761a1da8b6d3ed21b3847f0448172718c9c753c0e4f3553c17ab7fc241e13d17553b737d650dc9d9d3e740dc7b735b6a39ad6952eacf31c9c98a9de9d483bd2d77210534d3a9a6811c67c2fbe7bab2d7eddba59eb77902fd3cc2fff00b3d7678ae3fc150c7a7f887c6164a72c7505bcc63b4b121fe6adf957623a9ace9af76c502f7a5a28ad4434d73de1e02d7c41e2583182f7115c81d321a255cfe71b574278af1ff89bf19745f837e2cbdbcd6a1beb882e34e80c71d8c22472cb24f9eac00e2b19cb96cd8257d8f611dea3b8b88ed62696591628d016677600281d4927b57c15f13bfe0a4b7969a8269fe16f0ffd9fed25a285ef63324c4f3f3603aa2f6e0eec1f5af10d47e287c64f8d365e20bbb8f118b1d36c0b49736d3cd2165c119291a9f2c70e31c607d2b355b9b482b9b2a4fed687e9378ffe3bf83fe1d59c736a5a8fda649504915b58e269244c1c3019c60e3824806be54f8b7ff05298343b98ed7c27a3a932e4093534dedc704909285500fab1af71f14fc29b5f18fc1ef0a4c624b9d4acf49b58fed0146644108f627a9cfe35f925fb4878e2c4f8d754f0ee996eb0dbe8d773db4921501a595646573907eee5463d71cf6a89fb46ed714396d768f51f1aff00c141fe2a36abab3693e2b96d8dddb35b3cbb4148413cb41183b55b8e1f058738af9bfc4ff10f5bf1ceaefaa788b5cd43c41a9380bf6ad4ee5e79703381b9d89c73d0702b8a9ef1a6724b1249cd3627de41cd525d096f76748ba98dff003c680e3afad6e687e2fd4b45bcb7bad32f6e2c6e2160e8d0c8c8c082082083ea057256e9f2064258f5c3f6abf6d704ab02b923be0f1ee2871428c99f61feceff00b6bea7f0f7c756fa8f8bac5b56b1bad89757568317076aed0d8242b1e727919c0afbca1f8afa1fc43d065d4b4cd522bbd0359b5650e0a110ee41c91bf2265f306f8fae318e786fc57b7d6a4891a25930474c357a1fc19fda6b5ff84fad18daf24bbd16e014b9d3e5766889381e6a2ee01650060376c91d0d79d8b8cdc3dd3a128cbd4fd03f88de12b5f0df8b3478d665bd89ad639d2ea320aca3cc7c103fdd03b9eadce0d430b22ead70c78564dbc771906b85d1be23e99e39d32cf56b6d5167b38ed91803283e48237146e4ed209ce3b64fad75f64e9332ce8fb9248c32367390791f98ae0a151a8de4eece6926a47d33e04f11241e17d16ce49849288230a4f7520e3bf60a4571bf1634b4d6bc75a4b3a6e8268218df81cafda307ff0043acaf0a6abe6787b4e95982c9139b19021f9846c772b63b1c865fc6b6354d4daef58b1f3ca164405994f00abf9871ff007ed47e35e5c9cfda492eeffafd4ea8dad73e76f8d9f0fedbc27e01b5f10592b43a94ba9dbc4ae1888da29125cab28e3219073e845737e1fd66f7c59e057d1247596ed2713d944ac77f9aaa14aae7b10e3a770076afa07e236996be25f06269f7906e8e3bf595507f0308ee1573edb941ae6fe05f8120f08b6b69aa5b5b5fcb62f717d633601f299331fca580c1263538ce3806b8b114e30e6c4c56a9bbaf2d07cb6bb458bbfedad6ef649ef8485b4f44d3a38fcc3996745cb33127241e781f333640079c79bfc43d2dee2582e58e648d91e55618c8193b5873c640041ed91c576f6de28bdb991ec2c9249a7b87371757ae3e546208711e0f19c9cb9ea0633591a968d25d8d521954cd3456ced88b2426d3863d0f0067dbbe715ac694b9254db564b4febb1835757b1e37f106e247f1178723e423637f3c0c9e73ef8183f4ad8beb916df6188ffac48107c87ef3331c9fa60135e7be31f119bef155941bcac7608c1f0305e40c4123dbd2b52efc592dc585d5c1f2bce8a51650ec463f2a83c9c1e492aa33d307a56306a13949765f97fc030a4eedab9d0f8a3c49f647b5c451fef6558e247519cf77e79c0181ed5f4ff82fcc6d42d0dba44cf1e971c6429e766e4f9bf5af89f51bc9b52b89355b99e18ed6da3f221dd9c93827231ce79ea3d6bed2f074b0e9be1d6d5a51f66ba8f4e8ed32dca2ca4019ce4120609c75c0a9ab59ca351efb5bd5bfd4ea82bbb9b1ac6acf7ba904b6943c718c0589b2c5149f980048cf7c8ee3b669fe36f120d2fc37672da969268dc48d1b804c8c36912a8cf7c119f761583e18f32d2ec5e5c88248a1765492d90ed53c60b82305300925496c13d466b53e28695630d8e952c7b5e09fcc70b6f2011e700e50f385e7a0a787a74dd6a74a4ae97e3a3febfa57eda4ed2e63e56f107ed4da95f6ad7f69a1783af67bf86578a49b559043186048e8858919f71c5614ff00123e32f89e230c32e93a22c831bb4eb39659467d0c8587e42bdbac7e1d78761beb8bb5d2e2927b8732bb4bf3e589c9e0f15d1da6976b64a16deda2800ed1a05fe42be8972c7448fbf846a38ae5697c8f996d3e0ef8efc505bfb67c47e24d4125f99e2b9bd96284e4f3f27031cf4ae8f41fd966c6c8a35c5ad8a10325f6f99267f151fcebe8254c8e94ed9ea2ad4fb17f576fe2937f81f9e1ff000504f0258f81edbe1e456649338d437fcaaa3e5fb363000f735f1fd7dcff00f053d5dbff000ad7fee27ffb6b5f0c57bf857cd4537fd6a7e7d9ac153c64e31db4fc90514515d479214514500145145001451450014514500145145001451450014514500145145001451450014514500145145001451450014514500145145001451450015f43fec8a33ff0967fdba7fed6af9e2be88fd9106478b3fedd3ff6b573d7fe1b3b705fc78fcff267d0bb33f5a45886ee454e17d285539e95e333e9ae539ecc38603b820d77bf0dfc2badf8ae2b0b6d1f46bdd5e492cdaca55b488becc32852e7a051b9b249ef5ca428048095071cf3debf553e0fd8e9707c38f0e5ce97a6da69b15e69f6f74d1da42b1a96789492428e4fbd6d4aab8be548f1b30517cb22f7c27d16f3c3bf0cfc2da56a1198af6c74cb6b5990904ab246aa4647d2bac1c0a441814eaf620ac91e28514515601487bd2d21a00e2ed2f45b7c5dd46c4281f6ad1a0b9247aa4d2a7f271f9575d717315a5bc934f22430c6a59e49182aa81c9249e82bc1ff00690f136bbf0fb56d3b5ef0ecf0dbea17963358799344240803ab8201e3393df3df8af83fe21fc4cf89baff008bf4ed0f59f155ddce9fa8991c66590e1d73c2a1628386f4ae3755c3dd4ae6918736b73f4de4f8c3e189df528748d423f10dee9f68d7b35ae92e933796a707e6c85ce7f8739f6af993e317edbde23f0e5aea53687e1dfb159dbc2ee66b98bce9d40ce5f1bc2a903070430e3bd72dfb05e9474ff89b2dc5c5c5cdccd79a1ce929b898b866135b93c1fa3703d6bd13f6b4f83107fc227ae5c69d6eb8d42d6e6108ab8c3b4329c703da89394a29ec52518cadb9c3fec81f187c7df107e3dc7ff091ea334ba35f6857379041717523fce25808c267629dae78038c9e7b57a97ed7fa5069f48bd2bb96485e06ff00809247fe846bc1bf654964d07e217c3f99111ae7ecbfd972375421d63f3083ff006cce2bea0fdacac526f06e9b7254978ef047f83239ff00d9454c972c2c2e6bc8fcedf8bda05bd98d0351dab094d4c46d2018f9591988ff00c72b77e1c4acb1789eced91ee3fb474d7693cb3cc7132a83263db6d7a17c45f0869baffc1abe7b9b657b9b1d72cae165006e0852652b9c1f972467f0acef86769a7d96ad75e45bc48f368b3da8381f74296007e22a68b5aa5d072f33dabf68efda32f7e0e7ec5fe19d434bb8107887c41a7c1a6d94b921e00f6a4b4c0860432003919c315e2bf1eb5ed4e5bfbdb9b8b89a4b9ba9dcc92cf33166762492c49e49249249afaa3f6d7f89f36ba7c03e158a766b1d0b4305e1cfcab70f2caa4e3711f7228c7201e4f6c57c8974fbe47279e6b793b19d880487755883dff004e2aaf56271c53a26e491c54c5dc76b6a6c5bdd4b18000daa78e0e735a50de81feb7706f53e958514d92aa7f1a9a5944470a58023b9cd3e817e86f452c0f208d588df939e0e6b26ea1469e555cf0091f99aaaf78542107a1a89ae18c8c738cd60d75344ceb3c27f10355f0dc7736505d3fd8ae6331cd064ec7071d467b62bef6f837f12b48f15f876d6dad2ec48da65a451cef2e141daa013c13e9f866bf3611c2b971c1cd7b5fc13f15ea56d7967a269424db7f711198283be4c32e41c7f06339ff0ce7c7c541417b48ad8e984155d19fa7fe118becf60b2bdb48c6725170bf28ce0a303ea1b6fe04fad696a4ed6b7969e66043282ac472579e4fe229bf0aef6e24f06a97841449594a329dbf753072780d93ea3a7e2b67c5f0453c76f24392c5999d7232809c138eb8c83d7a739af0635ef8974e4b76d7e1f83d81c128900bab1bc9916f5c1827942ca4e3839249f6e19bf3a75a2e95b6eb48b543721e3bb9371e9b4b32fdef72a3a67a8ae79c7d92276c82371600f6f971fcb15d2e89610aea4fab3285b396099d54ff0a90dc63f11f9d698aa69536d37d7ef49dbfaff00805d3578c91e65e16d0358b9ba9d818ac74ab594b4f260aced8273b07451fed364f5ebc8ad6beb3b19f5492df4d992212db808de60916520e02c8c0f058f249e848e80f14fc59a8b5aebd3e9ff006f6b1d21f0d208885326ece5393cc9d064fca3f4aa3a578be2b8b364d274d2d67097b36bb9540808db8f948ff593632777239c60e2b9a0e4e5cd77aff4bfafc4e66ef03e4af8970cda5fc44d5616430cab2e0ab64609273fad5c8e4b483c3f119c4cead38e217032c4673d0f200fd47ad4bf1b2209f105a519d8d18ce7b10ee4ff003ae767b81b238bcd65f2dbee642856382e7f01b17eb915a5587bf23cf8be4b9dc78574c8f56d6965bb84496d6d17da3ecea73e69e02a376e71cf6afab6ff00c450c7a7d8690668ed647955b6170af33bae022e4804e0f0bd7afbd7c9bf0d2c65d4bc5368d60979713ca0292fcaa6586d5da3ea3827f9d7d0be22d42df5af12eaf66cb713f957474f67b58c305923f9392075c0cf4cf393df1c34e2b9d5fcdfcf4b7e6fd373d287bb03d13c2b340d72b05da4ab182d0308d1438390b878cf55ec403d7a1ad4f891a75ae9da0e8915aacbb434808993695200c8038e33cf39fad719e12b0d6fc397d169fa9c735f8478fecb79e516925420131cc8400f211c8618dc0738c64779f15d9e6f0fe86e1415dc72f1f0036d1b91949cab0231b79c74cf515e8e0d375e327a7fc33fe97e5bdf683e87010a600c71c0ab71af1cd5385f72823fba2ae47c274af5d9fa661fe144aa99f6a50bd6914f14bbb1508ec3e14ff82a08c7fc2b4ffb89ff00edad7c2b5f757fc1500e7fe15a739ff909ff00eda57c2b5f4b84fe047e7f99f97e73fefd53e5f920a28a2bb0f1428a28a0028a28a0028a28a0028a28a0028a28a0028a28a0028a28a0028a28a0028a28a0028a28a0028a28a0028a28a0028a28a0028a28a0028a28a002be8efd8fe1736fe30982931a359216ec0917047fe827f2af9c6bea6fd8cad8cbe0cf88d20527cabcd24923b0297c3f9e2b9f11a527fd753bf02b9b1115ebf933dc42d1f769e0ed1ef48a7a822bc668fa3b0f841c138afd39fd9b7584d6fe07782ee13388f4e8ed8eef5887967f54af80fe137c23d4fe2cea17d6da65ee9f62963089ee66d42668d523ce0b70add3be715f57783fe347c32fd997e1d59787752f1c5af892e6dd99cae94c92952d92ca30fb540607ef303cf4a74fe33c8c74a325c8b73e9f8fa53abe7ff839fb5ee81f1bbe25cbe17d0b48bfb6b44d365bf5bfbd0a9e6949234daa14918c480e431fc3bfbf2f7af729c94a37478ad38e8c752039a08e2be69f1f7ed2bafe91e27d5f46d36c2ced62b29e4b6134cad248c5599770f98019c038c1abb88fa589c5566bfb7170b034c8b3b025636601980ea40ee2be25d43e2d78bb529e7b83e20be85e424ed827745504e48501b8158926b57cd225f8be9fedbe697371e6b79bbb83bb76739cf7a199f35f43e8ff00dabed126f0269d3ec0ce97ea81b1c80639323f41f90af877e22e83336a1e1dd4eced44f2dbea31c4c7fb8ae18163edc0fd2beb2b8be9bc5ffb334b35ccf25d5ce997df3cb2b16773bba92724f137e95e05e25b7ff894b48b91e54f149d3d1c7f426b81bf799d31f84ebff670b66f0afc5cd1dfed3ba19ee27b5daac7695933b47e7b4e3d6bedfd574db6d5ace5b7ba85268d95861941c654a9233d0e091f8d7c2ff0edbec9e3df0eca4950baedb64fa2b3a7f8d7de4086c9ed5d4b54ccdb3e04f87c23f0c7c41f0b2baadb8b5d696de404050a449b4e7a63bd7d3ffb4bdb8baf872a71b825da3f1dbe4907f5fd6be61f8936b2d9f8c7c4fe529dd0789256040ec6427fad7d61f165535bf84f79344a5c3c31cebc72075cfe59ac2a3b40a8ee8f93efed56e3e19f8de1393e55947743ea93273f916ae07c3a16d7c45668de5a79d6c403d86548fea2bd734fb277d0bc53665769d4345b9b48f77019dd7e515c45af814694967a96b37b6ba6dbdb401657b89820181c9cb6001c7ad7252ab08397333d1fa9d7a8fdc8367c4ffb53966f88f30c602d8431827be1e5e7f5af0591773633f9d7d33fb605b68b378c6daf7c3faa5beb3652d888daead6449631289242cbb9491901d38f71eb5f345c44413ed5d4da7aad8e294254db84b74566753c0e00fd69b18cb1a72c45db02afdae992cbd16b27248a8c1cb629842470338ab080c8809cf15bb61e189a720607be6ba6b0f87acf102ca0e474c7ff005ab3f6f1ee6cb0d368f3a743b73cf14c0a5998f6af486f8637934adb22c20faff855fb0f8432cf380d19d9b7181d73ebd2a1d78a5b96b0d36ec797c70970000727815f65fec5ff00049ef6da1f1b5e4616d62324506fe8cca509209e3b1e3d8fa57cf7e3bf87bff088dd6951db234c6e7015319666ce00000e79c57eabfc02f0adb783be0cf85f4db9b282dfec7610fdae365c3f9ed1af9b9e9d6407afa0af0b34c4fb2a69a57bff004bf335a6bd9dd3dcb7a1ea09616ed6a652b1c7279b1c276aa12318727a0cedc679383d7a96a7ae6bc668d1e0631bc6ead194e23650a0038c72a79c1f7c7239aeaef3c10ba809af6d8fda3cd80ccd6d2619df209c293c64924027207a135c3ebda14fa55abc972b1acbb85bc8b73ba42d9c9611a71e63e30319da3b0af0235e8ca4e51dfaff005fafe663293253729ae5ab49122c73228f363e99c0c9651e9ed5a3e12d7db4e6fb2dc39680c2e819b90876fbfa64579ac7a9dc693acc2d1175013cc5594fccab93842a3000e0f1d47435d54f7515fe9ada8db3aae54f9918eaadc671ed5e8d19c6b45d296db1a3f75f3a39bf8b561024a2e2e1e46125bc4f212db9cee8c3155f4e49e7d31d49ae216790da47e75c0b1d3a0b70d05a40de5a46c318595bd4e3945f99ba9603afa97c5410ea7691df45e57eeed6dd762939ff00563231d377f41f9f96ea924074396c820bad4c039957062b6c83b57ae7cfc807dbf972a4d46cf4765f7dbfafd4f3e4ecda47957c5eb42fa969d78bb48c60ed5da31c9e9dba0af3cf33ed37a558169a47ce7ab7527f9e4e6bbdf1acb7379a65da5e2489776817893ef1f7cf7fad79c4723dbb4afbb9914a12c3b1e091e9dc7e75ab973abafeba1c735a9e9bf0bfc7d75e08d4eca2863b77f3ae4319a4072ab1e59c820e776d5183d2bd2fe135eb1587524c4f7d7721b8995930b2ee20e180c6e2091f36339af9bfc3ecf3dfcb38112c3691bc9ba5ced3853f2e7be7a63bd7d0df0235033c5692de06f225c6c68908f2b214e1c1e002070dd29d2f7a714f63d0a73955dcfb27c0da15beafafcda9c015acdd911e01bc49111c619598f18f97182304e08c6293f687b0b7b2f0ee9f2c49e5b35d6084c28762ac4b103a9e3afbd7a5f86b4db3b8b0b1d4ed6316ad2c4a7f76c1b7a1008563d0fe078ec7ae785fda44245e1ad1e490ed8c6a2849ed8f2debd9c2d1508a93dffe01ad37cd554763c36d237d88bb5836d5e2b462b6936e59481ea78af28f15fed39e08f07fda7edba95f4f2c04a3c7676ac48c678c92a3b63afa570d73fb6f785eec30d17c39e21d6241ff004c1157bf390ec7d3b77a7cb29743f4aa75e9d28fc48fa4bcb451f34a9ff7d6693cc8173f396ff747f8d7c92ffb5c78dfc40b23f86bc176d0c0b2189a4d46476dac09c83865e4719fc6b9ebefda13e316b5adc9a47db344d165f204e7ecd039014b1503731639cd38d36f539e799d38dd732f9197ff00053f9237ff00856bb0371fda792dff006eb5f0b57bbfed47aaf8a356ff00846a5f1378825d72506ebca56cec87fd4ee0a093d78fc8578457d26155a8c52feb53e0330aaab62a734ef7b7e4828a28aea3ce0a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800afb2ffe09fba1cfaff827e31dbdbc2f348b16992a8452c72bf6b3d81eb835f1a57d95ff0004e7f145f78627f1f4d660b871601e2ea1b02e71f29e0f53d4571631b5424d797e676e0aa7b2aea7ebf8a68f5c9b4bbab5dfe75b4b094c6e12215c67a67355d93084e2bdcfc43716fe2ff87577aa44166bb9eeb64f23da47032b245c22ecce47ef3ebc578d35a383e5943bb38c63bd78387acabc5c91ef52aaaa26645dc324f6b3c0249238e55dae2372b91e871d6b8ed17c36961e223712abdc5bc48cef1bab4ad8271955c124f4e95e8ffd9d339d8a9c95df8f6ce07eb4fd1b496b6d70348833e4b6411d41e9fe7dabba9f2c9d8cb14d7b26d6e8f48fd92f583e1df8d1e0cbb2b3c16b7024d2f0c367986401429538380caad83fdd1c57e98af7afce2f855a1aa78e3c397a9e5ac7a76a497f2190e02a44448e47bed0dc77e95fa3719dcb9f519af5e92e5563e69cb9871e86be2cfda1745fec5f8b3abb2a2a45791c57698efb810c4ffc0d5ebed335f28fed5562c7e21584c07cafa6a0cfb8965cff00315a37625e88f1689cf2b51fdb982326cddb58739ab11443736e2001e94d0b6b0b9254c9d18873c6334d5998dcf72f835771ea9f01fc7168305a133ca51b048fdc2e0e3eaa707dbdabc8aef4e6bed36e631199098988551924804803f2af4afd9bf594d7a7f186811c315ba5ce9e70b18c742533ff00912bcab5df15f8a747b8b5b0f0de87657b23e4497574f262320e3eea0c9ffbe85799886e13ba5d8f6b01423896e9c9d8e8bc3ba35ed96a5657c6d1d4c4d6976aae0a6590824648ff0066bea8f18fc60d0bc08e20d46470e211299328b1aaf3c9666007435f197f677c4af126d3a86bb0e909c663d310c591fef36f6efd88af6ef8d5f0c345f1cfc3df06ea3ac43f6cba8a2b78e49880cd27ee989c96073ce4f34a35db849df63d396594e9d5a74ddda95fcb5f99e5fe37f8b3f0faf3c45abdeaea91ea6f7f73f69369a68fb5bab0edfbbc81c8ee7bd7d19a9f8b2cb52f841a64f13948b51d36311c72aec7c345c7ca4f51c71dabe7fd33e1c787745402db4c886d1c1645fe4062be89f0658596b9f0a6d2d6e2189e28e27893e41fbb2a0852be84579555cabd395a4f4d4d334c1ac2c6128c52fc7ef3e53f1e68fe20d7dd74dd1f5db8d0c3125e4b7dab2347823862ac41cfa560db7ecfda6df98dfc437d79afc8a723fb46e5ee88fa799903bf6ef5dc6b1398759b2ba2d84dc607cf1839ebf4eb5d47d924b3b8412282870eac3a38ec47d6b8e9569c6f096e8f5b299431341c6ab7cd1f3ff23e19fdaeacfc2fa55f685a1f87ae6c24168b38bb8ade68da48a462a02baafddc6ce8466be50b8b71e7ca83b3633eb5dff8ee5fed0f177896f0e7cc9b52b89727ae5a573fd6b8eb2b279f528d1b243b8cfd33cd7bf19fbb63e5f134ff007ad91d8e942302461f31e40adcd3cdac4e8259523e7182466a7d41e3b62f120c3118c9ec2b2a15b432fef98927baf5ac65abb041d9687a7f872c34f9551a3952438e9919aee74dd3a12bb7629c5780b1b7b28bcdb2d4a48a4041d85b07f435daf827c7b7725c436d2cad38e9bb927f9d72d58726a75d1a8e6f959ecb6da4c0780a3d3a56b59e8d0860a362f6ed5e77acf8baeb4c814c636160397cfbf4e6b8bb5b9f19788755636faf25ac6e788e4b86518cfa5428a92f78736e2ed13e80b6f85e7c5df163e1c318c496f6fa924b303ca14421f278c119500fb135f644faf98e1bab68d06d9c3492a28fb880a9040ec305b9e95f367ec85e11d62df52bc6d73536d42d2d6d5e4864399184859084527f84846f4afa7ee6c925b3d4208619a393ec0c4b10a04bba366017b93c85cf4e31c9af1f19284db8be96b7f5ea73ce0d5db2d693ad4d1dec44b484359a98f602d802247e48380b91efcb0f5adbd5ce97adcd1d9dd8566d8ab15f478de9c98f04f75dd9247d7bd7216d1c5e759daa5db40eb6e80436b22b384f2a3c19b8036e0924fa62997ff6fb4d22fb50fb3b416b68921495778de361951f2df7b2cf83b78c8e2bc1f650e68b6eda6fe6fcfe5a6fd4e595d5cf3df8ade19bbf0c5da82cd3b5c9012f594347200a702255fba063a9ce338e78ae334df14ff645cac171759373fbbf2a4701db27aa8e38af62bbd734ff0012b5cc1a9cf31d22f6d1a48151c6fb6c8251d01380ff00787e95f3cf8b7c057da4f8e2d34f2649adae94496d7900556b90588560d8273c0c8c9c135bc79e85a527e9e7ff0007b985ff0094f65d1b4c835dd02e6ee69bf749384decc029555c9553ce653d1540ed5e4fe33f13e9fa42dc58e9ca097ccc4c4c195a5e7ef367e66ec4ff008d7497d77a845a55c588bc5b896d13f7de48c59db1c1592318c6e97039c8c9fe223216bc87598d5a759624716cc436e63c9193c0f418ec2baa55277737d7f03964ef2d0c796f66d7751bc4bb95bccb888c6e5463cb18603f2245607873c1a9abac777aa43a97f654ae6dede2d3a20f757520fe140c31b40c967c103d2bdf3e0efc1bf0f78d3c3106b1ad6b32e8526a3e209349b52b1865948855d557774cbef1df38031c57d11a6fc29d0345b6d2f52b38e1d5ec3ec36da6186d72de429e2475f2c02d1b364c8bc6ecbee3c6070bc4ba4f952bee74468a6bde3e45d03f66cd4b4db0bad5b52b55d53c3f710992d8dbe6695635646264540555b66037ccaa3246f5ce6bd6ad347f0fae8769af787f519e0d29a21a75e69cd1c692da5c15070a063f77b47cadf3127209e4d743ac7c70f0f68f7da86857fae5fe9da8e85772db29b7b2b5b6b54d83618614694332657f888dc339f5a9b4df893a47f6669ba8e8be19d0fc4fa4df4fe4ea31a58c22ee06383e61f2be55539efbc0391bb90074509d49494a5f7151e58e903ea4f8629e4f84ed044b2a5ab6d68d6e10232fdde028ed9cf524f6c91835c6fed4ee7fe107d37fec20bffa2e4aecfe1dea96fa9f85adae2dcc89192365acaa6378071b50a9638c0c74e3d2b89fda99c0f0169d90003a82f27a8fdd495f5986d20979993f8ae7e73fed23e11b73e17d5efe28023fcac580c67e624f6acff0b682f0f86f46f2e1e64b488e547525057aa7c59d08f8a7c01acd9c32c51484065926385201e7a035e73a3ddea3686cacd64deb691245ba24c29d8b8c2e7b7bd4e2aac69b4d6a6aaab49c59cdf82ec1adacb52464642da84f90463e6dc33fad5ab2f09de5df8ce5bd36d2b41f6658f642a5a67f989f9571c0ff0068f03debd8b4dd5752f106932e9735ae9b756521def753a0f32df0bf791faac87d32412338eb5b7e15d08ea5690d968c5ed60980fb66ab7112b4f39e8618383953d86093fcfcb962efeec569fd7f5bd8d1d5bbb9f11fed95e17d4742d3bc077777690dada5e2de8b6f21b7eed9e46edec060b8dc32339191c00457ccf5f69ffc146b454d134df86905bc02d2cc36a6a90161e62b0fb20667551856236f07e6e39038cfc595f5f97cb9b0d177beff009b392a3bc98514515e819851451400514514005145140051451400514514005145140051451400514514005145140051451400514514005145140051451400514514005145140057db1ff04d3d3e1d466f8871ce8197fe25db4ff12b7fa4e08fd6be27afb1bfe09d77f3d9dd78e5616c79ada7237d3373cd71636ff5795bcbf33ab0b250ad193573ef4d1fc23a2defc2ad5f4a7b90ba9c5ad4d2c0770c94da899c7719c1e3d2bcafc43e159ec1cb9019a270ae50e47df03afa6770aefeee5db703ec4c51dca29766f9464e49e3d71c9f4cd68ded8d9da69d7d77aa006284708b83e6480e4019fa7e59af8fa4d61e12bbddb7f7ff005f89e8c65efcadb5cf29f0e68f399a3558da3b99b6c28cc380318cfe75a8fe1f6d3f50315c41e4cebc49b81dce724679ede9563fb6e4b9be560ed6e18e11212542f3c74ae935ff0014dcea7a4d9dbde411ff0068e98365bddac38692304e6393d707907039ce724d52ad3a6d4a3aa392b4dbbdba96bc0be1fbcd43548ad74c8259ee2588298d51890ac0a3b703a0cf5f7afbb3c3ff006afec3b0fb700b7bf678fcf00e70fb46ee7eb9af8efc15f16127bfd06ed99a29eca68e39248c05fdcee5de84e79eac71ec2be9cf037c45b3f134d3d9a3ee9e0542588fbd9073f9107f4f5af73098f551da7d7ee38b96cb43b8f5af9fbf6b6d1de4d3341d5625cf933496ef8ea772ee1ffa037e75ef9e70c1af1efda86ddafbe1d47e5abb9b7be8e4213b0d922f3f9e2bd5ab51463733dcf93f243e01e719c5496b6f6d70f29b899e30015da80648fa9e95a161e1cd46f0936d6334ec80ef2b1960bcf7e38eb41f0a6a06e65332c76c3393e6363f402a29c9cae6563b8fd99459e95f14e58e16901bcb19615de41cfcc8df9e14d50d52d45a78eb5bb65508915dcc8aa06000242063daa3f8493d9e8ff11fc3d7115e2bdc35cac26318c00e421ef9ee6ba4f1c69ad63f123c41b872f3348a00e4866dd9fd6b9715b1efe4ced89895614e0715e95ad48752f833a4c9d4dbcaa9c7a2ee5af3fb3d3ef2effd459cd367fb91b1fe42bd234ad2ae7fe154dfda5ec7f6597ce6312dc1d99f94118cfa9cd79d87f8668faecd6ad35528cd3da479994c82735eb9f09ee82f82e74725952e5d0e7b02aa7fad79c1d0f62ee9f50b28477026dedf92e6bbaf01ad9dbf86f57b78eedae23ddba4748caedcae3233d7a570559ba74e5639f3bad4ebd18f23d99e2de2bd2639759d46da5052de3bc604af5550c41c0f502baa85edef3438446fe60b25548e46eaf0e46c24ff007b1c1f7159d7d025d6b1a846ecb2dd472b962cdf2be0924fa92719cd7211f88a7f0337dab51522d49f2d762ee272c08183c7d3f0aca4e329293766adf33e630988fabd64efa33f39be27e991e9ff0012bc6f64a36adaead78883d84f201fa015cbf87a2dbad296e4846238ef5eb1fb4f6916d2fc44bbf19e8f6b790e81e26cddacb3c6142dcee612ae578e4e1f1d7e63e95e4ba0cac3548f2c09c1e6bdaa53bea9dee74e29c66db43ee2c9aeeee653f3303deaac5a7fd96e8349170a7fbb906b5c384d66603a1391f9d75fa7585bde443cd456c8e869b7664c69a923cfe6d274fba9e69cf9bb9c6762e36afb8e2ba3f865a323789edc30f90e0007bf23ad5ff13595ae9564ed1a2ab11d07e34cf87975e46ad6aee363075fbdc646454d57746b461691d47c66d066866b4993cc8ecc285222ce01f9bad729a5780a6d7efb4d6d16ff00ec90ff00cbcb348412723a6060fd0d7d15abe9f6ba8697135da23c3200a77018e41f5aa5e1ff0087fa569937daad6155279c003ebd8544a4ecec822a3f148ef3e00ddea9f0f345bab796edae9448420dd8128238073d8649c0f415abab78c3c59ad45ad6b82e275fed0fb42e2e37245690807098ebb55704a0ce73df35d47c17f0a59f882d35a8af1a48e258420742a19720fcc9b87df0391ef5bdaffc292d676d0595cdf5f44b03490c595ff49e3e60ca14ae7030c38ea3a0af213a2a728bf8bfadbe5fd6879f5ea4dc9947e15de6fd52e9638e1bf30693122cd76159142bc68c707f8447f4c007d335d1fc61f898df0eaea3d3b535b48d2e2ce0794942d2ca4cd2290a33feafe527a70071b7a533e1678155bc41756917eeeceff4695228d58c6d0481951a1976f46562b94e98c13e95c97c52f8596faf78be6f18788249f53bed1f4a6b5b0b5864caf9c8ceaa64c82d82db98e303041c72693f673f86cd2feb4f469e9fa9946f6b333ed75c8b53f0f35de9b34f7116917b15b4b75b31ba1da7ca61c9cf0a7e638049e322baaf01ead6fe32b16b0bbbb558aca0ba5b6b82a19ed658950a48b9c90482fd31d06304023c2bc2fe35b8d0fc4d6de08bcba48175a9d4dd7969f7a28a2987985b7677b48060118dbb00c1aed7c21ab7fc22de2ed334e8546dd4b5d82da59198aee8a495508e3ae43743c7af19070c45153c3b4fa7e1a7cfa982972ceddcb9e2f8eeb44824d2d5111e172ca0a9114a0e4f987201773d73f771ea726b8fb0f873ab78ef508745b0b88daf6f9f2b24e246d872011f203b540258f1c015e9be25f0a5c6a77cda779cb36a114f1bb4f38dc150c4a5a3c9385dac24c7b823a74f52fd9efe1ebe8c752d5f50ff008f999db4fb7f24a9d8a305e4046707381c1e369af364a4a0ddf4b7f5a7f5a0e304ddd97bfe152687e12f04f87fc3b3db975d1a249e192165c0bb41bcdd38da194ee561b816c090f4ea3e58f877fb406b1e1cd7754d1a5d4583dbde358e9f1348eb1c52798ef16fcb0386fde21c63890639c57be7c72f89f37833c75a2d8bceb37877559d6c56f6595d25b0d4103a9fdeeec460c7b48dc08c9dd8c124fce5f1efc19a558ebabe3dd1225b2d612e564d634fb965d8b2aee2b70aa3043b64b63254ab295eb80f0b4e3285aa2bdf5fbbfafd0d5b7ab467fc67f8852f89fc49a578bf4516ff0062bf8c437d6d7da741711cba8464ef2aacac36c8851faff11a8fc413425f46bdf0adc5df87cdddbc571751db398628aed5bf7d0a08c8db1e763aa93c061c71c79bdc5bcbac5aead15b5e18a196effb4d313e6455217e51fdd3b5981c74da066badf0c68175a6e92bf688c4700912e51c0c02406525b8fe205496efb066bd174e315cb17b2305b9f7b7ecd5f1724f16d82697abbd84b7b04118177112269c2ec50d2649c9248f98919278079a4fdb1bc4f65a7f8374cd35ae516f24bc13b47bbe6584472066f6e48033d4e7d0d783fc05f882fe11bc8aeef64d3d34b89c19ee1c8599026d63b0839f994631d1ba579ffed09f16a7f8a9e31d4afc5ca47a61222b356043790ad26d1b413927249ed9aec8576a926979a2a492774617893c48faba4fa7dbb489088f78da194ca71c46beb9cf5ee463b7337823c2b3f89aca10af2c5b418a465ff5d8c7dc55c718c8f99b8c66ba6f87de1fd1f5bf0fdbc93dbc92dc4215434cca86338054a8f98f967d78c1cf635ec9e16d2e1b0d8574db18e591824b2ac6c588e08c8ced391938c63f0af3e52a959fb463508df5387f087c3bb6d3e08ffb48cc2d217c791000636381cb671bdc81d3bd7a359dadbc11ac3a55bb5922c995babdc244909e08c47f33498e766541fe7d17d86d6292f0bef416f02ca04691a6dc95040c28ee7a55c3e1bb3b85402eae7ccc08c6240171f7b1c83c7b7b570cdae5706ede9fe7fd7dc6aa0b73f3e3fe0aa5a3d969765f0a1ecf55975159bfb54b24bb57cbc7d8f95450368393d727e5ea715f0257e807fc157eca1b4ff855861b9b8b8575d4f02e31941fe8980318f5e98afcff00afbec9d5b034d5efbefeace4a8ad261451457b26614514500145145001451450014514500145145001451450014514500145145001451450014514500145145001451450014514500145145001451450015f59fec07746c6fbc6b3805b6ad90e0e3bcffe15f2657d45fb1146d2c3e375578e36ff00423ba472bd3ed1c0c77ff0af3b30ff00759fcbf3434dad51f76a6a89a8698a610b0cbe7a3000e49c2b03d3b64ff2a3c6dac490dada69af22feee359a5507f88e40fc40c573be119ca41145213968c30246e079ee7d2b3fc5d74d75aeca3710b90ab93d4648cfb8f4af896dba2a4ffa675d29ddb89b16022211e588c91e413b464d7a17873e1d49a8e95ff0924ab776fa487082361f3b719de011ca7bd79bf879a496e0e237b8b5b5024b8f9323cbc818cf2067a03ea457bd69be23bef19d888f4785534bb7b58a236b093fe8e395008cf2475240e98a73e6e48f2e8babfd06ddaeba9e7be21f0e5b781bc53692c1299fc3dac2248b2f07ca94b720e30015efec7debb9f85fe38bcf0bf8f74f87529fcbb7999616da700ee185c927d464d739e3cd252df4a6b21a9da5d458170ab14c1813823807956c7518ec2b85b9bdf2ce953acae27122233b3701864673f91fa935952fdd276774ff000d7f0ff339a3b9fa1315f2b20f9c7d6bc8be35f8cedac9356d267064926b780c099e8e1e439233d30bc9fa0a6687f116e2e74ef0eca8bbfcdb78bcd25589590fcac7ef74015864f4257ae6afdd687a3df78ab55d7b52b5fed29d42c3145b44ab12050dcaf38392dd78e7debb71198ce34e316b5dfee68d15357679a6917d3de5ecd35b4115a4732ac44db872d23f190bd57073df9ac3f14693aa58dc48b7504a80e182b67be7fc2bd375b8347b6863d5347be8ac6e061bece92ac71ccbcb6003d18f18c715cb7886f22ba823be9ed92e6098615a00639d3eb9c83dfe61d4fa574e133397372b5a7e3fd7f5e473ca9a478df87658345f88ba55f1675fb3ea1148c7a0004a0d7b47c73f118f04f8ea5d58a4a55ec1252b6f0891c9dcc3807bfcb5c26a1a0699aaccd3c4c570721ced4983678ddc61bf1c13eb5d7fc629a2d72dbc3da8433addeeb216d33290d875e48382467e7e993fe3ec54af4abda17d59d184a8e8cb99743c235cfdb8ac6def6fb4eb4d2fc517d756707da254611c11a46320b1fdee703fddaf72f813e27d5fe337c3ef15d9dcda2e99a8dacd1dc5aa79c66e1a33b37123a9da41007e35f376bbf02efbc51e37d6f56b2974eb2b2bcd026d37ccbc94c65e76666455c2905883c0ce7835f40fec6297969e2bd462ba8d60373a5c6fe546c595b63a8dd9c0fef91dfa56b4a8c617b1e956c7d4a91b2495b5d11e0ff1eef7e29f836f60920f10496364350b582e22b7842308a495a36e76fa915f44fecf5aa5de9936b76f7f335e2bda895669ae0b93b71f7b3d0926bbefda27e0de95e36f07eb97d36e4b88ed95d506d085a37f3431f949ce476af2bf84b60b61e20bbb2d4ae2d1a0b8d2d952491c280fb930016c60e338e3bd7918d8d3952925a34734f1352b594e574695fc71dfebed2dae088d8a1031ba4f9ce738e33c900f1d0547e2df0c58dc78624388e5460d212cbba48dc73b58740463a7ad41abdfcbff000919291bee58c02186659be72339c8defc8e83240c8ce315d5b4b6f7765189a790a1c0014e639067254e7a38e98af9b95772928ae9d3fadce168f97b49f0868fe31d274ff0beb7a74373a7c1e21599e39d76a8b73205741dc120b636f3c1f5af2cfdaeff00669f0c7c10f885603c29697563a3dfe97f6a449e732812acaeae013ce3698b1d7a9e6bdd35ab01a578d2f2cde264b2b3bb3713c807fac2b21013dc9c138f75a83f6eed4ed35ff02f8375681149f3e4b14283091249117488f27e75f2d37e380481ce2bb7055a5ed68a4fdd775e4765393b3573f3d2f2e9935063d0a9c71f535d2687ac6d40771e982335ca6ba86df5390118e71fa9a96c2ec46adb4e0e09c7bd7d34a37773be9cec8d5f17eaaf2f93d480c18fbe3359f65e25992fedded95b7230f971ef542e7525b8902cf2af38c735ade1e5d1a3bc02f27785a45c2485380d918fc2a651bdec5c1bbdec7baf87bc7375aff84ef2c1eca76912d5b13950115f6f1824e720f3c56af803c573dec2905c3012a00a464839e339ae3f42f1268da7dbadac3a808a7da14a4b85129e991eb5bfe13d385fead04b6e0f9b3ca112388677b123000ef926b86ab74d7337b1db0e569ab58fb7ff00670b1b36f025e4b72b1f9d7b78638e47db95db1aed3cf6c96ae9b408353f0e6a30e8b76219e27924ba796690fee8efd89b38ea76b673804301de9fe08f0fdbf877e1959787b5b36f697023dc7639f30e402494232581cf4fd2b2e0f185ac3afea3717cd2dd4105c5ce9d147b57e7f2dd1b69dc71fc79f6e2be4ea3f6d29c60fe277f5b6d67e7dbcbd6fe3496adb3d0f42d31a0d5a77884422be8e490a5b2e26495b19933db38c1f751d7935c97c51d3047e1fb9bed481b686381ee1aced0e25998425c798338da191cfb003d4d62697e39b1bbf1009d61d4a31b0b822ec042a33c10b193dbd69de31bad33c53a05cd936a525bc716e2f6ef3865b94085b6862aa4eec95c671f5efe850a35292d7f4d3eeff23369db43e31d27c1fa9f8afc7b2ead03ad9cf01533dcc8dbd4b03be4030d90773a00a78c44722bb8d5e6974ff126957814bbd9eb568f918f97cb9d4963e83086bbcb5d274fd374491ade3b6b159ee59a548e3d92313c1de718db853c64ff008f3fe27d02e61b682f0dab882e110a3aa108ee7392a71c8e08c83ce0d7ad0e5e56a5d4e392f793ec75df10e7d5f46f1e98ed224992ef798a33922673a8dd24591c649de00f615f53e8ba38d360d2add91849147be5fb2929134c7058903b124f07d7dabc13c2253e2778ebc2faadd46b136996ab24d1c5955699276641839e0332b1cd7b1de5f6a11f8aae278a4315b5b6c45524ed94827231ea47031d7e5ce3b7cfd7849d4e47a249fe6d7ea74c524b43c2ff006c0f023f8de497496b81047ab5a99ac615fbdfdad6eae61dc3afef61778ce39cac63a57ccf17896fbc61f08a7d0f52680789749b68d166be6c1bab24c8f280272d711b0053fd80c3b28afb73e30de5a6afe1f6d664b526ef4ebc8e7b23b46e5bb8b73c678c9d8e50447be7238c1af897c616d656bf1075abe955574e9eda2d5600ca1ff76f23b7279cb8f99491fc48476c56d422f48db6fe9af4d8d56917731bc1be1e82765b7924401c303860036e18e491cfd315dd69b6916991bc72926d56320066f900f6ec3a7ff5aabe8da2ea5e21d31b59d2f4bbab8b345599a54b76011700fcc40c0e08ebd2a84b07f6b5c0b20ec2147dd2a6e3cb7f771d2bb151749733d5dce4d6fb177e2378b6c7c47043368d6aba269d059476ac52110b5d4a8a77c84292ac0e48dfdf03238af373a8df5de90268230d1c73ed8d946774aa3251b1dc819fa035f4afc37f83761e38fecd4d66ca54d3f2bb5a24c2ba314568be61c63248c7bf5af26f197c2d6f0b5ef882c7489951f49f10491a2cd956645c989cf1c8d9bc13c745c7539d145a8d9f63474e7b9a9f0b6fe4bf7b596d731381803aa15241784e3d0e71f87bd7d5bf0d74a1abf87656966449dee51600f8c9754180493ee07d4d7c8fe09887847c53199a41169fa8829e4f7867561f303c0c7de1eb82bf8fd29e04b5b9d46068ecb52b880a473dc208f2578d83770c31d54eef61e95cb08f2c269cacff00ab684a4dcac91ec97fa0e9da7f85356b87457ba9addadd776d6cb9c85c1f5c918fa0ae3afa19d7528f4e0adf300ac719209381fd68f0f5ddf6a3abd9e837d697ad0acd1ccf730a6e5765daa18b37543b5db3d4f5af533a069c9a85cea12aae61642dd0e4a82c3f56cfe5583a6e13729356b7f95bf5fc0d76d0fcafff0082b4472c37ff000c164da77c3a8cdf2f41b8db7cbf800bf9d7e7f57e877fc15f2d59756f86b779f92e5b553b339d841b4da31dbf7663e2bf3c6beeb287cd8283f5fcd9c93f898514515eb99851451400514514005145140051451400514514005145140051451400514514005145140051451400514514005145140051451400514514005145140057d4dfb0d4734cde35457516f8b26917cbdece47da3007a7f17e95f2cd7d4ffb0da030f8e5cccf06c363f3c7f787171c8af3732ff749fcbf3434ae7d95a2dbbc3651c811eddbee879762b1071c2a8e7b77e2af3e991c88d7578522b60c552529977c750bd32704565f8611679edadd249279a660aad2b6f6009c6f3d70a3d6b456e62d4fc411dbb48cd6966a5c28e54857fe2f407b9af918422e166c13e577376df4e86c7439ae21ba92dc5ced88c0b380d229e40703818dbd0f438a2e345d46c22c44ff0067cec2a61936920a161b80ea0820fe5541a52f72d24c14c5c88e2520fcc4f51ec38abc358bbfb233dcc8ed703f7055cf0aa061472723038cf1d46056ae9a836a3b14a6fa9830d86ab1dedd41a8dbb6119996404e54678ebdfdb91dfdab474ad393519aeece58da45583ed904a17e459108c86f4f97240f5c56869f25e5f5f5bc71bc897b332c4a55ba92405e7d3a57a37887c18de1dd1666b29d656b658e7d47672d280b990f006631dc1ee149af36a28c24a127bff5fad90926ee54f877e34961f0ddd5ecbd2d229ed76b8386c303b81ddc36d0003d30a2bd3be0f6a32af80e1b9bb66b9b8ba325dcdbdb2c41c05ebd72071db8af23f0aa46de18d6b4fb695265b3135d24f1707ca2a731b7af41f427ad76bf0db55493c316118b86f3915764708fde154c00bdf3d0fe74ab535569b7b3febfaf2f4378b77b3399f1478865d5b5fb988dbca6da37d896ad10f2d00638c2e4f6c73fcaa63a05c4f6a9e4f996f11218c596118cfb1cf35b5a37831f5bf126a17b716eb6d67e6b5cbb5cc877a82738214e3b9e09ad4d5eedd992cb4ab3860b7f3163594a0dcc7a75edc7e35d0aa24d53a0b65af65ff04850beace39bc2c65607708a451f33336d04fa00d8c9a75cd8f91a769e0ea1131865e6d95b8ea724803a9c62aaeb3732d924d23480e1e6956427ef80ccabcfd53f51597624dc6912ccdb5d13e676dc72aa00cb7e3b801fef7e5d7185492529cb4ff874547953b246edae851ead7fa5a432c51c697d15ccb031c097048c28e99c360678ad2f8016f71e19f8b90d8dec4d6d349653db04707e6db221047a8c2139ae57498de756b99a7f2205fde293f7d8718541d09e78fa1aebfc0bad4d6de2bb19e48a1923b59f8b9d40849620df290194f7e7e4e40ebdb23be962a5464e33775f97f9ff005e8535cc8f74f88b7119f08eb36f70d179571692c637385624a370b9ea7d2be5b7d1238ad84b686ea19845873e6a44197049048ebd3a77f4afa5ad3c65a278caca586002f62652922b05c2923a104f3d7b0af0cf0df856e6c3c45a4406ca56c4f8697515da8bc919f29483d8632d8e79eb5c955f3ba924f6e9f7908c1f0de87fdbda9c36f7972f0c0c061c0ce1411c8638f5ed9aec3c5b6b73e0bb58b4cbd95af34f9cfda21bf58bf79b9b82aeddf18ce7af22b4753d0adf4ed7e09229a09524b93049e4440846ee308485400670c411debd0af53c3fe2df095d5ade3249696e4c0d336dcc4c1701c139c1c1ce6bc3abc936aa475feada7f5a97cba599f2f78e12d5f54b4bbf924b79162ba99d5b05183156663ebc6efa9cd79cfed77ab43aefc1384595ac915be9928b8b690bf0368da4a803b83927a92c79af65f13f84ff00b063bbb3d4accde456f23f9058e12e61752518b7f77318ce08ea790791f21fed17fb40af88ef6ffc11e1a3a7de5b2218b50bb807fa2c4b820c30e0e19d7fbdc8e3ab75af430142552b29417bb1d9f6fe90a3eeb3e67f161f3268ee940db346b211e84e4915896b745241cf1d2ad6bf74fe4db36729b3cbf5e99ac582e551cf22beadc743ae12b6e6f5cca36a3ed076f4c0e95da784bc77a12c31daea36d0cf22e02349106c1e9c64d719a55ed8ca425c6181e306bb9d021f08dbbc65eda2693fbc42f5acb557b1d94e492d5e87a5593e9faad934a2d60076fcade50040f4fa57b6fec91e18d175bf19cdabeb0c8f168e88d6b648ca1ccad20092907036291d720e715f31eabe3fd2b49b696d34e2af70e85554638ebcf06b6bf676f8ab1f813e24a6a7abc934da65cc5e4dd2273f28911c1c138e0a8fc338ae7c465f571585a8d6e73d5c6469cb921d4fd0ff001f7886382e4dbd9ce922eedeefe50277739fba493d07af6e6b0f4ef1342d13fdb604937c8f234905ba212edf79f2d11249c0c9cf381e95c8697e36b7f1a451ea1a35d432db38397b691da400e38237ae3031c0aeb749d1e6bbb5847d86eb6ca42c4cc9b4367a11b8b8279ed5f0f2c3ba76a728eddfb98c5b9bba65b9bc55a4bc912d9cdaa9d4190426184aed0dd06d0b8c9e71c83d6bb8f05f823c43e21b3b692fa1b548530ca6ee2dc48c60295c63804e475cfa543e0df005af84025fde5b472ea528382ff3795cfd073c75f7f4ebdc695e2a9ed84b1f9aaaa2325411c2e3ae064700027f0adb0b185f9aa2bc42527b2dc9a4f829e1ebdb2682f6d2dd9989667b6b4862249ebcec247e79ae7f56f801e1abed3e2b57bbd461b78a40d1a79a98424f1d57f0af43d17c410ea48abf6846964ce361057200c807bff8547e22bb8a3b2725f6173e51907f0310769ebd8e2ba7172587a8bd93d1f6febfa662b99df9cf2df0c7c38d3fe1e6ba534fbb96f0dddcc684498cc60331238fa66ba49a312ff68c53092cd26668d270b831c87eec80fe2083eb55adb526d5fc59a33301bd61925b8d9c29751b49e7dd8f5ad5d42386e34196e651280c3388db048505b8f7c67f215e6d4a936fdfdda57eeaedfe56b9a44f0bf14fc4ed1ed2df56f0eea5a8d8da5d6a21ec2ec9528d6578c1e3f3c16c2ac3bd049bb2482c5b8cf1f1cf87afae2db5bbb7bd75bd5b4996208ff3a322bb1239eaa49638e9c9f5af4bf8b53dd41e22f10eaba8c266482e1271b53931c7e76d56cf39dbb72304e7ad792685ad0d4ec351d6982c25ae15dc9e0018563d7fdeaf6611f674538f4fd2fafe474506e6f6ec7a4eafe3fbbd2bc3c6c7c3b1eaf6d7b76be4b88ee02db9660373ec5e0608183d4607a566e81aaebba1680d69069361a9ea735cf9f35ddf4b2b483200c2b0e72319e7b935d77827c2bfdb7e2ed3279d6396c6dec45db796a19652586d04e3d39c77adef1df88e0f0eeab63a5e81a6d9cfa93832cc820cec4c903ee91839c75e80577f9cdedfd7fc03dbf63cb4bdb3b2bf43dffc31a1af87fc3de1fd5af122b6c69f6d712ec7c5bb038662431e24058e0f71f8d79ffc4ed093c6f6b06bbe1fb23a9de7da0dadc4765fbcdf190ccb248a01c152b18c938f99fdab3ad3c79e3ef1cf87d2c6516d67a359411c0d1a2c9e5ccea00d9b8e4b31049da085c293db35d2f86344d4e2b187cf65d38b10f29965f210478183ca9ebf3119ed1b7a571c95485372724a5f7fe1a6fdbfe01e0baadfbb6384d13f678d78413eade22d674b5b75733c304586911c2e30e42edfb83924f18c9c6323d6fc39a643a4d859582ceb627c8567690812c91039777241db0e07cab81bf049c60e2a6a770da9fd92c66ba862d3ad632ed1c6c0869cb613cd00005386278cb0438e9c51d43c402e964f266885b8cc57acf0ed98c280b4d2e7a6523210760cf2af000af9ea952aa97bcfd7f4ff003eb6fc54f2b93e63babbd7a3d333ab5e6a2c19a1548ad21c048de456280f439d9b78e39c9ef54dbc5faf6bed3d95825c84ba6512dc630218c6033824804e0a9eb5c5cfaa47ad6b1e17842c8c2feed358bb2edf2aab37ee623ff007000f6fa5779e2af131d27ccd420711dac53ad9795232ac52308da527dd880cb81c6368c574d29f2c63eefbcfee5b6de57d85c8db3e0cff0082be41169eff000a6c9649a7973abdcbcb33872db8d9a2f381da21f9d7e7557defff00054ebf96f6c3e0eb4c5a491acf519a49581e64778372827b0c703b67debe08afd072556c0c17f8bff4a670d4f898514515ed99851451400514514005145140051451400514514005145140051451400514514005145140051451400514514005145140051451400514514005145140057da1ff0004e0f006a3e3b1f1262b196c618ed62b19277bd98a00a7ed1ce00248e0e4e303f1af8bebeecff8260dc5ec965f1434db2b79e51752692d72d6f1172d6ebf6cdf171cfce5946380403ed5e5668a4f09351767a7e6869db53eb9f06f81b4df0e699aa5f6b57f6c8f14522c173136f136d5e3cbdca30b929f37e1d4f191a669cd6fe1db9be9efd160f35a36b780832bb7960aa918184c75624fcc4003826aaf8ff48f1778835cb68e2d1b50b4d3ad240f217b495224b78c96f2c9db8f9895c8e87144b399518a406146992136fd4cb20d8b8e4ff1166cf1d16be3d28dad196dfd7fc3b1abeed043a38bf852f99a5b4b981c324123831f182a4b718ee08231ef55bc4506a565721a6864b53322cdbd94aac80f0194e3e61ee292f350175abea7aada18eda34dd2b40c488e352d811a0071bb90157a601aeb34bd4a1d6b4c821d520f3ade688225bb6e2e391ba68f24ed6180377ddcf04638a95296aafaff005d7faec546317b987f0ca6b89bc75a60798cde54a676dc4ed2106ef5e9f2d7a5cbafcde1df06691abcdfe9af7d3359cb14bf386825072bd739fdc800648e4d63fc2ff03cfa6fc50b79f2d73a3341718b880ffa95652a164e3024c1cfa1ec4d4dace9729d4ce9bb89d1b4abbb6f2d79249334922938c0076c8c0fe559c796a3a90df6dffeded3d76fbcdaa4141ab1ce789357d43e1a5e4f2e8ab05c5a5f5bf94a8e0ed4e4abae411b1d7a83ce010706ad7c26f8ab2477f716b756b2dade48ed1c6f7ac04314648e44801dc031cf03b0e9822b9df8a5a8db7dada3b74865884fb982ed668f702addfb100faf359df09f53817c432a5cca8202ae7cada88b312cbc39c74e3271c9e2b5a31bf341eb7fc77ff863356723ea1b2960b49574ab79ede59650b3dc5d2b6436724a9e06140e71ef59badeb7652ea805b3848e2f3e659131b09457db8f7c3023dc5707ab5f6a7e0e1a6cb7d6f67a9e9ae36c1751316b76cf41952006c0236fa74cd6d78616f6fac52fef2ded6d34a3720049146dc3146e0b67e4e064e7a13806afead1841d46ef7fc5ecff004b2b68697e8731e249ddb458b4d59034cd70221bcfdd4195391db9193ea49a82f1121b64d1ec8a3bc844f77242e18f9284aedc8eecc490bdff00775b17fa2cde23d7eea28363c503b493ce38520336e6dd838c81deacf873c3f6167aa429bd279964599e503251b036827fbb18249f4623d2ba31328c21bfbdbb5fa9846fd4b7a2e9b710436577b21134bfbab586e5b0c84f0ad8ec073cfa83e956278dafa58eded6d64b8b68e55b694daf3ba5cfef2e08c11b46480c7d5077a9fc4b0c9f6cfb58996175554b68a56e91f215874c76c7d5a99a5d95f694228c949a591c5da41192aef180002e41fbbb8ae17b907be2bcbbca70555b577b7f95fc975db7d8e94fa09736927877725a3b43f65cc681c9592e087c0da540c93d777b138a53e20d7f59b3b56b0be945979bb652582a63b962f9dcbce32df88f587c40f7311f3ae6dc41e633ac533e700904640eaaa177103fda07b8aa9e6c90db431c576cd1c21a1882ce7cb8a1055564947dd0872493dc6ce3d7a23cd68dd27ebb75feb7ea45d296a6e78dfc51e16f062b5acd2cd6d7290174b9593e58d0b66491f710149da412abf74f07b5707e0ef156afe24d1f509ad9e582c6ea7586059d1a2170a5540963ead229014863853d6a0f14e9761e28b2b5b69e59e5417b033e1b335d3f03070a5bc85207eef18e9904e16b87fda63e34c9f053c11069fa206bdf1b788a01616425946eb166de8d222860559084032321b19db82b5ad1c236e30a776df7ff0083b2feb72b9b7bec70bfb52fed4375e2bd05fe10f85d161d5ed01875cd755f02de05dc86dd0839f309ce41c6338ea4edf8e3c4b2c1e1b6b7b289235581235f90142c79dc083d4e4649ebcd744fb3c3167716da8196f759b999a4bcba932659266fbc642c32467243739c93d6bcd7c412957bb9036f2b2089496dd82776581cff00b3c1afb3a542187835056262eec66a37625492163ca48d8f6ac8908ec7934e9e5dd23b673bb9a84b81824e4d458e84b4116778fa310455cb49ef67e5642bee735520b76b89464616b76d60112818e057a1430e9abb3cea956cec996b4eb71090cce5dcf059bad680d4fc898265d11472d8e0fe359171706dbe45fbedc8f615034d24aa77b9c7a57a915cab4385ea7aaf837c77a9f866786ef47d6ae2d1d5830104c54e460f63cf415f54fc05fdb76d349f1569b6df116d525b503c98750b34c18d8b0fde4a19f078ce48c7d2be078649502b4394dbc75e0d5f8b59b889313491be0ff78e4579f8ccbe8636128545bf55b9ad3ab2a6ee8fdd15d6f44f1ee889abf87752b6d5ac275c896d240e03633ce09c1c11c1e99ae5e4b86b5bc8d8e72181603f51fd2bf24fe197ed05e28f8697b149a26b97f611860cd6f1dc48b1bf20f2a1802381c1afaafc17ff000501d3ef9638fc5da7cacce369bcd35177063b796567e7b9e31f4af87964189c1a6a1efc3f1fbbfaf43ba3898bd5e8cfad2faf65d3a6d2e75fb5466ce5296a212551c26e6881f6f99a361dc135d76b7acc5ae69097f6bbd22be4f24237189c02d1b0f5cf4cf7e05793fc3bf89fe17f89ba1cb3787f5d8eea5dc938b612f97344b91b818c9ce0eec1ec7915a5e15bf9f4853a7dccdb6c668c5bc6ee788640d94939ee09073ed5e1d68549a7fcd07f9ebb796ebcd58f5e341d5a5ed62b446efc33d71750d6af259bf77716b04d03c127def30346a4007b640e3debd1b51d66cf4cf0eb5e4e236b6546122a8dd9014975fae15863b9af14b3d5ff00b0fc757f7ac163b0787ed372c83fe5ed66fdf460f420e15f1d704135b72fc50d2ad350d6f4596313488f24df3a2989baa36012464850dd39de4f7ac6341d692aa968edff0007f1ea73285a278b7ed2167a759dc6a220bc5b86bedd7f135b9063789b702a79e4a9da48f4635f2be936a9ff0008e6afa544a99904e2300eeec5467e8dc1fa57d5bf1965bff1fe8e24b5b5d260beb5d5df4e7b880f9693c257e504b118629b31938f91fdb1e0171e0dd53c18faa5bcda1aaddc970eb717c2e14b46391f22e36fde1bb3ce4d7ab42517049bdbf43682b2767d8d5f027c546f0ff822dfecce21d6b57786349aebfd55b42630140e782a718ea0015e8be08f0fd9476b36a735e45a8de4c39904fe63c8e7925cf276e7b7e75f3378becaff004ed72cc4fc69d0940bb5b249ddcb10076e7e98aebbc192dec12dc0d3f549944d2999e5f35f6a29fe11819c818c01f9d7a1a41dd9df1aee6ad2d525a763edfbcbdd3742d0346b16b88acd4dac666867d815a3f2b7cd304eac4edd80e3821eaf5ff88208fc131c9a699afe3966101963806d78f63b9182395c0619e0e4fae6be57f875ac34fe35b2b0bed6ee45c5cc8cef797077328ce36032676a648519e82bea9d674a8b46d3acd67d4ef6717eaca3132b461dd89dea000148dc704718c63b9ae3c4f2cec92bbbff00c1f33820a536610d48c36e92cf6b1c773768f70c420c48e4148f1fece0c8d8ff0068d727e2883fb4fed164aee565b04b3631f01d4ee695988eacecc0fe2d591f13bc797da4ad9c3a7b895e227cc69d43298c164555c7230a09fa3735cbc5f19253797335ddadbac4cc5828c8dab9e3924f38e2b9a961a11779c7fab9e8c7eaf1f76a3b33d065864d3bc43a51b63e6db5b47641779f999634419c8f4c56df8df508b56b1bed2a76320fb73dc26394cb0917777f980c007deb81b6f895a45c9479a4781d42819c118edce7918adab6d634ebf977c77b14aec49c338dc7273d0fb9fd6ba6187826bc95bee3b2950c3d57784d5dff005b1f1cff00c14c6e04d0fc2f8c4b3c9e45bdec3897ee8dab6832a3df1cfad7c3f5f6dffc14ad4aafc38c8e0ff6960faffc7ad7c495f61808469e1a318edafe6cf9acc29fb2c4ce1dadf90514515de79c14514500145145001451450014514500145145001451450014514500145145001451450014514500145145001451450014514500145145001451450015fa69ff000458b1b7bd5f8ca278526da3462a1c71ff002fdffd6afccbafd20ff8238ea874c97e2d3f9cb027fc4a1d9a46c290bf6ddc0ffc00bb7fc07d01af3731ff00759e9dbf345c3e23f4eb5cb88b4fd391ad8245e73797bd546158a9da5bf1007d48af39bafecad7bc470da4f6fa7ea6ed07f687993c2a4c404918f95b3c36d2ddfaa8a4f1bea72d9ff6cdb0d58c6ef8960899b1b39664e074c3a4a33ff5cebceb4ef151b1d4ac75dfb3092c62964b523f848742c6327a704ff2af8d8518cd39a8aeb6ff0087367249d99d6f893e09f8656de73069f2d95bcf22499b1904ab900ed66575fbbf364e1bd315e7aff0e750b4d0a6b8b4b93e23ccad1078d48ba8e31d235465c851fdd52704f7eb5d8dcf8fe73612d8c774934302be9c58f3911e577fdefbd90483ea299e0ff19c3a95acf671a209de3f3f6ed049901f9f68cf7c0a9850928f345fdfaaf5d75fc41b8b39af02ead77a25dcc8f234324a8f14b15ce43c40019254e318c5759ade9b17fc23b7be22b2de6d6fa5c4a4b64361dba7ae02f5cf73eb4ff156bda16b9269cd77043e45f4696d25e22aa4d19e4633fc3c872472318abdf10f58d37c2fe0087c2f630bdcaa4223491880dbb69c3718cf7c903ad09d4e78ae5b4a4f5f45bfe8435a33e72f89963796fa74574e6dc79a4f976c18b158cee20b7b9c76f5a8fe08df68d6b71f6bbe77174b70ad1c4e80ab00571b5bd8e7e53d41f6aa3a9e9faf6a56da9ea73dcc4da65a32a85958991dcef202f6c6d46fd3d6ac4fe1b87c2fa3e937f24bfe9b7f6f15cc2b6b32bc2aa5436d9108cabfcc09238a74938d6654534b98f6fbfd12cf5ad3e25b5bc8e485671793699bfe43215ea371279cf393c761c8a5d22d6e67d42cac63b937305c931185b3b1428cac720078208e7d0723a1c72df0ab41d7fc5cb2de6d8ede0b6dacd7171b954a1ec0007270380001818af498740d4b48b4bcb88ec9adaee68becff006dc6e190ac5dc0cee19e79233c0f707a2a6221494a119de5e7ddff0057ef61c539be66b42bdc4567a0db4ba65a164b48b125ddc800991f90403de35ed9cf3d6b37c291a2ea324970d34aa216984508c9946ece093d776323d460d6a695e07bfbdb1bab2b8bf9602f248ad3496658328c6704b0fe22718ebb3daa4f0f7c377d2b58b774f102dd369b2c724f1491b2b6c18c0c6e3c0538c1af396228c29ce3ccdb7d6cf57eb6deff007688b9539364173727fb4dedee12317f70e59d27c1f2a0ddb42ae7eeb73c7a019adab4b08a6bd79bed721b9216489cae2208adf2a02792818a71fecb734b0784268bc4f757ff006ab7b8824b8dee657fde0f9882b965c0190401562f63bf5b948ffb3e511c56ceaad1c6b22a8c9015b6e791c1fae6b9a7569cad08c96de9f249ebd16c75c611e5b3286abe0d5d6eea5b48a5965640b73e6263203b30ce3d3853d3a7e15cfea3a45a2f86ed6ff53125ad845279cb6968097bb75184c290782031c76c678ad41e2c9b4d8a09a3904334e5eca6966521a250c0e319e000d81f403b563c5e31b496ec2eaf792585b41339862b65dac620c36ecfee0381f37a29c72c4d7728d64ad27eefe3d6fe5abd7c8e2972dee6668da4d9787cdc788fc4772d671c6ade53103f711f0cb0460a822eb284311f73a0c372bf1cfed2ff00137c3de3afda8345bcd1aee2b382c7451a5dbfda63596282e16696401be6e1c87da48390d81cf26bdcbf6b4f8db7be1df84177e2187479219f519ffb074e12e45adaa4b14ae6e570466e3686dac0e07071d33f9c3f6f6bb2ef24ad24ac7717624b1279249afafca70dcf175a7a3febfa472d4a9caecb63d37e21f886ff004c8f524d42ea35bb33344c1e14dde58e8e8c0e467b027d78af0fbad41aea497a88cb02abe80671fceb475e9e5bb3fbcb9966dc773f98e5b27d79ebf8d601ca301d403c115ed548fbb62a33d558b4250c0e7b5114cb0b19980761f751ba13ea7daab09416393b4539ee1ee0aeefbaabb557d07f935c918d8d673d2c8b3677ad0cdba43b95bafa8ae812643079a8c36fae6b9841915660dcaa40242fa66bd0a3376b338a51bea6a2ce85d9e46c93d876a437889928bff7d7354d573d4d3805515d3cc45899ae2598f2df854b1a63259b9aa867080f3c534cfdc1c8a7cdd0971352292300e791ef53473984ee89c83fddcf158c9313cb1e054d05c7ef97e6e847e356993ca763e1cf1ff887c2d7915f691aadce9b3a100496f2ba3039cf3b48f4afa77e1c7ed9bab788f455f0cf89deca2bf950c516ac63204995dbf31dfc49c920818c815f24247b6475cfcae3cc1f8d4b0c2b3a9da70dd48ee0fa8f7af3b1981a78a834f7ee75d0c5d5a09c632d19fa53e1ff0019c9e29d16f5246849d36d44ade48c79caa36963cfdedaa833df61cd52f0f78a269ee1b5ebe8d648a394d8cd737872ac248c853b724f0119b23a6057827c25f14dfdf780ed259e675b8b51f6473bf1e7a0418762482490c41fa1af486d5a54f0ddb69afe58862dd75c0e5a47c0193df0aa31e9b9bd6bf3995174e7ec1ec9ff005fd791deaa36b983c69ac5cdee9977031686cee1959fc925725519525ebd769ce7d49ae6afbe2fae9df0da0d1af26feda61215fb45db3b4cb91b76efcfdd013701d7827915e811782b50f107840eab710a0b586d5d3cb192595327e61c80dc49c1ec86be60f13dbcd67aa5dc5711c16de7a79f0ac719561196709b89edd7e8c411d4d7552a3efabf9ff5ff000fdcde949d99af77adda6bb25badbfda1ad158c9e6498dd9ced1c8cfcbc9c03cfad7b27c06d00586b8ed35bdcdc694f6ad21b8488644d95ced66017382c081cfeb5f33e997f79e54e6dee1e1115abe2290901994e471d09ea7a574de12f16f886cf49854eb1a9320b6052017326d2cccb8c286c7393d05762c3cf996ba763ba96229c1da48fd0cb5fd9a74896deebc6f6b64f77a8cb611982cef5c2c1bb02566f914139cecc64743cf35e0937c46d7b42d73fb3a3bc696dad2e1d8dacf9f2830620ed19f940c1c60f02bee1f85775f69fd9c3c157974ec7ccf0e594b2396f98e6da32c493dfdebe12f8b7a55d7867c7b737724904b3ea30ff6a6d8725104cf2304c1e98e062b1af4a542a34bc9ff0099e72ab292e75a1d4e98da578df558265b60192ce406d64900df2901b763f897712b8eb802b8dbff0003d9d95cc904d222c0ba7bea524ad28dcf87c2469c60923a2f1f7bad60c1e2b974b9ad1e2f251e589a367518f2db703907b1edf862bacb8d72df5d5b0b12584616d618a691c677a2903249c6c25c67d957d2b9669cfee46aea466969a8fd7fc2da6e9da6c32bda4f7d3ae9905d472b391baf6719b78485e36842a4af5c95fc59e2e86c7c376d7b6462dbab8d13ed297b6d27c91a798621336e2792c257e074f2fd0d73df1a3c64da4ebe21d3ae0b5b7f6f472da24726731c28638f700791982dcf1dba1e4631f5df1ab1d5b50bfb986def64b8d2adb4b36f27dc4219e6978ce71946007fb58ac29f3c52727aff005fd7f5aca5ca8f01fdb7755fb443e00d3cea2da8b5b5acf36f762cd89560209f73b79e057cbb5eddfb4c49737cda06a372eacf752de155031b1434780076519c01d80af11afb8c0cb9f0f197f5bb382adf9ddc28a28aee320a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800afb4bfe09c7e239b41b4f8928b1cd35bdc7f672b476fd4b85bc0bbbd176b4809f703bd7c5b5f747fc1307c1ade275f8957335fa69fa6d93e95f6997711261cdde360c119c2b75c63debcfc7cd430d293f2fcd170f88fad6d7e266a577e219f4f9a349ee6da36b4f32425da58d82ed6e4e721937023bfe35ba8e2ef43bdd3225db03dd0bf836afdd90e11900e7db8e7806bd7fc0ff000f7c05a46a3b92c24d52f9e5110bed4764adc2b380303000c31e99c9aeb26d73c33a15e1b2b6b6b58e060a716c88132777040e8768f4ee2be2d55936ed0d2f7dff00c8ddc533e75f0e78575b5fb636a1a36a52c524ee42476b2fcdca9cf2b8e77c873546cf4bd4bc35a81ba5b2bd8e4b6bdc28921646313e4ab6319c7c873dba7bd7d3373e2ab7b8d366b8876ac31bf9792bca90f839e7a11fcabcbfc5b149a94f716c6dd6d06a72db25b98bae37152777ae4f03a609aaa35e7cce124adff055ff000fc889256d0f38fed1796eaeeda6b608ab28ba8bcf52a321b207a1048c7d0d6978afc656babf85354baf2f64f146b1db2bb72092f8db83f7803fcf8aebb4bf0d4578979f6996376bab0dd1f9bb40442222cc4e30081202a41c020f5c578688ef1b58bdd323cdc5afda7c912be0c43921583b703b73903a9ade7560e565bab7f9ff00c01460fa91e83697d75a46ada7c8e7cb9edfcf11390cce158608cf7033efd7b1ad3f86de1e4f135ec326a56d717f6da329b4892261e54f30da5232187cc76272a3d473ce2b90f1441abe8a97c82de432c5f35b4c183a4c0120a065241247419afa1fe1dfc3b93c1de10f02e93179b35ecfa8c5a9de3c84b6d3b013bbdf0aaa3f1f5af36551d15dd3bbfbb5d7eefc8ea93ba48f45d2f438743d3ada116ead7800bb9a145fdd170bb76aff00b2a7a03d383535b4d79ae6a6968f119f6c41e5badac228f2704237424a938c738ce4e3839be24b7d62cf4d334703496d0dc66e41dc5dadb712fb79e4fca78f4c7e3b1e17f176976fe1cbdbb375018ad6494388082b1a46080700e71b533f8d79ca12707525ef3d7faff81f9e80f4d114bc4fada6916e969a65cadc4d0b2fda210c1e411e72ee57392c48c67a726b86d2fc5104de2e616efe6a6a317d9bcc65c334cd839c1e8b91cfd3e95c0f8df5d920d7f52b8b7ba0af732990c904a0a90c723690781ec4e32715c6378bf528f5bb0d455d04967223c7b576862ad91bb1d724724f26bdaa58254e8b51ddadfcfbfdff00d5cc1cddcf75b3f16b5e6b13c4934525bf9f1c842b67786ba93a0272461c718cfad6868da85e2ccd1dc4cc1e6fdd48f1ae046d261c6d393c0690007d8d78c693e279e29669f8cbdb18dcf2551464f9aa770fde740bf53d322bbdd17e20d9f88753bcb680c76717d85becc66c2379ab23f94a0eee48470481ce54e3a56188c2282765a68bfe09a4277676da54f0de47716ba8a0bc96352d9b90242403865c9e4720e3e959daa7c29b0d7a36be58dadaf236f37c8fbd04b81c2b71bb69e33cf43599a7ebf3695e21b6925589ceab6a27101fba923fdf8c92780ae8463b6e02b62e355bed3b4c1a842b34fa7aba82923112ed61ba35247001f973ec2b2545dff73eedecedf9aedff07a972b35a9f02ffc14675bd4f48bdf08f842eee61f21a3935afb3da8c4637968a338fef611c63a01b4038e2be3686538c86e95f41ffc143bc771f8cff68798466355d334ab7b06485c3223f99348c179381990f15f3c4588e019e38afd2303170c3c54959d8f3276e6625c5d170c1803db3599280431ee2af9dbb5b774aa533a9385181eb5d720456f98373534649a8c0cb1cfe75623502b3e54cad09631c62ae2271c74aab19c0353ab123ad6d1d096afa920f9475a8d9c9cf340e01f7a631c555c490c6383f5a4127079a52dd6a327738fad1ccc5627f30a419ee78a8d9cac41fa64d433bed9180c8a79606cc73c8a149a124753a5cbf6dd363914e658bafbad3d8986412c6783591e13bd10dc346c728c3047e35d05d41b3728fbbd41f6aeb4ee8e76accf63fd9b3c588be32b0f0f5f4a4d86aee218949e16766501790719ce3a7a57bef8f34eff00847bc4fac693bc4915a5cc90c728e03aa3b2023ea066be22f0eea52e97a843345234734122cd13ab60a48a415607b72057d989ab9f88df0d6d757187d412212cf2e725885fde8ce49ce7e6eb5f179ae1fd9e22335b3fcffe1bf167a3466a51e5ec7bff0083bc06be25f0678e3c14f713596bba7ac37b6779112a2480c201723ab2b2f381c1f37df9f9c7f6e6f8572fc30f88da15bf9ab35adde9a1637442ae56395d7e6edc8c1e0f7afb6fe0468d3eafaefc39f1a5b046b2d43c270e9f76cbfc7710950dbbd48c63939f93dabc57fe0a97a542977e02bc8c3b5c14b98594fdd080a107a75c93f90abf65caaefa9d1097bd63e24d0ac20b8b39333f932fcc06e1d415fc722b46d34cd3916144d4dfcc876aa95523041c8edea2b2f46628133f2e5b18ad3b99248f5058b68450c0631f36735d34e3a5c57f78fd87f843a6c3aa7ecffe05b59904b04be1fb1575c70ca6da30460fa8fe75f157ed41a26b56da86bfe27bf458e0b9d75ac2d176905e08959508e3a031b671fde1c735f717c0a4dbf037e1f2f5ff00890587fe93c75f3f7edd9e1dbdd4ec3c3e6ded76d841722379b770cd36f663b71fc2b0124e78de3ae78e6c7536d732feb42694b4713e29316e92dc30f9c45e693efeff0098a9ecee6e750b06b4918c784c2c8b9ce40007e9fa8a92ead0c56ba85e49b923698db400f70327ff0041fe555f42474b7473b8963c67aed1c0af9ca8f9347b7f48a8de2cc1d4aceeaffc51209d59e2494cf1b48a7700142607fb3f2a9c7a93514b79737d3ea466dab0473c9b76c7d5b731c93ec381ed5dc5f592f98b36de51786f6f4ac3874e5367778c0124acd9240e58741ef5d7ec9d55ccba9bdd6c7ce1fb4bc261d33c20ad8dca2e949c63b404fea4d785d7d09fb58406ded7c22a46093787ff004457cf75f5b858a8518c51c955de6c28a28aea310a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800afbbffe097572c90fc4cb62dfb9b89749471d7afdb0038ff8163f1af842bed5ff00826edfdc58c1f121ad97cc7ce96fb06771dad70d9007a62b831da61e5f2fcc6937b1fa6f71af69ba65b6b4a1fca324f3188a01b9408b68c72300338c5708faec57f24f25a485ae0cdb1140ed918239f4cd66eb9e23b7bc89a5596460b0346c1c6099ccab9c73ce71d78c81c818acbd0e39a293e47896e25f2c86673900b638fcebe4e9c146176f53777d8f59d22692e74a8bed1711dbdbc973e733b1c2fcc1bafd370fca8bbbfb786e8cb71a9d95cc767e408c075dfb9260d95e4f5488e0f1cb7d69de0ed363bdd0350b498b5eddc30a94861932bce5776319dc38ede95d3f803e0adbe9f7b1eabad4626b88a4df0c01b7283d8b6475f6edefdb184632938a5adfb0ace3ab38bb7f0beb51dcdbea5243e4e9b70b069e96f2655e488c2ab231c700128b83d78e82bcf3c69a3da59ebd3457513da5ab6f748ecc2ed524b18c007000c900fb57d7fab4310b5dd2db89a251d02e48e0f35f34fc4f86c2f0df49a7dd4c678ceef28a63ca604f3cf2abc8c1e9fd5d19ca3564a4b5daff00d7ea0e57dcf24d16faee4f1fe97a5dc44b1e8297d1cb74933065281b96001e0f18e7b57a6fc44f8f5e1ff06f8564f13b4974238aff00cb8228c28d988a42a07381f2e303d54d78c43789046f2dfccc6e6e1989788296049c0dd9209039ef5b37b612788fe036bfa55c450cd71aa6beda5c5730a665b769a1221657cf0048ca318e85864e6b293855a89cd3ff0080ff00cceaa704d9c97c3bfdb4bc757daac16fa85e3dde92cef1c99b705ca06da3049f9c91cfde19e79ae8b56f1d6a5a7dff00886cadaf07d92f4b06368e7ca2acd9e80f076e4753c123b9af3df03f8165f878f17f6869b6b732c3fb8fb3ca0cbd38c302010dc1ce3904f15a57d6e2dd7edd05b35b4139dc612091efc9ed9fe95d50838b938ab2f4d455651d916a0d52ea55f2e4999a32b83f3673d31fc8568da4d1dcc651d4e492cb8fe44d72ef398c79912128dc155eaa6a787516b7b577ddca30e09ff3e95ecd154ab46c713bc59f41ddfc3c813e14e93aae9c9f699279904ab6f87192a495240eaa463db9f5ac4b2f85da8cb1c0f35b4f6d1cdcc124c8e88ac7d495c676e4e7d0135e91fb34dca6bff064cbbb71b2d6d643cf2a1442cdebc105bf335edd79169daf4525af9827890fef0467e5183ca9edec47a1f7af3aa4bd8b92935bfe1ff00db47d0f987c3de1fd64693711dddbcafa769c1b50b4bcb88d91d91482501c1cef5e719ea179aeb65b8d4ae3c1da94dad4704027b457b474c821c92f10c1f412151cf017dabd73539ec35426068a66b7b60259540015f04e2320f5e9920fa0ae7bc4178a9322c96105d456d09bc8e0923caa6015552bc8046f6f418039e2bcf55e9b7682d6ff00f04dd434d4fc62fdb374e9ecff00692f16dc4b6a2ce2d45a1bd8235185f2dd38c7d3041f706bc9ae65dbb507a015f50ffc14c27373fb4268d3192d1de4f0e5ab15b30a150fda6ebe53803e61d0f5edcd7ca73cde64ccc3bb57df61a57a31f43cc9fc4c7cd2920a8f5a897a734e886e3d32690e0935d00348ea476a963e698b4e8f8a432c2f00d488401cd423a7152466ad0c941c13cd44ed92694b802a3739e45021923707b0a64646ecfa0e29b2b607ad22b6d8d8e79a416229a4dcec4d4913ff00a330aaf9ce41a557cc6c01a49e8162de93318ae95b3debd0ad596ead467938af32b57c48083debbcd06e818d0673c62baa83e68b473d45a8e9a130cd91c035f41fecddf106016973e16bf996313e5a26738dd9014af27af4e3dabc36e20120c8ef4db0ba9f4cba86eada4686785c32baf0410723f95638cc37d629d96eb55ea2a72e591fba5fb30e8fa4c5f05fc2674e7f356da260771dc6398e04c07a65c3363fdaf7af9bbfe0a8f0adb69be07bc3f689199eea2545398d4e10e71fde3cf3e80574dff04dcf8f317c46f01ddf856e9a25d4f4902601701e453b43b119e46e2bcffb4476ad5ff828cf87f4abdf865a1eadaa999a3d32fddd22470a921689c956c82493b3031ea6bc7a91fddad353d0a4fdf3f32b4d9b73afca5087ddcd6b98c4d31b8932ec18608fe751786347d47c5dabeab268da4cf2436b1bdecf1dbc65c41003cbb6d1f2a8c8193c0af45d1be05f8df5ad256fa2d284366d089d249598174dbbba004e48e4714e092b5cdd425293e55b1faadf0172ff00033e1d93d4f87ec0f3ff005ed1d711fb5c5a35d7c318d61556b86bc5542c338cc5283fa5777f026268be08fc3f8df864d06c14fe16f18ae67f69a50fe07b207fe7fd7ff454b457d2073d2579a47e7678f2dbfb12d34cd1866493cb33ccfea72c33f8ee239fee8e6b17479c341b547ccbfb91f5c0271fcabd0be2fe89245a54dad3f11465602474392c42f4e49249c7a035e71a20f292307aaa991bfde27ffd75f1d8bb42a6ff00d7f5a9d2d6ace92450b629bff898a73f43ff00d7ac2b3d3e4657b5568936ce30f2ae4636f1dab76428fa7046ea083f8e0d50bad2ee2f60b216f0bc8c6e537ec524e307ae3ebdebbb03277717b6ff00a1495d687ce9fb5f589ff8477c0da8b101a6bad4ad8a8503fd5ada1cfe3e657cd15f59fedaf61f62f02f803f76f1675bd742aba907608b4cdbd7b60d7c995f5f4fe1471cf56145145684051451400514514005145140051451400514514005145140051451400514514005145140051451400514514005145140051451400514514005145140057da5ff0004e3b3d6a7b3f8973690a9279234e3326409003f6ac3a1eaacb8386e80900820e0fc5b5f5bfec11e25b8f0b5b78f6f2267489a4d391da166593a5d11b48e09c293b49c90091d38e0c72e6c3497a7e68d695f9958faaacbc4a75dbbb8c4921fb3cb231c8ff5655ba480746c75c75edd715d8fc3cd1357f176bf6e90adca191c431c6232ce17822460388972c0927900fdd3d2b9386eaf752f1ae9367a52dbde4ba9aa89a0c6e6cf9800765c770fd7d56bec9f86da37873c0da3082c1e2376b099ae6e06dde40da188efb32060f43eb5f1d8baea97ee96affafebb9b25d4ea3c1be0a87c2ba7c788add6fbc958659615c020756c919249e493e838aea04d1c11e0baa81d0b1ea7fc6a8e957f0eada7f9f14ab2a4a3a839c6474fd6b87f146b17f67652405a2bb68a42720ed31c63eeb96ce54839cb608071583af3a36e4dd936bee47e32f88d7967ab5c5ae9f3c13db5b046b854dfe6c7f31dcc31c1503afa739e2bcefc41afd86bd62daa43e45d10a2de64f28a4877b4857a8c3a944391c8e78ef9e13e29f8b120d7edb5c8e7f244f0b2eeb7750db8333c649cf12ecc020673b4e338c57953f8de7b9b9bbbcb4ba797ece9e6b463ee9608a00c67fdb231d3838c55b7eeaa93f89ff4ee24ba06bd6d6fa77882f43287b3795820419c0dc785cf6c7a8af5df849a1e83a87c32f19c90a89641225f465dd73134458a385dbf2b2fad7cd7acf8ba6bb752a8235dd9058f739c8ebc7b57d15fb267d9affe1c78f2291c3dd5c79c1a4524854f2f0bb8f40c4e7be4fa715e7e22708479ada26bf347453ba563075e9e19ae5e6bfb59646b8ba674ba28a11d1b832640009c83e8093edcf2be30b3beb23690dd426f85d439b124962b1f383c13851ce14719eb9c62bb6b3b9369a95bcda859b6a5630831476f38629b8638071d813f2f2327a76aa3e228e486ca2bb8a3ba8e7810c36826933e586e8a4e3eee3774f7f7af7d5d7bbd099c6f7679beafa249e1cb9b6b79678269a481277489b3e5ee27e47e98718e476c8ef9c43f658e68cfc80a1ea3d2ae6bb67334a85e43713aae66939eb924fea7f5aad6790fb1ba819603d2b55cd4df344e4beb667d05fb37eaf0e81f0bfc7364d3458446bb8637c7ccc62236f5e7ee2f1ef5ea5aaf8aeff4ef045a6a1a5fd896daeed4cce36ba9f35b39da41ea33d0fe7c57cd7f0ef55bcf0f5cead6a228e5b3bcd3e5f312404e38dc8ebcf041039f735ee7e0a9d7c41f0d67d367dcf73611add45e572c5768cafe1c66bc7c5d552afcef64d5ff002fcff03b21f09d3f85f546f155e36a96f751cf611f98d2c3ce46e6661bd791b82e073c718a778bf4eb9d665b04b41e72b88e57806e5df192dc391d7818031ef9e05791787fc54fe01d7efcb4927f65ea1ba3ba8c9e2356e378030378fc8e48e2be83f029b7d5f4cd2af2dee23bb8bec910692360d87017e5247704b6476cd674bdd9da3d36fc4d3995aecfc90ff829de94fa47ed03a3c0d6ed06df0f43872302502eeeb0dd0738c03ee0d7c8a06457df1ff0587d1cdafc66f05ea2000971a0b5b0f5cc771231ff00d1a2be055383d6bf44c2dfd8c533cd9eb26d1603f950ed0796a8f38e0f5c5110decee4fca833fe02981b7649eb5d48cc951bad3d4f2455724ab641c54a187ad1b0cb11b6322a456ca9f4aac0fa54893610a914efd8b8a8bbf30e2dd6a372474a4ddd691db233d69dc8b8c639e29929db0e053f70247ad45747b669740235e84fad461bef0a71200e0d405bef545f41935b9e47bd755a15d6cd8b9f6ae4606c56de993ec65e78ad284ad2b1138dd1e81049e6460139cf7a47879f6ef54b4e9c9814fde1deb5c012460f5c8af551ca7a37ecc9f1c750fd9f3e31e8be28b791ce98585b6a76c83267b56743228059416c2e573c6e02bf43bfe0a09e2bd27e20feca9e15f1268d7827d2b53d5ad6e6095482591adae1b6903386e808ec411d457e513a6508e8457a7689f1b3c4179f08adfe165eca977a1c3aaaeaf6524a58cb0c82268cc2b96da233bcb6d03ef1639e4d7958ca2f95ca28eda125269367d39ff04ced3f4cd6fe3578b34bd4ec20bf825f0ec84c57312c91b017300390d9cfde15fa4b0fc3cf0ed9d83d95b695059da3aed68ad4792a46318c2e38c003e95f9cbff04cc225fda2f5d70821957c353aca98007fc7d5af41f515fa76c735c1492e4d4e8acfdf762a69ba75b691a7db5859c2b6f696b1ac30c4bd11146d551ec0015c2fc60f0ec7e2cb5d0349966304773a9aab48a3240f2663c57a26315caf8b5776b1e15e01c6a79ffc81353a8b9a363183b3ba3c6be2b7ecc9e18b8f87f756d2b6af7a96cc6f8c70ba1791911f0aa366324b0e0f27a0af89af7e1fea9e1886ea5d4ad5ad545d343b1b24ab64e0138e98538f5c57eb11852688a48a194f622be7ff00da37e0fdbf88a3f0f47616ef1adcead0c37622c0548199cc93118e4a83c13c2a96ed9af0f1f848b5cc91d34ea292b4b73e55f833e07d33c67e29d4a0d6e69adec34dd2e4d518c21092226438218104104f15f5fe89fb21784746b63047349750197cd097b63653b0240046f780b638e808033f535e27fb35e85a5f8a7e3af8faca00468b77a5dfdbc262c02b03dc46ab8c83fc0dc57da7e1b86e2df40d3a2bb90cd751db469348c7259c280c49fae6bbb014a3ec9368ce7269d91f923ff0590f86fa47c39b5f8456fa3c2b6f15ecfad5c491471a468ac23d353e555000c84c9f726bf35ebf553fe0ba3ff344bfee37ff00b615f9575eba5656310a28a298051451400514514005145140051451400514514005145140051451400514514005145140051451400514514005145140051451400514514005145140057d0dfb30ebc9a7780be23583db79af7b369a629c1c1864517783f8876f7e07be7e79af74fd9b2479f42f185925b33e66b1ba7b807889505cae08c77328e7fd9f7ae5c4d9d195f6ff00827660e2a55a29f9fe4cfd06fd9734d82f3c2ba7eaa6c1aeefede236e51a3670e446073b79004814b1cf4ec4919fa5ee247b5f879aadeb86fb55e8449a6270d196049894ff000c6a4e02e7039f524fcb9fb1eeb2961e15d6e1b9b9882c1333869ce4c49847dcbead90422f762be95f47ff006e36aff0e75686284ac31b828ef8c85ddb46e20904f52c7d79af81c6d392ae9f44e3f9ff009ffc1e8554f75b5ea74ff0fbc550e8da2da5bac9e6292ad23c848c4780091ea7bfd2a2f1b6b1636973aadbdbcb67299a27bc0cdea001347d7192801c75f9b2783cf96d9f88b315aab4edfbb5103c519c92a327701dfb7e55ce7c4af18dd2e8ba45fc7246d3e9d761258621b84f8520338ce76491f04f7f2c7a5455a135352df7ff003febb98d395f43cc3e315fa3dd5d2429279315d09612edf32c0dbf68c038c723a0fe75e7de1cd402f86f54b9c8490ca57047cc70198f19e461d2b77c717fe66a72a998dd1951a305db3f2b12d111cf0002463b000579e5f5cbe8da3e99079ec1aeae99ee63c72899e4e3ae362ad76544a766ba7fc3137e5b97af2f239e37c32f09f3807827a9c7e6057d3bfb237886d13c3771a6456a9209ce6ea62a330a6179271ee49cf4af998d9c7aae897baa69d1912c71e2ee16e88482eeebe9b4b6cf5054039efeb1fb31decd04d6705acb25b7da5c24922c8483903716c77e9c1fe1cfaf1c35a929c1c25b34ff000d4de93d4f51b8d3f7de5d5b493792caceee8e0796a41396f6e9d7ad60dfea86ed7122c5710db5b920e70b8539c839e188f9467bb74e6bd1b4ed26cbc4d71ab0bbb8f2f74ed1ac92a8da47279cf42720f1cfcd5c1f8fb4883c31a4de5ae92934f3c464f3e29635cac4324153fc4091907a0f97b9e3d18564ef17bfa1d2e0f94e46ee22348967923779c8691b63601c8caa8079c1241e7af1ef58da2e8cf0126e95c4b2b951ce4062738cfb6eaeaf4ed7746d4741d2f49b48669753ba996faeee648942a2eddab086dc4ed5c6718ea3e94c5be3278ba308b1b5ba23c7f733b59882d260f0303bfa8f6ab55acb99f438251b31fe1b94ff00a60918968e02898192fc80179ec739c0f4aed3c11e2bbbd3f588e1b6959125436cc8c32850e33b8571ba3b431eafa94b0dc2c315942fb9d9b1994e70bf500814b16aeba4dabdc00e97f3a9302e705573c3fb7233f53df15e3569b9569a5b7f573686c8eab5fd463b817da598505f3653cc6e1579e84f6e7f0abfe13f1d7887e0edfc32ce934f6b22877b5f9bca951b043a74193b480e323af5ae65ae60b4822f2ae7cebc923dd732b9c8dc721c31eed9e4b67183dfa56eea9a9e9f79a6e909a90b9bc925b28e180e9d289a3d832029258fce33ca0c0078da38274a14a4e7ed23a31dd6a9ec7c79ff000538f8d7a57c63f1af8526d2f4cd5b4e5d2eda7b695b53b75896566656dd11566dca3a678e7b57c5c0649afa6bfe0a07abcf7df15743b4934e4d2a1b1d122821b70a55ca89ee32d267ab9ee703a74af98e25f35d57b773ed5fa2e15b7462e5bd8e295aeec5827cbb455e72e777e1d07f5a895bda8b894492b1eaa3e55fa0e95121e6ba4943dce08a58dba8a69fbb9a54e8698d13ab7029e1b19e6a143c53c50896485811da9991cd21e06681f303ed5402670e2a3b91f37b62a555e699709b973e949ec08ad9f96abc86a53c02075a81f3cd649e85124470a2b4ed24da73dab2e2ef57adcf4f6a20ecee0765a1de03b54f15d35a91b767e22bcf34dba314bc1aecb4cd444ca0672c057ad4a5cd139271b334641b587e4698b989c143b5d486561d8d3dd83291d411daa049704a9eabdffad6d6524d32168ee7dd7ff04a6b692fbe37789f55662fb3c3ef0c8c493f335cc0dffb21afd4715f8adfb09fc7a8fe05fc7ed365d4a609e1df1020d22fdde4091c1be4431dc312c1404603731e88cf5fb46932ba06460cac3208e722bc29d3f66f94ef93e6f787776ae7bc46b9d53c3876eec5f1edd3f732f35bdbf19ac0f11c98d4fc3fcf1f6ee7fefccb5954dbee14773a08c75acdf16476d2786754fb5ca6dedc5aca649d7ef44bb183329ec40cd682303d2b37c537d69a6f86755bbbe01ec6deda49a742a0878d54965c1e0e4023f1a55edeca4fc823bdcf947f62db1127c54f155dc31ecb58ec9e345cf40d32151f92d7d991a85181c0af95ff00621b5f39fc6faab445565b986146c607f1b30fc372d7d4aae7079153844952454be267e587fc1747fe6897fdc6ff00f6c2bf2aebf54bfe0b9ed9ff008527cffd06ff00f6c2bf2b6bb090a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800afa0ff0063db9b64d67c4d6572094d4ad62b25391c396665ebee807e35f3e57b57ecd375fd9d79acea0b12cb2d94b6972ab200d19dad21c38eea4edc8f4cd726295e8bf97e66b4aaba33535fd5f43ecad121b9f0af84e57d2ad1c5fc179be59d9b11b47b3001e4676b90d8f415f587c08d26e75df0b6b316a2256f2edfeccd0499011b60c9c11f7f93938ed5e39e1cf899e2ff00897e0abdd1749d0edad34892dc096d2c6d162565da1d2527079284743fc078e2be97f837617fa4784246d66c21d3b53d5a7651e492d97119cb3658f7463fd2be4331a559d35caaeefd3d57a1bf3a9b72678d7c5f48bc03a959490a1b7924b4592dca70934c8cdbe1e7192cbc01d492bf4af0df1a78c56f88bcb699cdcb854646276b4792ca719e48248f6181eb5f44fed71e13d55fe103eaea6096fb4abc8efe17191c0ddbd47af214e3fba09fe1af87f5ad5de4d421b88a52d69783cf5527fd54bfc51819e072081ef59538558abcf7ff0087febee3384941ea745ab5ddc4e5bcf760f1279718efdda33fa3afe02b9ed724136a11dfcf0b3c10c11db48aca4801c0667ebd366f07f0f5e3a29f17da1aea10a62e60611ca1780be848f66c75e80bd739e2fbc32db8b78df2b3d92bec41f75b0c307d063b7be7bd5ab24999bea749e0ed51e55b6541b649a469e7b5d9838c891c30c9cab315033c618035ea3f0ee687c35a9cd7b673c366d207696dd4e2246c9de00c82a0f45ef861f5af0df05ea70adbb6a2b34d15e59c2b66123058ba005db8fef798cb8ff662f635d0780f5d7f147c46d3741b59bec62f2f97cfbc99be558236c33123a82c58027b2a74c56338bbb6d5ec6941ddd8fb16392f340f103ac886e0dedb2ea93c70fccae5b2182e0e19320e39e47423ad647892d2d7c5d6b15d69737917d249fe936aeff3a0da73f2e4e220013c9c003078c132dc7881a6d6f48b9bb60b73127d91972a83ca0461540fbbc1e06302b07c41770dacda96a768641040c5e2b945db716ce0b70ce390793c7dd3fad67463356b7c56f93feb47d0f4e5b5ae7905e5e4be14d4a716c76c92164c9ce02723e5c56be8ba9bb787f54d6e195e5b879574e862279f3181667fa633df240c639e7a9d67e1b2f892df4abbb7bcf2e5bfb38a5592703ca4661164b9c7196986319eb5e133df5c699e21f23ed1225a40c1e293eea481e575df8ffb6479f715a3837ac5e9fd7fc17f71c75212869247a2586a074792d6c6564ba513fdb2ef2d9f35ce3009cf71827df3572f6fa4b88dae6590f9b34870b9e117938f61cf4ae4bc2d0cda8cefa95d1670ecde5a9e176e708d8f7001fc4d74b03812076025f2e4e011953ff013d6b686154d5fe4737335a0c91ae2e2289ae6e0c76e1b2a8b9556cfb77feb5efbf0e7e1bea4fe025b88f4cb8b63231916508e2e241b06d58c152150e7248ebd3a74e13e0e7c3e7f1878cac0dc59cda85a5aaacec88bfba04302a92b30c2a9ef80491d01edf52f89f579ec345108d463827194b986101595421c98c641da08073c9c13c8edcb894a8c9421bff5dbfafd37a69b5a9f913ff051df0bea5e19f8cda425fc689e668b1aaec97ccc30b89c9563d0380ca48f707bf3f2bac9e4c5c7de231f857da3ff000528f105836a9e15d05b4e4b6d66d85c5dbdc265fcd85df6ab176f998928d9e83e4ce066be253264f15f718393961e2e5bff005e6ff338e6ad268954f14a8704545bf8a729c62bb3a88b18fdd8a45e0d4919cc23db8a632e055b44a1c1b029ead9fc2a356cd3d79a100e269c3eed47f4a914640aa1005c9348c320834b8009a73734fa0fa19f2260915095cd5c9475355997835cfb6c50c4e455989aaba8c601a950803fc292d1817609769ce715bda2ea1b6e2305b009c572f1cf838ed572d27dae0a9e8735d74e7cac892ba3d2d3a0c7e144d1ff00cb45193d0d63e91ae2cd12c53939ecd5b6ac1d7e52067f5af453bea7290c6ed2388c8c46475c721abf5e7fe09e5fb469f8b5f09edfc2fadde41ff095786634b4f2c39325d59a24691ce433125b3f2b11c67078dd5f91d1db293d769af4ff00805f18fc45f027c7c3c4de1896d5b5036935ac96f7a8cd0ce8d83b595594fde453d7a815c789a69c1c97437a536fdc67ee5cd72b102cc703b9ac1f10cc1aff00402a411f6e1ffa2a4ac0f83de32bbf88bf077c1fe27d61208aff0058d32def674b75223491e25621771240cb1c649fad711f1a3c6775f07e4d1fc412adc6a3e1e1a8079e25f99e2631b001096000c0638c633dc640af9faf51a563a6115adcf764933c5795fed05ae6a13e8167e14d194c97fae5c25adc1446261b66dc1dc91f77270327a8dde871e552ff00c1473e13e9b8fed4875fd354b04324b651ba839ff625638fc2bb5d3bf6a8f839e3085752b4f1be9f14d15ab4a89a91fb2aa64039265006474c82782def5c75711cf4ec6b4e9b8caf25a1a1fb27f8724f0bf853c5369206213c41731a4847122a244991c72372b0fa835ede5862bcb7e1b7c4ff00015b784f4bb2b6f1b786ef2e7caf3266b3d52dd95e673ba46187e773b31cfbd7a4c3751cd1ac9148af1b00cacac08607a115d3471108a48ca4af26cfcb9ff82e51cffc294ffb8dff00ed857e58d7ea5ffc1719b77fc295ff00b8dffed857e5a57ab0929c7991014514558051451400514514005145140051451400514514005145140051451400514514005145140051451400514514005145140051451400514514005145140057ae7c009258ff00b7c401da4710a6d4049208941181f85791d7d2bfb18dcc90c9e2e8e284caf21b303040c7fafee48c563563cf0711c63cef94f72f863f10bc65e0eb4b716f657b931f92ecd0498112ee0b8078cec9665e78c6c1d8e7db3fe170f8a753d390cbaddfd9fcef2082395a2085b71380ad81f7d863d38af38b9babe8cf9780ae7b091587a7504d3629ef26e84a301cf2715c9185ba9bfb14b73b09f56b6f10432c1e20d46f6ea295191a444f39f904606f71ea7bd793d9fc2c8209c4afa8dd8314be644632a3183952720f35d76eb88622679c4608ce5891551fc41a4d8a97bcd6ec90a8ced79d777e40e694a8c27f1ea6d1827f0a117c3f0adcde4866b86177198a48db6ecc7a80075e4e0fbd65ea7f0fec2fde373777892c5188d30ea4607a8c7354751f8afa25b4cc21b917311c8dd1a372dce3af6f7ac27f8cc119960b1329038673b79e7dcfb566e8d1dac8d561aa35f093ddfc35d72c2de33a3ddc2ccaa1a5667757770490dd08ea4fbf3f9c7f0c340d6f44f1b09355b0bab548ed7ca8a7dbba35f9863e61c7627afbf7aa07e316a922487c88a2c8e0004ff5159775f1835eb789825c862fc7fabfbbf91ae5a986a6d3e4d0d23839a7a1f5bdff008c6c21f0cd85958d918e581d5e5bd99b7bc8fb483c81c2e4f03d875eb593e27d4a6d43c2f7d7561a8e9505dcb09592d85e15693d8c7b7939c77ed5e6df0cfc6771e2bf093ade246d731c9813018e300f52703b8e057a06b3a4d9cfe158b51b8b8b286de3f3f7c47f7b2622b496738dc7827cbc0e9cfe19f9fd54f956893fd7b92e9cf99c5ee6f685e39ba93e0cf82aeef6248ccda423b8049568e25b4724e7a64c4d91f5e6bc7eef4dd435fbeb1d6ae2348ece3b4b6b6658e3280b2a06dbff007d3bb119ea6b53c29accde27f09e83e1dd32c3509a76d26ea0882c6c517cc47030a49180307e51db233815eb5ad68165a0fc3d8f4a92d60b7963024b9bfb9daccf2952a6387e519fe2c13f8f214d76468ae551feba9d15d7345c91e7ba4162241b55a34753b01ca8201c0248c600078f7ef4cb3d521bbd4469da7bfdaa662230d12872cc782b1807ae71c9e39fcb1218aff549a1d163bd16161797088f24ae555be6c6e623f8402493e808e7383ea7f01be1e5a6a5e3e4536fbec6c9bcd5b92a00b928c36a8247dc6607a75c1c739adab4b92368fccf2a9c5ce47d3df093c30ff0f3e1cd8c0ead6971792249759c33a48ea8a4671d46067ef60e6b23e22e9eba65e5c4f1dd15d4ada0f32dc5cca312a2e77af3c92431e075db8f5abbad78eecde4bfb34b98e34b389a1d91b2a1f3790db413c91901467ef86cf426b9ed7567be8ed6f6f41b9d5440167b7de182c4006247392a181427fbcec39c8af97a7525f58736f4dbfaf2efebf33d38c34763f273f6e5d7f51d4be3dded8dfdda5dc5a5595bd9db796a4797190d2956c93f3069181c7b57cff1b641afa43fe0a0be1d8bc3dfb43def94cbfe97a7c174d1eef9e225a440ae3036b6101c1e4022be6d4afd370f2e6a516bb23c79ab49a26072b4e4a62f20d394e456e417ecc86dc84f079144a8573e9556190a3023ad680d932e477ad63aab11b15578ef4f1c02291e3284fa52a9000a8b58ae8390e054ab51af34f1c55224729c83c509839f4a629e4e29f19e698caecbf7855764cf18c55b71f33540cbcd458a2258f70f714850a9f98107deac22e08cf4afaf3e1b7c08f0e78d3f62fbcd4b51d3117c4126b714d69aaa4404d0c383114df8c942dced3c6403c5655651a6af234a7073bd8f8e8939a96ddb6b7d6ba8f1dfc33d63c0970ed751fda34fdfb12fe0563116cb6149c603e0676e7e99ae522e3ad1197544b8b5a3376c6720020d74363aac888158e4763deb90b498a1ebc56d595c6e20719af46954ba39a513a88b502ca0e79a962d4a48dd5d1b0e841047635868ed8c83f9559899c8e9d7d6ba2ee4ac64bdd773f583f620fdacfc1ff113e18687f0e754bc5d0bc59a4d9a584504b388d2f9142c68d0b6e04b9e32839ce48e3a59fdab2eb5ff00067816d74cbaf3759f0ddcdd2bc970e64964866292af96acc4ed8c2f21589619e0b60d7e55e857b77a2ea76ba8d9dccb65796ceb2c53c12147460720860410410083ed5f5cf847f6ae7f8a5e06b3f07f8aef641e2bb79545adfdc498b4d4a358f62adc02e73739381201965ebc8e7e6f1583952973ad51e8539aa89a5b9e51e3fd2e2d52c1bc9b9592d649008a7523e57e4aa3ff00b5583ad473d878725b7e11c5aec3b598670a41fad7a178c7c2b63796da8cf0c2da6dd0e2e34f9322376dc70e981c367eebe3f3e95c77d89752d1a6d3a59dfcb914c70cf2f1242d8c059b8e87b30e0e2b8941277e8546a4a0ecf63acd2750d2f43f0269924b716e254b18db644033e7cb0707deb8ff0005fc4ff12e87a038d0fc4bac695aa7dba52f25a5ec917ee8aafcb9460719038e951c5e11d6b498ad2daf2c5ef6dd140ff46915cba8e3e519c8e9dc550f0969b2e8535d9d5b41bd10bccc6361be2239183bb00118a52a6b9363a22eeec989fb617887c41e31f84ff0a35df11788b53d7eea4bfd66d11b50b97996358e0d318ecde4904b4ad9f5c2f1c57ca95f5ffed97a13693fb3d7c06bb117936daadef886f6dd0c9bd847b74d8fe63ebba36fc315f2057af878a8d28a4724dde4c28a28adc80a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800af75fd97bc4965e1dff00849deed6e247905b08d2020038f3b3924fb8fd6bc2abd4be0726e3ad7b791ffb52b1ab2e583675e120aa568c5ff5a33e8c9be2ccf0822cb4f8a34c63f7e4bb1f7ea2b1afbe236bf7a1996f8db2b0c15b75db8fa1ea2b9cc139ef4c6dc9923f23d2bcd7524cfa58e169c7644b79acea37cfbae6f6e2e0f7324acdfccd67b32997279c9ef52b36ecfae7bd40e36939ed4b99976501e015b9c0036e71c8e29b2c9b4346927cdd78aab75a98b384921cae7aa8191efc9ae7e0f192c976e1c054ce010304fd79ad124d1c93af676474f6d7eb828ec37f4db9e6a2b8dd1ca7cdcc4a7a16e2a3d1ac078a6fe1b6d3a58daf9cfc9134aa858e7a0c9e4927a56df88be1cf8b3c3d6cd26afe1cd5e1b70389e5b776880e7a3636feb4fd9b6851acafb9ea7fb395e19351bbb00cb247240665539c6432e7183d704d6afc77f88f3f86f4678f4eb888cb6f7a88d03fde4056f22913d76ed71dfb826bc93e17f8924d0af196d58090a18c2b9c101b0182f239c6703d6a6f1b6b773e3ef0bdd6a2d6e64bd44916e3ecf116cc8af03062464e3696e4fbfe3e27b09c6bca4d68716326a3276dec7a4fc07f1ddc45e20bdf146aab7170b6f03a59dbc73797106c863bb9ced00e323b646475af40f19fc48d67c6474a82362e8f30325a4ccc91aaa891f722838db9206e3827710001d7c2fe1ac8e34ed22c6d665dcd14f7128998848caba03bbd7191f2d7493f8a6e6f3c5aba5584b8b6b0d3659ef6f973f78b84dc0e7018047c67a0edc577d08cacf9b53cd95494a295cebb53d6654d65ad30b3490dbaa428e4e3ed32310aa71d100e76f60c3f1fa4fc15692782fc0919b2b989358b8857ed77d712f95325a851916a0f3863f22c9ddce1470597e67fd9ef43d3fc47e286d4f568ae1345b457d72f350bd711872cc16241b83799fba19d9d589183826bdeadb5f9bc748b737f6bfd9de19827fb4b4775018ee9eca1fdd4417002ae41daa8a7065339038503c4cc311ef382d97f563ae8d37cbccf73d0b4cbc58616f136a0d72b62b281676930f3127206e70a71fea56167556391feb1f8ce0e478d3c776bf043c05aff008d35abb82fb51834e9aef4cb2bd941495fcb67b7721995b619a360a3ef66653f789c67e8de29bfd5b52d3ef96ca3b9bb2cb6da1f8763051c2025a39644070d6c014dd274668c60855cd784ff00c146f5db0d07e09269371aa2ea3e30d575880decf0ca3c916ca93936f0a96de638e4440485c0214120fca3c7cb28fb6c4f2c95eef5f97e9fe7a797455972c1b3e00f8bdf14759f8c9f10b5af18ebf324ba96a93b4ad1c4a563857276c6809242a8381924fa92726b918c9da29a4f071d29501afd42292d11e25efb9306a783512e6a50b8e95402a1e6ae5b6248d909f98720d52c1a9eda428e1bb77a71d192d16a1933fbb939f4344b114e474a75c422451227e94b0cea53649d7d6b4f527d08a16e48a90fb734c78c29c8e45489f32d248a183209e7f2a740d9734c653d3bd229c30f6a00b05339351320153c243704f5a6c89b5883da802148f7363bd7ea2f867c33fd9ffb1d6930c11884ae85a65e48aab804b4d012df53e675f7afcdaf0178725f17f8d342d0e0e25d4afa1b453e85e455cfeb5fb75f0d3e18e8da92af82eea113e996da4c30a45211b5c5bcd018c30c72a4c633ec4e315e46367efc207a5878da8ce6cf8afe10c3e0ef8809e28f0cebd026a16b0cf2a496d246ac582b95de030e1b2461bb76af29fda97fe09fbe24f8496773e30f065acbaef834c22ea5b45632dfe9b115776799153fd4a818f333c7f162bec45fd92b4df0bebda8eb7e1a5bf4d461f37fb7ac4c8762c9896569901ff9665e218e012b2281cd7a4ea7f0a7c789e13f11b68ba843e2bb2d4b4c9747b889436e48a58518344bb86e555638e73f370a6bcca51ab4b12dd393707ad8deaba752167a347e1f46db4fa1abd6775e5b824f15f64fed25fb03eb1e0ef830ff0012746d2ee61bcd3ae5e3d674afb3cb1ecb609bd6e555e353f29dc1ce4afdd20f0d5f13ab1538afa58c9c753c9942da33aeb5b90e09c8c11566da726420e31ef5ccd86a02242189ad14bc320e39c8ed5e942699c8e2ceaa24dec15cec03b9ad5b3b249c8fb3ca0ca9860d1b6194f623b8fad72d617971346ab212c00c02474ad8d32ea3b2943b4814e31bba56fa3ba665aad51eeba4dfddf887e166a9797570da8eb7a6bc50a89be6796324753f789e0f7f4ef551239cac4b2c4df6e58559e166cbc89dd46efbe9fec9e73dc5721e18f153698b3daa84b987500a8159f0a5c1cae4f4c7d7d6ba5b8f145dc57d1dbdf698d2b2c619632c55a33eaa5476ec6be6abd2f65369ec772973aba3a4b5b8b2d5208b4f6965b6ba550d1175293427b641e76678febdeb9cbaf13ebde0cd5cdb6a3732b2e3e493cbde922e7b3123d3a55eb5d7add20fdedb47275647521994f195f40ff40339fc2aed86a9a678b6cffb335389882c5609640158301d8f66ae4bab6e5529b83b49682ffc141af1b51fd9bff65eba618335aebb2636ede0c964471f422be15afb5ff6f9f1468baa7c10fd9eb41d32e1a4baf0fc3abd9ddc52e03ab116055f009f95be6c138c90de95f1457ab4fe040f70a28a2b41051451400514514005145140051451400514514005145140051451400514514005145140051451400514514005145140051451400514514005145140057a9fc0c2036b43feb87fed4af2caf51f81c7126b23d7c9ff00da95cd88d293f97e677e015f111f9fe4cf55ebe82a37ef8a97919a610306bc8d8fac4559075aaee98cf26ad30ebd39a819722ac9b68636a01bcb6e770f4c571eda1c935cb98f0bb8e79cd77d2c1b81e32a6ab0b45520e2a94ec714b0eaa4ae7152e8fa958b2ba2be5790f11248f7af45f04fed41f127c0a8b6a75b9359d3c0d86cf58df709b781b465b20607407155c47b978acebbd26deed5d65897775c81835d11ab639aa60ee7b168bf1fbe1478cd045e32f0745a3df4a79bed22de3550dfdee5832f249c8e460735af0fc23f0af881def3e1df8fdd45c3acd7163f6c5dccb9f99768c30c8f5279ed5f35dcf82da739b571b8ff000c9c7ea0561c6756d0af1dada49a09a0392f0b302b83d723f9d6ca509ad4f2ab50707ef1f45cbf0fbc67e11f114924d62d369911ba747b7776055e40e0328c3670a3a771dcd467c57650c17e751d3e7b2b7d460b2d2ae628cf9422de1de41b8904612563839fba33efe71e14fda87c6fe194104f7d1eb16c3ac7a92b4bf8e7766bd26c7f68cf87de39b35b2f176822d6590f32244af0862bb4b0c9dca70c791d077a87422fe138f925166fe9daaade5fea9a1dd7da349d0dad26f10ac33dced3044310c11367efcc2308021c6642a78526bdf34ff12c9e28d17c3ba04305e5d69c2189d219d805babdfb91ab1ce52d22c36230338e490cc4af94782fc3fe04d6eff56d4b4ed6935f6d4ad9e3303dcc5318599b7ab0561b948e1339dc132a3b11ea317890785f41b28934f9aeef2d088a3d49999a78630a4858e3dc7856f983f2724f1cd7ce66186ab2b250bafeb53d1a338f2f2b65d9bc4d7be0db9d5527985dea53956bcb9b290a4c908dc1ada104e62b71820465410766e03ee8fcff00fdac3e22cdf11be2899e43088f4cb18b4d8a387766358da4243962417dcc73b7e5c6000315f4ff008c3c61a16b1a66b7e29d66ea6b78e18e589dae8859ae250acce83cc03ef367818249c678af81f50ba9353d42eaea53f3cd23487a9e4927b927f5af5b2cc2fb0839496acc311579b429edc74a7aafcc07b53f682a6942e0823d2bda47188a7152a9c8a8c0c034fc114d012850693694a48c1e6a453c734fa0172ce61b7637e14b3dbed2594645558db63641abd14c245c1e2b45692b11b6c550e41229ca41e0d49241d4819a8802a7a62959a1ad478039a073ed8a236ec69f81ce2801b9c1a9e43e6c41fb8e0d4256880ed7209c0279a011f477ec2df0cd3c73f1961d4ae73f67f0dda9d5ca8fe3759a248c671fde9037fc02bf59fe0adcbdcfc4d9198f1fd9d2a000f6f363af8c3fe09b1e03d37fe1457c4af18085ceaa6f23d3564cfc821558a52077ce5b27b702bebef81b7022f88d0024666b5913f556ff00d96bc1acef886df43d88d9616491efebe1ab0fedabad57cb3f69b9b616b3271b1d03123231d7e6233e9585f0c744bbf0e5a6bb61730f950c7a938b53ce1adc4512c7827ae1542f1dd48ed5d8a719ed4ac7835e9528453e6479577b185e34f0be9de36f0a6b1e1ed5a0175a66a9692d95cc47f8a39119187e218d7f3bff00b467c26baf821f1b7c63e0d9ed6e6dad74fd4265b07bb1f3cf69e638825ce006dc801c818ce7a62bfa367efe95f9f9ff000564fd9e2d7c71e01d2bc7da358799e2cd36e56c5f613bae2d0a4f298c000ee65700a8ff0069c7522b59494771c75ba3f22636c30cd5d86f8c2c360e6ab6a1a5df691726df50b39ec67c67cab88da36c648e8403d8d36138208e95ac24435dcddb5d56e0ab066073d3daae5abbcf280cfbb3ce3b561c52e09abf637e219376ddfc715df099cb289dd69b2083c9e7ee91b7dabd8f56d5e0b8b6b487568365bdcc48d1de20da0647466fe13dc67e5f5c57cf36fadcea5488d42fa1eb5fa0be03f01fc35f8aff0008bc35ad69720ba97fb260d3f57b28e4db2e9d7c9080d71323061f6366fbef8c29208eea3cacce7c9cb266d420e57b1f3526872d8f985246bbd39ce582a7ef21f4623d40fe2fba7d6a4fecdba62f7f6e563fb3c9f2107894019f308e99c60ee1f957d1fa97ecbfae69fe1a9fc47f0f246f14f858830dee8fbbcfd574997077a46a802ca8a3690a3058302170727035af8112e9be0f3e279751b3d63c326516b3c7a5178ef74d9d8371770c91e21c6d2aca48c3903f8abc1728f57b9d893ea7c81fb4e6ac356d3fc24ccf99d1aed64420e412203f42bc900fb1f4e7c22bddff006ae8b48b3d53c3563a3c17a91dada3a5c4f7ca14cf392a5da3038f2c02aa0f7da4f7c578457b987d6923292b3b0514515d04851451400514514005145140051451400514514005145140051451400514514005145140051451400514514005145140051451400514514005145140057a6fc133b64d5cff00d71ffd9ebccabd33e0b74d67fed8ff00ed4ae5c4ff0009fcbf33d1cbff00de61f3fc99eb800c64531bbe6950ee841a639fd2bcbe87d610c9924f1db9a858633eb53b739a848e318cd4edb8bd08c20c13dea374049152f434c6539229ee88f8657b8cda39a8da23d47047a53f7601f5a66f07241c62a912f5d86c0db64f70466ad68d696fa76b136ab72a24b4694da98988f9cb10c770eea14eeff80d5427ae393ea2a6d5645bdb7b34490aaecdaf0838cb8cfcd8efb9372fa9da076aa85933c7cca37846472fe27f0ed9dd5fbda5bd9a44f6ecd6ed2420282524752edc7390d1e4fb5739a8781ee6149a5b6bab49638bef2bddc2ae78cf0bbb2df857a73dd5a6916f6ca1fca95f60043ab191f0a18b15951d236d809e33dfbd374fd3353d6eeecdae0ddc9026025bacb70e909dfb5a38f02421769c019dd91f81e8f6ad1e0a6d1e336d7daae81722e2d27b8b2990f1342eca47d18115ea9f0f3f69cf18f87dda3d57553ab69d0a16db7a1a4727002a86dd9e71df3debd5349f035cea3a7cba55dda4cf653c407fa4ea06355f9719649635c9caf63d0d709f147f65cd5f47d305ff008657fb67332ac9a569c3cf9503062240232d903001f4cfa54d3c5c26f95e8ce8e57d8e33e26fc7bd57c7f652d922adb5a4a774aaab8cf0c36819385e7dcf039af290b827271ef5ecbe30fd94fc7de10f0e8d664b586fad160fb45c25b8955edd76966de248d46540e76935e3fe4e0fce187a7bd75c2a292bc5dc89c657d4bde1bd064f12eb767a5c334304b7522c6b25c3ed50490393f8d6ff008f3e186b3f0f2f5edf558c440c8eb06e3879e35381285ff9e6dced6ef83e95cb2c48dd1b06b413527302c77523cea8be5a1662db579c0193c0e4fe75a42ee5abd0cdd94745a99aa08e3a8ab812cfec8771956e81627001423e5da3d41fbf9fc29a638b6b3ab0c75c679a8c48315d0919dc8ca62954714f18e73de8201e87147285c435287fc2a3119f5cd382127a8a566174588ee08e0f34f255fd8d575427bd3d53dead5fa8b41e62229aad83834f8d8c64827229cc15fa0a56b0c6631938ce6984fbd38ef8fbf14d052738e11bd4f4a97a8d1f7f7fc12e7e37daf9daff00c12d66e6cf4cb5f12092f74dd4653890de6d863f2305806dc8bb9470728464ee007e99782be0de89e0dd5edf545b9bcbbbf82328af2b0118246090001efd49eb5fcf6f81fc51a9fc3ef1968de22d39cdbea3a5ddc37b6d295ca892375743ee32a2bfa12f80bf152d3e32fc1df0978ceda6b776d5b4f8a6b98ed9b724171b17cd8ba9236b965c139e2b8a7878c9b9f53a5ce4a1a3d0f4652714e2fb9723f435871789ec66d6ce931c8f25d88fcd62b137961776dff598db9ce3e5ceee41c639ad5327159c29497c2ce77e646f76a0b060536f723afd2bc13f6c6956efe11c2f1059517538b27a8c7972f20ff5af77b944b88ca38dca6be5ff00daa3c21ac69de14b89aca28a7d25ee11b6c123fda0c9872cd247f7651b413bc6240063e619a312ad14fb346b4926fccf8b6f3e16780fe2978d347d1bc7b74fa5e8b33bf99aadb3471496df23e0f98c8c00dd8c96f971c9e95f0b78b22d22c7c5baddbf87a7b8b9d062bd992c27bbdbe7496e2461133edf97714da4e38c938afd0af04f87f46f147c50f0fe99e219608347bb77b6b8944c100578d909dcdc01f377fc8d7c5dfb467c00f10fecebf13354f0beb36eef66b2349a66a817f757f6c58ec954f4ce31b802769c8a30f52ee493dac6b523eea68f378581fa55a86508d9240159bcae719e7bd3d33904f39af5233385c4e9ade74f2832b6fcf19519c5765e03f889e27f04de17d07c432e95bd7cb984471e6c648cc722e70f19c728c0a9ee2bcd6d19f85562aa7fba715ab6cad821063fda35d0f9671716ae671bc5e87e9b7c1cf8afe26f83165e07f17eb1a8ff0069e8fe21b283edb6677c4e96e551848213b77320004720cab2064072a31ebbf13fc17a27c6886efc43e19d5ad3c2fa06a7637509b8d34b1bcd7a5c1215ade2389232083c8f34e0700104f9bfec51f187c21f1efe0245f0e3e20e9f69fda9e18b416505ec56ea4c5662248e39f7b1731383b81930aa30a73938ac7d43c2773fb3df8f3548e3d635c8741d56ce41a1eb3a1bef059d87961c90aacb8552e232083b483835f11561284f956e8f49bd5dcf8b7f6d6d2b5af0ce99f0e3c3fe20f07b785f52b0b4bbff004990b89352899e3d93488c3e57f9581e7db6ae00af97ebec9ff828226a6fe19f8553eb9fda6dad37f6a4774fa8cd6d31dcbf643b77c6a250c0b12c9392cbb971d4d7c6d5f4d493504998d4bf33b8514515a99851451400514514005145140051451400514514005145140051451400514514005145140051451400514514005145140051451400514514005145140057a67c1638fed9ff00b63ffb52bccebd2fe0be7fe2738ffa63ff00b3d72e27f852feba9df80ff788fcff00267abdbb931019c0e94ae0fd6a3b4e5180c7f5a90f031debca8ec7d6bdd911e2a2635330049a85b033e869d894ee467bf34c2d86f6a901c66a263cd0897e631480c691a224e40ce7d28da4e4ee18f734e0700ae083d88aae531e7ec420ac6d8249f6f4a9e74b7fb24175f30b8538e07c8547cc338e7703fa13516d041c904f734b14325cc3f6748bcdf9b772170bc63272303b7714d238b1def516fb142c9cea5aba4ad33dd4aecbf701257e6edf303c67f0af4ed352da3b4810f87b5ebeb803cb7f2b4f8de1e1c9e1a40e33fed67f2e958de1b921b77f2e3bbb3b3048496e659551f92381b6e402a339e9d8f7aec22f135969b66ac9e24d1e69cb0db6ff006cc8e5490194ccfd1873f5f7e5b8bb33e7a09753a1f0fdd5ae9304461f016ad14a106df32e60b75271dc4657be7f4f7cf4d0fc59f145bc5f64b5f02691b0005e7d5afa59cf1c0c2ee23fc9ae2f4cf126bd7fe5c92e9fe19b9800dbbfcb925c8c7503001eff009d6ac37d677c4b8d0bc365d786f2ed070dc1cf24e08e0e3debc8a8a17d627a94dd9377fc083c47acf88fc57a16a3a4ea96561a7dbde40f6ced604c61d181042965c6e20f1c9af008ff00672d56df500c21f3acd6ec614b063e464fde207dec63803bd7bfcfa54ba93c8914f67a7054ddb44af1c67b602846527ea3b565a6a1ade85be481629a188ef94e59d768ea718181f41570af382e586c0edbd8f30d6ff66bd2ef2d9e4d2ae2e34fbac67cbb8198d8f3fec823f5fa5790f8cbe17f88fc0d1adc6a765fe80d2f94977164c4cf8276e481ce0138afa3754fda4bc33633ac37715e5c24670e6ca18caf1d7059c0af31f8cdf1c2dfe26f878e9b63a0b5969b04eb225dc8e37970ac07cabc0e1b9e4d7b58655deb5363cfa9285fdd3c49c904e0e01edda95d4c6072ad950df29a47e4d325c6723278ef5ddccd1ce0ae41e86944ed9ea2a026ac594cb1f9a1a359372151b973827b8f4356a4d2b8ac3d6714f5985375381a0bc7631f94928f36350380a73d3e9d3f0aaaade957ce2b17d2606a5593766a8464b1500f5e2a58f77ae0d3e70b1742939fd290123e94c432004e3701479c48fba7f2a7cc8648b26d073c8a46d8dfec9a445691d542e373601f7afd15fd977fe09bbe0cf17780745f17fc40d625d5cea70a5ddae9fa25c048a38d954ed99ca6e2e092acab8da46326bcec6e3e8e0e1cd53af63a68e1e559e87ce9fb33fec7fe35fda434b9b51d2a6b3d3fc35613886ff50ba76691400accb1468accefb1f201c0ed9e6bf55fe0d7c30b5f801e07d3bc11e0bf11cbfd8fa7c22e2ee6d434f927324923132b8756558d88da4273b40c907249e73c2ffb352fc26d34dbfc28f104fe1a87cc333d85d0125bcad8032c515589c2a8dcdb8e2b5ee7c67f177c136a1b55d16c3c450a1fde4da3191e4dbfee3ed24f07a67ad7cd7f69471551da765f77fc067b2b089ae5835f3fe99ea5e09d06c751f0fe932dbea9ab3b5a4a1cddbc8d0bde15eee3f8e361823afcb80318aeee7bf8ad232f2c8b1af4058e335f2aea7fb54f87aeece5b1d5e1d4fc3b76721c44cd6b708dcfccbf30c904746e091c8352587c6e3ae9b1b7d0bc5961aa2860655f12aa417112f00f97710fc81bb0cc64f24927a57b2b11cb1f711c553015a32bccfa9e2b859903a9ca9e6bc8bf6a123fe159b1da85cdd284320c85631c801fd69341f8d705a15b7d5b43d574a8ca173a9bc4d73618fef7da10b1c6067738418e4edac6f8fbe2cd1fc51f06afef74bd56cb54fb3dcc477dacd1caa18ee1fc2cd838638e8722b3962fda2e4b6ed1cd4e9ba752ecf8ebc31a7b4bf173c316f0c3a749a94f7ab0c5677d1b1b59e439f96455e483d0f07e86be96f117c2ef0e7c56d0f50f07f88fc37697524770ec7c35aa9db2db45b364936992b73b4b11b186d418c623af0bf81cf18fda03c1d777d6d0c852ecac667656552ca4071c64303820fad7dd5e2ff08687f11b4f369750bfda2205ed754b53b27b393b490cb8cab8383c7a7391c5744271a6dbea6b29db4e87e23fed75fb2f0f80de2492f3c3ef7777e12b875445d41025e584a431f22e140009c292b22fcae01c74af9dfcd2a40cf15fb67f1dfe18e8fe26f0f4de13f8d164d36973edb4d33e20e9a8a25b78c6446b7eee3e53bc87661fbb2c47dd22bf23bf688f845ff0a33e2ceb5e128b59b3d7ec6dcacd67a8d94a2449addf263248e03edc6e03201e848e6bd0a1579d6bb9c95216d56c7090c8d90558823d0d6c586a13ab22e43e4f21866b02ddce7e95ad661942b0191eb5e8425638e47b4fc05f8d9abfc07f88169e2fd06468e5890c5736d93e5dd43b959a27008c82557f4ee335f7f5b7c72f827fb4b7838dbdbdf6afe06d72400c3a08b432c37374ca42bac102c8643b9f6ee50ae4718afcabb7d41add79019739d99ea6b7342f1a5ed96ad63748df64bab49e39eda685997648ac0ae79e0640e4572627070ac9ce3a48d69d4774a5b1ee9ff050ef106ad79a0fc2dd13c41a55cd96afa38d4a24bdbcb096d65bcb43f64581c8955643831c83e651c11c67757c635f7eff00c151fe235a7c57f067c0bf13dbc760d25ddaea625b8b09d661bb6d8b792e7ef2ba173943c0dfc13935f015104d4526cd657e6770a28a2a880a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800af4bf83076ff6c1ff00ae3ffb52bcd2bd27e0d1e758ff00b63ffb3d73623f84ff00aea7760bf8f1f9fe4cf52b46dafd702acb1e0f354223b5c67d40e2ae1e4fbd7931d8fa9b8c723d6a01839078a95d79ce6a2c72c2982686e7e53d0d5795f62924f5ab0d80a4553ba0595a9dec899dda7639d7f10bc17d303c80e76eee9ffeaad6b3f11dadded598846e9b80c1ac99744175292c0f5ea2ab5df862eedd5a4b66f3547f08fbc2ae2ddae8f35d29c6f2476220f390c96c44e9d488f923f0aafbae0a38b775898e376f93ca5233d19b2303d79ae2ac35fbed1a73f3b2329e41c8aec34af1c691ab04b6d6ad42eee3ed56eaa251f50d9571df0464fad5dae455a9cf4dc248b50421edc0b9d4bc390e1d93cad925ecc42a81f281bc73c01c8c9cf6aee3e177c251e3ff001159dad9b6ba62496137f3e9f6d6ba72aa34803f96d2ede429247a6093c0385f01781ec27377771416be25b5116e8c9d58d84502804bf9d1449e631c6385703af53d3d93c0e3423e1a934fb1f0ef812f03c52f993d8e9f73a86a1665b004be64f2c8511411c95c038f95b93512972c753cda54d5f547573fecebf08fc2da3dfea1e20d77c63790dbb33428fe27d28485401f22aa4bf3b7523a67078e99f26d47e08f8abc673bddfc3cd235082cb73b5b4b7b3197cc45c95ded1824c85768e3827b74aee5fe1bf8cf54b776b28353d7ad2de3c442d74690c6b9e5798d17b7f4aeefe10fc36f8c6d25b5e6a9ad788f48d2adb88f4a58f5788480630008c10ab8f7078af17158854573ab7cff00a677c209a6a6785783bc0bf10ace54b6f19f87f53f0dca18c71deeaba75ca5aca411c0711b139192300f4fad55fda0fc57ae681f0c3fb2adf41834d49192de5d4ecd1c2cf6ff00365f2ca0e5b8c927a1c6057d47f163c4da8f85743b91accb7fe5aa60437fa96aa7cf3c80aa92e324e3a57c2bf19bc672699a65fc92de5f69f2ea61e3834e8ee4bc2d1b6436f8dbeef04f20f5c0c57465f096226abc918e22a46943d9c7767cff00e20bc33de3283fbb4f9540e98e688352f26c8db2e1d0f254f4c9ef54ae6617126f1c915137cabe6270bf5ef5f5763c81b7000662ab807b545c346082370e0834f3316043540e40cd43403581f4a92390c4edc0070460d4238e940258924e4fbd2b012bccd312598b1c63939a60f94d28248a4ce29a5610f42474a9e3908c93cd4038a78f945005c4ba2232b81f5342ccd8ec2ab2b605207c74a1a197a0958b677138e403dabee9fd8cff00685bfd27c1173e1e9751923fb26f687680ce372a0db9272132b9e08c124f5af82d2403be2badf87bf11ef7e1e6b0d7d66b1ceaf198e486504ab0c83d88e78ae0c56195785adaa3ab0f59d27a753f5e7c19fb4cfda4a5b6aee2c9f855bac168d8703bb641ea724915d7c5f1b6cf537686298de2aab12f6e158051dc907835f9bbe0ff00da4fc35aea456da84f36957240cef51e513e80ee3fad7aaf86bc5767703cdd33558e6421816b79c12011d3839cfb57cdcf00a0efc87b74b1b6f8927e67d4be2abed0bc55a6c8754b3b098b26edd70a8581c11c93c8fad7ce5af7c3fb24d427974ab97b362495f225cae79ee066adc5e22ba9addedda68658dc7cd2ca80b8cf6c9e735025db805564dc01fa8ada9354ee8dab632552ce3a13f87bc71f13bc030b2691aa7da200324195d5cfe208f4f7ab93fc51b8f1b48742d73c3da7d8eb175fbd5d62d2258a5661d774884649c92770249e7b55686fa58c6d750c7763f7633c76cd3ed6e2d67be897e48e63c65940615d5094652bf539aa56752369c53f3ebfd7c8c51ae6bdf0fbc53a7eb366b06ab26997492c504fb98bb2b640caf50718fc6be91f057eddb6de2f9adf459747bef0d5dc285b51d412cdaf62b741805ca46c1a3192492e30a17a36703e6ff18d89bbb95b391e58c4cc143db0c639c06627ff00d75cade7c3af1458ea29a8e8da93ff006941f2c37b1cad0dda019c01228c95f63c7b55558da7a339a9528b8de4cfbbe1d0bc09f1475182e62f1eea1e3cd376b5d6a16275349ed3ca500f94f6d1f1f3332fcaea780c2bf2f3fe0a39e01f047813e3e5b8f01385d2353d2a3bf96d51c18ed6669e753122803628544f93f87a7b0f75d22ef57f0edaf9de38f87daf34774011e2cf0b5a3c57d19c1cc8ee9f2c8080ccc4839ea41af33fda87e0e43e32f8791f8e3c0de2583c5da2e8f196bb1a9ba0d62d81cb488de5a2ab4680ab10c03a92dd41ae8c2d5f7edd0baf829aa2ea475b1f1bc59239ab313b0e03102aa25588ce78af722ec784d1af64de63a8033ea2b44191b2a8817d770e6b12da52aca41c60f6ae8f4cb80eaa1b048ee6bb61ef2b1ccd599a9f157cab8f84df0e6ee2bcd42477b8d4e2b9b4b98f16f1ccbf65cbc4d920968da20dc023cb5ce4118f25aeebe22dc99349d120dc5a389ee0afcdc7223edebc0fd3d2b85ae18c5c172b3b252537cc828a28aa2428a28a0028a28a0028a28a0028a28a0028a28a0028a28a0028a28a0028a28a0028a28a0028a28a0028a28a0028a28a0028a28a0028a28a0028a28a002bd27e0c9c1d5c7af93ffb3d79b57a37c1eff98b9cf4f27ff67ae7affc3676e0bf8f1f9fe4cf4c1cb0f6aba18940474aa20f39e3ad4f167cbc0ed5e4a3e8efad87961b4fad46c73d683c679a8b19a19b4456e6a091339cd4e4534fd291a2575a1045075a9f6109c76a10e053d1f3c52572ac93d4cfd4343b5d4a33e74437118dea06e1f8d715ac784ef2c4bcb6c0cf103c05cee1d7a8af45cd34e33f7735b29b5b9c956846a23cb345f1beb3e17bf59ac6f66b6950f3b1d877e8467dba57b9f80bf690d3f50db6de2092eb4aba9008daff004c94c41c703322eec1ee49ab3e12f815e16f881adc33789afed7c3fa75d6d08d63a85a8ba92425557e49a51804b1249e06d3d38ac0f8b7fb1478f7e1d41fdaba1a41e37d0a692530c9a0335d5cc50a9243cf1229d83681b994b20271b8e466a3568d47c8dea78528548ae668fb9bf665f887a9ae9979a5e85e27d06486ea759adae359b96f27ee85650c83ef91b7827d7a13cfd25ace8bf12f4ff0d5cea12eb5e10d2d2184cd7177335d7931aaae59cbee5c28009c9eddc57e19f82be26ebfe00bf57b1bb9634461e65bc8cdb5b1d8ae7dabe9fd13f6a77f8adf0faebc09ac78af53d0adef542c91c775b23750bb4461998fc873f73a1c74aca5818c9f75e644ab49ea5af8e9f19f5ef1af8aeeeef539f4a9f4eb22f6b14d6a93416f728aefb6621e4662ec0e7e9db8e7e5cf8a9abdaf8975a49ece4d90c30857059b69932c58a06e40c60638e95ed7f17f48f0a7c30f0169a746f156af7de23bd55596deeacad8c3b76b07749525dea01c609439e7915f31ea6e3e6c36e66e73f9d7a187a7c8b53824db96accd693693b49c53edee016c700fb9e2abb2e73ed4cdbb7deba9324e86e2cf4fb5b0f3a4bc492e5d72b041f360f3f78f403f1cd6116273ef4dc103ad033db9a043e800a834d04834a4f4a3518f1cd2039a1467eb4eec4e79a0055ef4018a6e4f3de939c1a009037d6937d27634d53827bd003fccc020714d321dbed48cb9ad3f0ae8cbae789f48d35d5dd2f2ee281821c3619c29c7079e693692bb04afb1962529d0d6ae8be2cd5b409d66d3b509ecdc1073148cb9fae0fb57b9f88ff640be9497f0cde3498e1adf50041cf3d1d531e9d40efcd790f8cbe12f8bfc053b26b5a0deda4582c973e4b34322f3f32b818238ae6a75a9555ee3b9ab8ce3ba3d13c25fb55788b4a68e1d5922d4ad8000b608908fc5b06bd87c27fb407853c508a4df8d36e09da6deeb6a0278f56c1ebd8f6af8b718e3bd0a08e41a72a14e6b54355248fd27d2fe235e5bc11cd67a7e95aac38076e583b8c7183bb1f90fc6b9dd47e32e9b6bafefd5748bad3194e0235be63603a9049e473d6be21f0c7c47f12f84a488e9fab5c2c319e2da4767888cf4da4e074ed835ebfe15fda93ce4587c51a6a4aabca4b689b803c75576e3bf20fe15c9f538c5de2cd3db4dab5cfa0754f1f695e20b9b1934ed460562e84c7712f9647cc0e304f3d6be89f84be00875e12deeb177672d8a4258cb67771911f23e67c9e001d6be3ed23c61e02f88568238e7b68aea4f902878e2b81c7619c9ebef5b165f0aa38f61f0ff008db54d09faf922731275078316d3db82738eb835c389c3d593bc5dbe573aa857e5566ae7e8d5a5f66c3fb33c3360b72f0c4b1c3a86a44c1625b185da40df2f1cfc83040fbc2bc53e2afecc1e1ef88936b36da55e4e7c65ab446df504d0608e0d26263bbcc6b801490c779cb166948dbf29000af1cd16ff00e3ef83bc2735e47afdf78af4a5cc11f947fb46e224c0c49e5a98e51c03f3265867b1af65f85dfb465ee91a2c56d7be103a9cadfbdb993c159ba963620077bab394adc47283f7c90e4e47cc4f5f989d1c561e7ed68d4bbfeb75fe47b0d4b1117ccd9f9a9f1b3f651f885f04fc5173a66a7a05d5c5a99d92d2eeda27923b9504e190841b860761c646402715e46d1496d2c914a8d14b1b1564718652382083d0d7eeed978dfc03f1f7c3d369093d9eb883709ec6508b796520054b985fe789d7711bb00835f057ed93fb04ea3e148f51f1b782924d5f4c077dc5a852d7683123bc8eab1e180c732679ee3bd7d4e073355ff775d72cff003ff23c3af829d25cd1d51f0dc32639ea6b6348b83bfe5c13fdd3deb08ee4cab02aca70411822a5b798c6c1b3d2be9e94edb9e54a375a1a5e3a71241a710369fde64631fddae4eb7bc4b70f736760cd1b20f9c0246377ddac1a26d4a4da2a09c6366145145665851451400514514005145140051451400514514005145140051451400514514005145140051451400514514005145140051451400514514005145140057a2fc20fbbac7fdb1ffd9ebceabd17e1074d5ffed8ff00ecf5cf88fe13feba9d983fe3c7e7f933d2236f979ed5340fc11ef55633b454d6e7e63f4af251f452dc98f520537a1a7051d7d285c1248a76378bb087a74a63e4f7a79e334c231d4e4549ac5d9081b9a721e2a2c8e69f1123354913cc3f38a6920a9f4a7c6a181e9c51b0e0f19a2c4dcfaa3f652d5b4bd3b45b36d1b45d26fbc4769746eeeaf351d2e7bb9923180160305b4851b210862d9073d738afa56c7e2a7896ebecec926af716975b9da68340bd992166c70a7ec4842819da32c460e49c8cfce5fb17cbadcfa05cd9e9b3e9f1422ff7336a5ae4d66aa76c7f7228a652edd08c8c1c11bb8c1fa8fc4d77e2af00780b52f13eb9af6916515ac6ef15ac3a9ea12fda24da4a44aed76a0bb118031d7d6be7e4b9ab492dfe479b88694dab1f28fed5bfb3ff0084fe21106c7469ad7c78616b992e21d227b0924889766baba4fb362505fe5de70c5b259b02bf3d759f0b6a7a0cedb9564895ca79f09dcb9c91d7b74afac7e297c6af10def8af5ab7d72e6dae2eeec969aefcf96e8451b0256dc098c85447b980fbaea73926be6ef1debc355936da40f0dba8f9cb1243373cf5afa5c1fb5b5a5b1e1d69a72f74c07d665bb8cc37b72f3b43188e2699cb600fe1049e075e2b0a76669189fe79e296e250e40ce7d6ab312338e95eb6c730c65ce699c9cfb5484e4521e94ac31a4718a40bd7b5285c53871d280003e5349da97711ef405c5210f1d0d250a300d2838a681098a5ce79a422963ef458620a17be69594952dd852a28c66810a395e057d0bfb0efc27b3f893f1a2dee3539bc9d3740b66d6243b4b0778e48c22e3073967071c64035f3ea270462bed8fd842cf59d23c03e26d574584a5ddfdc1b47b81012eb12a29f924eaa773f6e7e51e95e7e36528d19726e7a1828a7539a5d0fa73c6fe07f0c693672cd6da8dd1bd770f19b72bf239e83cbfbcbebce78eb589a6fc2bf1978a2d15deea5bf58b09125fb34839c02a428f906319c8af40f0a7c3136da5db6a1ade93ae5edfdd95f32e56069162523219891bddb3ce46460fad7ab49e25d1fc3d681e49d74e2909f322bbb592d5e6d8320c6aeaa646edf7abe25e25c5d96e7bea3093bb5647ca5e24fd85fc13e21f0f4d26b7e0cbeb4bf472df6ff0005ddc05f760e55a2911430c9ec0b647519c57c97f133f626d6bc3375752f86f5bb3d56d11c84b0d555b4fd4578242b45200a4e001956c12702bf54f4cf17d9f8bee163b7f14e956104c811ad56ee11728c49e5630c76b7cc0649273dab69fc11a2cf6e619f4d1aa2ae61926d52259377ab65d7e6cfb706ba28e6b56949c652bbedba309e168d476d8fc17f1078335ef0adc18759d1eef4d7c903ed10b206c77524608f71593e5e057eddf8ff00f654f017c41b492d352d124d29513cc5934c11c36ce790331b2b2123fddf4af8fbe2d7fc133753b1d3afb59f0ceab646086379de3b9cc6a402c405288464f031b40fa639fa1c3e6942be8dd99e5d4c15485dc7547c0e85a27dc84ab039041c115d97863e3078b7c2f22f93aac9750a8c7d9ef19a54c7b64e47e0456c78c3f67bf1cf836e1e3b8d164bd45cfef2c434cb8e79385c8e9df15e7975653d9cad15c42f0b8eab229523f3af6134f6382cd6a7d29f0fbf6cabbd05a27bbb8bfd26ef210cda7393195e3a82e180f6e6bddf4efda37c27f129226d58e9f2ea04029aee8530b0d662f43e62b0248cf46079c66bf3b7079a6a49242e1d18a38e4329c115cd530d46aeb28ea6f4ebd4a7f0b3f49ffe138d3daea2b8bd8a4f11436f202be21d3912cfc4f1aaf4df2a10b7040e79e59b1c57616bfb53ebdf0d6c2d350d63c41a6f8dfc112cfe4adadeab5bf89ad236ce3cd89f6c6e028c16cf2c7ad7e6668df133c51a1ba1b7d66e9913fe59cd233afe44fb5777a27ed43e2ad2ee2196786c6f846c0859a263d31eac71d2bcea995d37ac55cea86326b73d17f6bfd27c17f107c587c59f0bbc3771a35ac76aadadc33b5b40ad2b48db67112c84827700e7017807d49f17f02f8374bf16fdaf495b8683c531667b3596706def8206dd6b12aa3334ee7679786dac72bd4a9aef7e277ed1da3fc66b643e29d0043a808844751d355126e338cf4de39ce09ec2bc534bd56e745d4ed751d3ae64b5bdb39967b7b88ced78dd4e55860f04100d7a9414a14d46a1cce54f9f991b9f10ae629f4ad0842891a2897e5518c1c47d6b88aeb7e247881bc4fad4faa793142b7b712ddb2429b5124936bc8aaa380a18e00ec2b92ae9a4ad048cabc94aa36828a28ad4c028a28a0028a28a0028a28a0028a28a0028a28a0028a28a0028a28a0028a28a0028a28a0028a28a0028a28a0028a28a0028a28a0028a28a0028a28a002bd0fe11631ab67fe98ffecf5e795e81f098e06adff6cbff0067ae7c47f09ff5d4ecc1ff001e3f3fc99e8cac054b6ee15aa9ab6d63e95245261811eb5e4a3e8668d1c86cd22707a546ac4f438a76ea6cd60f41cc734c3d0d380183cd348c0348d3990ccf5ec2b3a6f10456b7662ce42e3247d6ae4cd85703d2b97bbd2e4bc9e464f95c9ea7a534ce2adcd27a1dad95e41a9461a065f300e54e054e8a402a47cc7d6bccfcfd4742b8e55e3ed939c1aebfc3be32b7be090ea2c54e40f306323f335a357d49854e45691f457ecdbe2af0ef872cbc4a9e2252e8b1c573001f39629b832aa182552c430c162838e5ab0bf682f8c6de3d927b3d33c8b4f0d690cf34493c36d04d311900b346a818e3a2f3d4f5ae22db4fb886d26b9b0ba1736b2c7832db9c9519ce1c763c0f6f435cc78f20bcb3f0d6a4b712131cb00942babc4e0904e0e410c0804f0791deb8e1878badcdbdff00ad0f37195a52972a7a6879e78abc731ebd264cdf676c6dca4671d4f38cf079ed5c8cd7b748ac12fbcd8cf6dc7f91aa9238dc702a30339e6be8a2945591e488ceccc493c9f6a69e98a715c534e6a86467e5cd39581ebcd21a44efcd480b81da90e714b826908348428ef42b63345206c74a6324cd2501b7518a0041f2f7a38a7019ce38a08e3069d807890fd97ca01797dc4e39e06073f89a10e4d46a3dea58b8a4068e8da74babea36f670279934ec23441d5989c003ea48afd81f82fe11b1f84bf0cfc35e1fb64b41269f0a1bf5d4111409881e6322eddc642c095cf6cf07ad7e5f7ecc5e1a9bc5dfb427c38d2614577b9d76cd4874dea144e858b2f750a092323806bf766c3e10ad86a07516b9b5d4350c8659b50b432ac3ce711287508011c7523d4d7cae6f8a546d167b184a90a34ddf7671a352f17ebda7c0d6625d3b4a919411a924697b376db0a361071920b75c74a89b59b7f074827b9f09789ee6f0c9e5ff0069491dbdd4af939dabb652c01ecaa31ed9af4abdd07c4d360ff69e8ac50ef4126952b6d61d0ffc7c75f7ae7b52d23e23a616d2f3c31788adbbfd2ed2e918724f1891bf035f092c4424b4dbb25b9d2ab459c7cbadf83bc4b7372fae78275050c3734fabf866690b37a731376f7f5aa5a9ddfc26b282e2da3f11e9fe13668f25ecb553a74a8ddf312ba0040f519ed8e38e9a487e28db33a456be15904f2e5f75f5e216ff007728db6b375783c69a94122eabe09d0ef2d594dbca90ead2bcce33f795becfc2e33c75e6885a6fafdebfafc5af4e9bc5f327730b41d17c3b35d46fa2fc5fd4f50b8607cb8db57b4bdc8247003a39f4e335c67c64d6fe217857c03ac08bc49a4ded94933c022d774b9219e45c12047242e53040e09403af4e0575a3c0fa25b6ba216f847a0eab3794505bd89b29e446eceed2c71b2fa6493f4ae13f688f05690bf0d3574b1f85de23d1353f21a48ae345bab64851c29ff5a23b81f203d495cf4f4af4f08e2b1108b5bdadb7f9fe5a05495a2d2ec7ceba878a3577d2a79350d1e2772992da75ca4849c1e8b204feb59d71f0b6dbc6ba7412f887e1df88238268102ea173a14a5766d3875962470171939dddebccacf5278354bcb19b56f115a5cdb48619ace68dee0c6ea482ad9490750475ed5f6a7853c45acd9da78763b3f17f8cec2e21d363436fac784669d36855e62091464a83d09ed5f4f8baf3a3356fd7fc8e1c3d15560dc8f8af5efd8e3c37abb0ff00844fe216816f7923b66c358d412dda2e78565601c7fdf27f3cd78778f7e0478d3c01717c2f7487beb0b46dadaae9a1ae2cdb93822551819c746c1e9c57de1e20f88dabe89e26d6e2d4ec7c15e2d5fb411f68f18787668a561920677bb30c8c70738cfe795a2f8bfc3ba86bd23ea1e01f0a4715c40f1a5a7873557b1895d9b3e6058d149230300938e9d79ade18dad4d3738dd7aff9d8ca7469bb72e8cfce630b0eb9c8a4d86befcd73e037c04f11c926a1a9e9de2fd0ee2472251a6ea569731990e4e332465f764f43cf03ad78878fbf65bb4b4bb9a7f06789ecf52b1fb3b5c7d9b51631dc23ee6db6c0aa6249b039da0283dfae3be8e3a955d354fcce595071574d33e71111e6811b60e2ba3d5fc21ab686ce2fb4e9edd15cc5e694250b0ce406c60f4ec6b285b907a577277399ab142ee563043193908588fc71fe1556aeea31797e5fbe7fa552ade1f0898514515620a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800aefbe14b6dfed4ff00b65ffb3d7035dd7c2e38fed3ff00b65ffb3d615ff86cebc27f1a3f3fc8efcbe338a723f1d6ab97a236e4d7907d148d68df22a446f4aa503fc9d6ac46fe94dec11d158b209c6699b7ae0d229c8a72fbd22d3b913a6e069b6f69824e33cd59403d33562da30d9e86a2fa9b2495c649a6c37d6cd05c44b2211dc74ebc8f435c2f88bc0d79a6acb75a7eeb8817928325d7afa0e457a5c23823bd39d3e5c73cd744656392ad28d4d0f2af0a7c51d47c2926c56de99c323e4e4719046791c7435ea67c5fe12f885e0bbfb6530697a98b79998cf232a60c67eeaee23e5e4818ee6b92f15f802cb5c8a496dd16d2f08243a0c2b9e7ef0c7eb5e61ab7876ffc357cd69a915b626212a957cf988c3823ebe86ba69c6337747895e32869230c9c12339c5201c51232ee6d99db9ea7ad00139aee479e069bcfad3f9f4a3354044d9a6e0e39a7b3533939a9014d252520e292d0055e73474eb4801a55380734085550d4a0119e6983ad48bc81cd0314640a728c6714d51d69d400bce0d2c6314ccd489c015223eb6ff825d78453c55fb5df86a5961f3a1d22d2e7526071852aaa88dd3b3c8a6bf700a0ef8c57e46ffc11fbe186afadfc56f1378c239ee34fd22c3496d38dddbaa65a792682409f3a30c6c8d89e8795afd4e92dbc35a4b4d1deeb12a72237fb6ea9215dc7903e77c06239c0e707debe5336c3ceacb9ba1d89ad8d2d5356d3b4883cdd42fadaca1ce03dc4ca8a4fa6588f4ac24f885e12b89fc987c4ba65c4cc7688a1bb8ddc9f4003135cdebbac7c36b5b9996c3c2f0f8a75346c49168fa425dc8ad920ef7dbb54e7aee6079aa0de1ef16f8ae67b93617be1bb188aada69315dc568af1facb245e61191c60018c71eb5f2157031d799fe86f04bae8747a878d745b69642916a37ae8395b3d2ee6707f148c8cfe35ca37c4d496e634b2f04f8b9c799cecd27c956e7bf98cbc7bd6be95a2fc42b195e084785b40d3cb16fdc457379331f566262dcc7bb1e78aa5e2336d239b1d6fe27cba5ddb617ecda6496b6d216f445657939cfddc9ed5e459c27683bfadff00456fc4de32b6c473ea5aeea905caaf82758d2bcec05b95bbb38a40b9382c44a48fd7e95e65f1e352f135bfc22f13e892586816f6d3e9f24737dab5ec5d4a0a3066c1870588e7ebdeba38748d324bd96c058fc47f1979c3cb335edd4f05a9ec7259e25c1fa11c9ae43e3d7c31369f0df5eba6f05f81b44b34b590c72ea7bae6f0b0562aa9f2aaef3c71b8f39eb5e9e0a6feb10535d57f5bdff03494ef167e7b699629a1eb73476a74bfb4cd20924965d54dc0ceee9808ac7f3f5afb6747fda2f54b3b3d26d6e35db0bd963b38e28df49f0b5dcd710e1401f34b3853fef7426be5ab5d3040fe5f9cb68aafd2ce25863000fbbf30247fc06bdffc39e10d32dbc3967a8cf2c77372d179b69109bf7eee546c2bbc65d40caa807e69b6a8e031afa8cc392724a5b93847269ab6862f8d75cd47c48fa85fdeea97f35a79eb1a3ea56f0c6ece0648201701143648cf19e79c6784d42fe7171235bc2618238b125d188622427973803f787f8108fafa57b45b68b67ac62dcc11dc4910335bade80a625424fda2e5beeb59a83ba493acb2ae3eead7ce1f19be2469fabea51e83e112f168f65c4f76d8dda9dd82c0dc103b646100e40c0033f770c354755f2f446988e5a7beacced5b5f499585bcae2dd5f6c6a1f69504e0ee2391277773c2038ce49ac67f10dba6a4c974cbb1230247b70410bbb1b2363c2a9e7e73f337e40ce7c0f2e9fa6c375ac1ff89bdd00d69a5c6a4c8aa7695794630339f95339effed1c7d474afb2cd15be45ddcb287db131768f2c79ff00786319e8bd073907d784232bd8f22a55a907b16bc4fe33bcf124496f2d95ac169140b6f15a246a91c118c8248238cf3b98fceddcaf41c86b7f0f747f134c2e22d3e3d123dbe52f91f26f23383b4839ce7af04fa015daf87fc2575a8dfdb5b5b5a35fdecdb561b7895a42cf9e300025dfe833f4af53d6be115a7c37d3a39fe21dc5c6957d7da79bcb1d3ac1164bb889c8532ef1b605e304fcc477c1ad557a7424a17d7b1928d5a8b9d9f0e7c54f015c78264d38cb2acb0dd997cae0abe14ae4b0ed9dc3f5ae0ebddbf69a59e2d3fc291979fec7bef1e18e794bb64880349d064b6d519c60ede3205784d7bb869b9d2527e7f98a492764145145749214514500145145001451450014514500145145001451450014514500145145001451450014514500145145001451450014514500145145001451450015dcfc30ff00989ffdb2ff00d9eb86aee3e18f1fda67feb97fecf5cf5ff86ffaea75e15dab47fae876cff5e94e89b23e951e4927bd0afb4d7947bf7d34342d9b00d5a4e07d6b3ad1fe6c55f8cf4140f526518152af19c54286a68c8dbdf02a5ec35a3268d7e6e055bb788e738fc0d558ce47033f4ad3b388bc60f6e29235e616340c71d0d3ca9c900eeedc54f0464120a9241e01ef523db9f9890aa00e36d6ab6336eecc2d5ae96d2d6576215554924fa735e03ad6a336ada94f73348d2176f9771276af603d80e95eadf1435a167a5c91c6fb67b83e515ff670771fe42bc79876af428479627858ca9cd3e55d06018cd3968e4d390616ba51e78ddb9a4d981d6a4e4f14981f5aa022dbcf031ef4d2060e054a54b5214201a9020db9cf148576d6e785bc2b7fe30d6a1d36c23dd23f2f21076c6b9e59b1db9abbf11bc1d1f823c46da7432b4f018525591fef31390dd063ef2b63db1dea13d6c2396a106734a5680b8aa186d3da9c171484e280d8cd20154f5a7019cd3402bde9e3a668e8022ae73ed4e5e3de84ce0d07e5a181facdff0004c2f891e05f86df03adbc3be20d427d0b58d56fe7d5ccf7acb15b4819628d143ee1d52356c371c9c1ed5f6b7c31d434b3a35f6accb05b0d43529de1ba910235d445cb42cac705c142369e78e95fcff781fe33f883c1c23816e3edd608028b6b92cca8a31f779f9781f4afae3f67ff00db7a6f0dea96b2699ac8b3b948bc8fecfd70efb7642c0948db7f1f37400a93cf15cb2849bbad57637ba95d33f59adf52b7b4beb9b7d33449f2ec659ae2281618da43d492c54b13819600f6e6a9c09e32bbbe90dd49a569761d123b712dc4cc3d4bb6c553edb5beb5e47f0abf6cff000778c92d2c75f90f8735478c179a72a2cddb81f2c85b2339c8dc074ea6bdd5754b4b8b08efa1bb81ac193cefb4ac80c663c67706ce318c1ce7a579f5b2fa15aed2b3febe44f34a3d0f973e38f8af4df87bf14b43b2d5bc53e2fd4d4c5fda17d6092a2da4d06f6411854f2d73b97054820ab1e7d7d0be0bf8efc11e21d0751f10e9fa1e9de13823be6b089e44862926f911802c31966cfdd04f4ea6bcdbf6b98f4ef1a476b77e1c863bfd72da240d70d22a44f68ec7f799ebe5ab60f9c7110cb02fbb8af30f863f01bc737b0adf6a97b0e97a1d8df457c2f2eeee48ac3e500b3c630a64f97a3a61186712b0af2ab65d4ab43927a59f43a5cfb1f4278eff0068db982cc47e10b1fb438bd7b196e2f617da0a83b8a8438078ced63bf1c88d81cd781fc56d7659bc2bacddf8bf51bfbed6a2b4924104d72a91c5338970bb5882a0053c2e01240dbc106d78ff00e38f80be17584fe1ff00074ede28f15a06075696353059a3eedc2d95197cb6f330ca147f1752715e05e33fda0f565d2756d224b0b6bdd4b58b492090df34b38b289cc85ee583390261e630dfd1436d03e662dad0cbe8d15fbb8d9fe2275ac9a5d4f3bd5bc586e2648546238f89190f1dfe5e3b91c9f6afa4be1d6bc3c77e15d0ad9a592ed0c1159416f3c69209664450208c81940a012c78f2a2676cef978f8e23bb567f22d4930af0646e0b9eee71dcf5cd75565f17753f0778425d134879175cbf56b65ba5277db5ab8f9a3880236ef24ee3d48017a673d1530d0aaef2e8452c54a8a691ecff001c7e2608e5b9f01f853524be594aaeaba858125647cba8b1b560c4fd8d32bb50f5393e86bcc5ad6c3c02d6901cdc78b1a5431dbed5920b2560c034bd48914e01f970a33c1208185e1d9a3b2d325b70b14da94bc5d5e5d61e2b64e3289c7fafc827be38f7cfad7c2cfd9cfc67f14ed9a4d1f49363a44a37bebbaaac91adc738f958293231cf0aa31dab93968e12369bb2edd5fa94a53aaf9a3ab38596e6f2eccec971e65edc9dd77a9cac4ee739dc1093ce49ef927b9e48af67f841fb23eb9e23d246b9abba784fc351b07bad4f59cc32cd0ed04bc6aca014da4619885fae0d763ff08e7c29fd97619ae757bf8fc67e3d8a26874ed1c4715cc3693940564962c0d8e24423009701b807ad79a7c51f8e1e36f8ab3add78eb526d23445855a0d1f4f730ab38271e62166c13923bbfa15ae6552b623dda1eec7bf5f979798dc6307cd3777f819be38d13c19e16d62ee0f85fad78b352d4a2325b5d6b7fda096d6fe5f39897c955f9090a792491fc27ad7159b7d5752861bcbe6bdd5bcb066125c33c50919e5bab1393d4e58fa0ab5a6e99e24f1b4e34bf0e68b7ad6cca65161a540ef76e3382fb403b41c8cbb7393d79af43f0c7ec3df17fc69a5cae9a158f846c643f247a8ea0f04d3020826611c4ec7af2095cfbd6f2ab4682e5a9357febfafd04d4eaea9687cb1fb5cc7646d3c193e9d1ddcd6aeb74ad7f70b88e6940837a478c8c2e54e325be7193d00f9d6be84fdaff00e1eeb3f0bb56d03c37aceb5a36b92da0b909368f7b717221198d7ca63280176ede1507196cf6c7cf75f4d8256a11febab30abcbcef9760a28a2bb4c828a28a0028a28a0028a28a0028a28a0028a28a0028a28a0028a28a0028a28a0028a28a0028a28a0028a28a0028a28a0028a28a0028a28a0028a28a002bb6f86870352ffb65ff00b3d7135da7c361ff00211ffb67ff00b3d615ff0086ce9c33b55476e481d2a20d834ee9ed8ea298d8c7ad79495f63dd4d2d49addf122633d6b563931fe358aa7e6e2b4e363b473f8535a5d0f99175188ce0f5a7c6c5b2377e75484e73b57ef633d2a7b27779406db1ae79690ed503d79a5cac975125a9a569f26373803d6b62d2558636e01039e39c52e97e0e8f5189651728fbfe60637ca32d76fa26816b64a54c0b91fc657ad5283399e26db189a769777a801e4c38c8dcaee0815d3e95f0fe4b89565bb9093820c7170bfa8cd6bd941b4ed8d76e7bede07e3507c46f1c45f0fbe1d6a5aab3ecbbd9f67b41804b4cca429c646718c9f606b78413d0e5a9889db43e57f8f1a8e9b73f102f2cb4a8ca5be9cbf64909e8f2abbef61f8f1f8579d15a96f2e65bbb89679e469a6958bbc8e496762724927a939a895b19cd7a095b4479cdb6eec5518cd04f5a339f6a3000ab102a96cf614a1474039a6824e71d294102801e138ad6f09f85aebc65e22b3d1ec8a24b3b60cb21c2c6bdd8ff009f6ac63260715abe1f1a9c522dde9e4c655f1e606da72307afe551276d06bccfabfc3bf0c749f03e8f15a58c0e641869ae78f32661dc9c74f6ed5e4ffb45784f1a7596bb06184321b695719215b7329c8ec0861f56adbf87bf1c2eed962d33c490c93c4a020bb45dc57a0cb73d3af35d5f8d353f09f8bfc25a9d847af69a8d770111adc4e8a164c1284e4e461b06b9e317195c1aec7c844734dc5492068e478c91b94907073519e2ba0404605038a4ef4aa71400e0314fed4839a737148017806bd8ff00655f82fa57c73f8a0740d7a5d42d7448ac64b9babdd37cbdf68bb923599c3820c6af2233f70a18e46335e38bc035f79ffc13f7c21a545f0eaffc4ccc25d42eb54974d7b689079d2ed86378e0240c986706e2261ddfcae3ad72e26aba34dcd1d387829cb53e63f8ddfb30f8e7e08f8c351d1350d327d4eded8bbc5a8595bc8d14d002db65fbbc2955dd9e40e46720e3c883b21f4afdc61a6dbeafe094bf7689754f0cc02e2d2e25da2ee7d1b6ee8d813d2e2221806e8b2467b3127e62f8d3fb23f853e38ddde6b5e17d08f87759be68cbea7936b6b2cefe60fb49802b62de560a7ccc280ec46e6038e3a78e8ad2ae9e653a1a5e2cf853c13f1c7c53e0e78e35bd3a8d8ae17ecb7a59d40e38539cae00e3b73d2bea9f84bfb624f79a70d2adfc4b75a5c4f1344da46a5727ecce5d3630405f69e5ce3807201c715f2e7c44fd9ffc73f0d355d4ecb55d0ae651a6a96bbb9b486492280062a7cc6dbf260f1f363a8eb915e7a808271dabd2f766bb9ce9b5a1fb4ff03be2cfc2fd6f544ff84cc4f6dad5da202fab7952699bd3011c679320c9c4b36e60323cc39e7cb7f6d8fda367d7fc7537843c3dab79b616caabbe09b301cef067255f0c79c2d7e767823e387893c1de540d73fda760b81f67bc2cdb14638439f9781c7619e95eede17f89de0bf8901239e44d3b53e004ba291c9bb181e5b670dcb1c0ebc74ae7749a6dc47bee747e6daf833443a8ca8f77a8ce76dbc52fcf24b2b0f949f56c8edd3381efe7baeea322cb756466171aa5db6fbf9d4e76139c5b29f407a8f5e2bb0f17f87fc40924da9e9457537484456d09fbf6f90774aa3bb81c023d7a5794cdaddb68914e8c930d7379f30ddae160183b9df386f37774f407fbc78e554e5b04e46bdc44fe1fd909549f529137881483e50ffa6bfdd031cfe1f82f872c8bde4b1dba3ea1a94dc35c45c9dd91c47c6428fef71f80e6a1f07e8975e3194199e7b4d39cf9b35eca8c65bae7e600f7439381d3b9cf4af55b3d7347f06581d3740b0f3b5103619258c34adc7de6231f2fe407345d6c885076d4d6f07683a47c3ad4f49f1078c96dafece0b8597fb26251244c321b6b2be03b7ca72bd0f727ad7d03aefc7ff1ff00c5dd156dbc0cb17c33f87b6d02c675ed4a236ff7410560f2d8aeedb8da91f3f29f9857c9775610cd27f6af89350696e3cc3247631b6f52a79dbb4f5ee31f76bd03c11a4fc4efda6358b6d0bc3f6f753e9169108a3b9b9f323b1b18d78c3b202abc1fb8837715cd3a34ea3e792dbbee6caab8c5c1181ad4fa7e8be26bc9746f11de78a2ed9899754d42dd23dd3331dc41dccfb49e47cc18e492335edbf037f645f157c4eb8835df152cfa0e885f2d3ea11b25c4a301b36d132e029c8c48debd1b0457bdfc2bfd9c3e1b7ecf3a145e26f144b6da86ad6e14bea5abf97f67b79861ff00d16261c36532a7e690faf26b8bf8bbfb79cf34b75a3fc39d2a4beb84b77335dcf06f9e341b879e115f1146bc379927033ca8c72e74a538b8c7dd462a76777ab3d9c5b7c27fd95fc26f2c8d67a6cf15bee79dda37d4af97d49e0904afb203e95f1ffc75fdb4bc5bf16269fc3fe0c59348f0f1909fb5287533458643bdd5f12121b3b07cbea5b00d78cf883c43ad7c48b9bcd4b5ed61f5ad5fccc2fda5e49accc783b7e627331c9c673b00e80d50d36e6e34f8ac2c3510af31c6c68a03e5aae0f1c0c0238f4e2bcfc365b4e8be796b2eeff4febee3da54dd4d66fe478cfed1ba52582787267ba9ef6f27fb419a79db39c7958551fc2012dc76cd78bd7b9fed3dc8f0d104329fb4e08391ff002cabc32beb28ab5347995e2a351a41451456c7385145140051451400514514005145140051451400514514005145140051451400514514005145140051451400514514005145140051451400514514005773f0c21926fed3f2d738f2b3cffbf5c357a17c24608357271ff2cbaffc0eb2abf0334a72e595d1d73584f9e5063d09a8deca4c1c054fa9ad472b2024aa9fa8a8160898861f9638af3d2475fb66544b0959012c80838254e6b521d36540a02b3938c10bc557b4119bf87270377e75d09bd8d23520f38c55a8a63759a564558b449d6279641e5c6aa58f97c96c7381ef5cef88afe07b18fecf95dc9f36eebce6ba1bed78470322b1031dcd701ad5f199df9e4fa55348c1ce52dcd6f0678e6ebc3d7314524b24963b8168c31e3a7239fd2bdf7c3dafc7acd8c535b4a93c2c01dca41c7b1f7f6af946398720d743e0ef1fea1e0bd4565b694cb6848f3add89dac323240ecd81d6a2c55cfaa70f7850c72cd1803aa9c0af9ebf691f1a4babf8963d020bd79ac74d8c79a84fca673bb24e0f242903d8ee15ec3a57c45d2b52f055e6b96772665b3b779e581ca8752a85b6903a74c57c85ad6ab36b3aadeea170479f7533ccfb738dcc4938c93eb5bd25bb32a8fa14a47e6914f5a613926804d74989203c52e09ebf9535480280c5b3568052f8e86985f348c6984f5c75f5a901e1b835a5a7eb46c6dfcae4a6e2f8f7e9fd2b2436d1f4a8cbe4f5a911b0fadcde6992395a33e8a71c534eb53139de73591bc8148643cf345864b713196e2490f5762c714d1ce7bd45bb3de9e8d8cd301eab8cd0462901e29ca2900aa083c75a957a1a8ea45e868dd020073c57d2bfb137c67bbf057c42b0f094be549a6f886416103cc0ff00a1de48f1882e54e7e52920424e090bbb02be696e95d0f8063bc97c5fa2ae9f1c935f9bb896de38412ef297010281c925b18c572d782a94dc646d464e33563f69fc32a961ae45e219edbed97506fb8d4a2b8fde5bdba2cd9bdb78979c3a4a04c80e4e1b3df27b1f19786ad741d722d72c16d2e340d63f7919fbe679240cd25aeefbbe44cb9655ce3ce2a7f8b9f30d2bc6f72ba2e989f668d752602eef6de090894ead6ea23b885d79cacd163ddb249ef504de3cbef116932787e7bb68f4bda6e74f862f94c56ecc4c63af0d11f9463eeed5c57ca453a91e44adfd7f5eba9eaaa6dcaede850f8aa34d951750d39bed7a93db7972c522fc9a8e9c43092d6f0725ee171b5d49e5769fbc38f85be32fc0df0cf8bb5d897c1d669a4eb2517ed16568bfe8b143b8813ca1549424b00c4607190315f5a6a335e35d49a5452afda9a60d25d4bbb6c326789f201f99d49041ead9cf06b94b8f0b2f865e7b9b20d1cb2831df48f8dd349c862c401946ebe9f90af570a9d2d1338ebc34bad8fceef19fc38f117c3fbd9adf57d3a48e3595a34bb4566825209e55f1dc0ce0e0e08e2b9d8e468c8656dac39041e457e83f8cf4bb6d57449747964b79165b7334d713b2f9505b60ab970d9fde2e0ed38ededc7c9be2ff00873a5f88bc6a74ff0004d94b1c6f20853739789c8620c80804aa9f94f24f193e82bd98d44f73853b3287823e3bf89fc22d0c4f78753b2523305e1672071f75b395e07d3dabdaf44f885f0e7e2d9822d62da0b7d4c15212f4246c5811855933f30cb1f94f5f4af98fc49e0ed73c1f74f06b1a65c5830728af2c6c11c8241dac4608e3b563f9cc872a4e7d455b8a91573eee9bc233b44d16973dbdb5a08c2a2f2ac074c28008c018e7f4addf0efecb3e38d774ab6d4ad12cadae6fdb75be9ebe6cfa8dc447eecfe585f92224e0c9232a823906be38f037c7df14f83235b7fb52ea764b8c437c5df60181843bb2bc0fa7b57d71f00bf6c95d2b53827d035b1a4ea0fb527d2f53dbe55c1c8f9465b0c3270304375e95cb2a2d6b10dfa9f51fc1dff827de87a75b417ff11e56d5b510c1974eb59ff7257009495ca066e720a210b8ee6bd57c79f18fc01fb3b6883c37a05858aeaf213158f87b43b74c79e54840e8854e49551b402e7b035e1fe39fdb07c6be28f0ec3a5681058f872eae5365f6a2ad219067209879f938391c920f461d6b81d1fe30e9ff000b1669fc3da1c7e20f164d299ae3c45ac2fdb2ed5dba957c810a6416ea4f2725a928596a8c1a7b1d1f8cbc25e38f89966fe3af8d3e236f00f845e2792d34507cbd564c64ecb781f2916549019f2e0f2c00e6be7bf18f8ef4fbf8eeb40f879a1c763e1f5568dee08c0bc5c9f9efee725a790f05a304a8ec38cd4fe39f17f893e266ad73ad78bb55935c902bb4703cac9630ae58e19d8e1875ca8c28feef7ae46e274d7238ed2c9daea181048c6dcac3a6e57fe5997c1dcbeca0e45637e67a0256d0c5f08ebc66f116a9a65dea5f6ab98c8db2c440b71c2e510673c1c815dcab70d190304f071823f2af00f0af8820b3f8993bdc88a28ae6e1edd858ff00aa525f00a67f872011eddabdea327859301b68209e726aad667d1d36a7047887ed4208ff0084681f5bae73ff005cabc2abdd7f6a1dd9f0d6edbff2f3d3fed9578557a347e0479188fe230a28a2b639c28a28a0028a28a0028a28a0028a28a0028a28a0028a28a0028a28a0028a28a0028a28a0028a28a0028a28a0028a28a0028a28a0028a28a0028a28a002bbdf858db46aa7feb97fecf5c157a0fc26b56b91ab61b007959ffc7eb2abf032e1b9db671c939069b3168de3f7e2adff00651dbf78914874a7381cf1c82735e7ab9be88cf3fba915c7f0906aeb4af8dc72075a7ff663b0c3019f5cd4e34c611aef3c01c67bd52b99b30af5d9c363273dab9dbeb690e4eccd771756d1a447039ac1bab72370ed4c4720f098c9e38a6b2e7935b575678cf1c5663db14278e28468b54568f50bcb0b7ba8adee24823b8431ca88c40753d88ef592d16056b4b1ee5e055278f39e2b78be86124ccf78f029110f381569a2ebc5336119c0add32111f95dc8a3681918a79e47f8d3318abb8c8dc66a2c6738a99876a8db8e052023e99a611826a4db81f5a67a8a403185215cd38a66909205003429e69c0639e940e3f1a78e94087c43834e02a34c8a70e295807a8e4d3d7bd3106334b9cd46c0853d6bec9fd8bbe177862df41ff84eb59b49755d7a48e6fec44ca882cee2375db330ea64560aca73800f4af8e6de092ea78a1851a49646088883258938000ee6bf51fe197c31b3f057c24d074769ed85ee98b6f717298f2a5c4910f3d59b62b8024f31b9c8e01faf1e2a494145f53b30cb5724675c6b77d71e28bbd7cf1717728bf8fc8254a4eadf32e33ce57231f5aeab4bf12c7ab2c9045c5ca4ed7d1dc28e56ddc7ef22db9fef1dc17a67159daef845b48d4e48ecb1244106a2818ee661921d430183f4207de158085ac2eda7d36668a6502e124518dc84f2871d4679c74e95c2a29ad0eae7941b4cf49d43c3eb6f662e6d635b98b66e6b88c64cf191c9247563d41f5ac4d55e26d3649240b3c810442363937319ced23d5b8ebecd4cf0878c9ecf7db6a772d6e241be16503ecfb09e0107a1ede98c52ea76f25fdfc9159335bdc5c296b56661b2288e77c8bdc127951ffd7a4b9922db8c968786f8d3c3979e20966d084aefa6b9135d5cdab121882408c7af52307f4e6ba4f0878234bf0ac7135b59795701423878c1c018ea71c938049eff0040057aac3e12b7b0b486058cf9710df1349825db1c96e392719a26d0ed6f9159d4c72a603345804a8e84fa915494b7b9c8e96ba1e7faff0085b44f115bbda6a7a745a9dac87260b8803853c8dc32386193c8e7ad780fc4afd8c05d24ba9781aed159b73be91792723ef102270bd0f0006efd5abeaebbf0bccb30682556c7237771f854474ed42d63256d0bc99243c793c7a56d09ce0f47a19ba4fb1f97be24f086b3e0fd525d3b5bd36e34dbb8c9063b88cae7048ca9230c320f2320d66c60a9e3a8e8457e9878c7c1567e32d3a4b4d73c3b05f2302a1a7b7deeb9041656c655b1dc115f30fc41fd8ff58b5796efc1f6f717d0004b595c03e603cf08c1403f4383ee6bb235e32d0cf92513cebc05f1efc4de0f6860b8b93abd82b0cc578ccee8bc64236ee381c03903d2be85f06fc61f09f8fa18e08ef05b5db9e6c6f4aa339e981f361f39e9d7dabe45d77c31ab785efdec35ad32eb4abd4018dbde42d13e327070c01c71d6a8c4cf148af1b323a904303820f622b5693dc85a9f726a3e18b7d4ccb25cbcf7684044b46c0823419e91e304f6ce09f7acf3a06a7796cf6d616dfd9ba7aa366e6e014638fee6411d070706be7ff01fc7cf10f86523b5d4253acd903c79ec4cc9d3a313c8f63eb5eb777f16bc3be30f87baebc5a88b6bd167304b5b8611c9bb636ddbf37392474ae674acef10514ddd9f354d234d732caee646772c5c9c96e4f39afa13e1a7888eb9e16b28bcc56681441b94e0c640180d9249ce09cf7af9e36e318af41f83dae2693af496b71bcdbddc44058d72de62f2b8f7c647e34e68f5284b744bfb4e998bf873ccda57171b594f5ff559fe95e1b5ed5fb49481dbc365655943473be41e467cbea3b578ad7652f811c388fe230a28a2b539c28a28a0028a28a0028a28a0028a28a0028a28a0028a28a0028a28a0028a28a0028a28a0028a28a0028a28a0028a28a0028a28a0028a28a0028a28a002bd43e08207fedac8071e476ffae95e5f5eaff01867fb77fed87fed4acaa7c0ca8ee7a5f93d70063b669861e338f6abfb339a6b26dedcf6ae1469b19c536f4ebdaa2994b2f3926b41a3cb1e327bd5731f14019b716e360c8e6b2ae6dc9246deddeba178f1b8edf97a74aa37116e527f9d525711cbdc5a6d241ef5957369b4123a1aeaee2d416391db19accb9b40abc80c29d8699c9cd0146240e2aa4b6e1892b8cfa57437167f7b00015973db94c903eb46c376663c916091d2a2f2faf22b4de2dd9ef517d9c31e467e95aa9232e433997f1a66d02bd4be1ad9f8275764d335ed3765eb1fdddd1b86457e981f7b835e82df007c23aa6e9638b50b35e81229d48fafccac7f5aa5288b94f9a4f00e2a16f71cd7d2137ecdbe1ac1d97da927a65e33ff00b25665dfeccf60e7fd175b9e1ffaed0abff22b56a51158f9f18e4102a3c75af779ff006619846c61f10c6f263e5592d4a827b648738fcab37fe197fc46cd84d4b4b23d4b4a3ff64a7cd1ee3b33c6bd78a01eb815eeda47eca9a8cb38fed4d72d2087238b48de466e791f305c71df9fa57a0687fb30f82f4fbeb7b89db51d4844c18c1733a089fea1501c7b67f3a3990ac7cd1e13f87faff8ca53fd95a64d3db29226bd642b6f00032c64931b5401cf26b0769fcabeaefda0fe2269bf0fbc16fe0cf0d47069b757eb896ded2208915b3060ff00771866381d0e46e271c1af94d69a6000e7ad3d7814d4e869d8eb4c05ef4eed4807bd0722a5abb11674dbb6d3efed6e902b3c122c8a1c64120e467f2afb63e077ed336de34bcb3d2fc432a25db5b9b476b963b7cb257949371618f9b860d804f5e95f0fa8ef56acb509f4eb98e782468a446dcaca4820fa835854a6a66d4e7ca7eb8690cf7561a7cfb84de4482113039f3233f29c37f103c37627838ab52f8363b96db1c50ab5bcd8042f3e4b0e878ec4ff00e3a2be37fd9e3f6a2bfb5b78f46bebd8d9c8d9f67b963b650768f932dfeb3e9f91afb23c13e38d2fc5b1acd697662b9316c9ed2621641dc9033caf279af2ea4274f53d1a728cf731358f04dc58a9410192089890610589439e08c74e3f4aced36f1f4713280b3306c343383bd54765cf207b74af4ffb5a32ec24b92bb49cf5eb5ce6b3a75ade9909b7d9718c09947cdc67bd10937a4904e096b0651b4f1041740451b193233e5b7de8fdbf0ab912c32b36cf95fab7b573b3694f1727724ebc89572adf8fad4d06af711324174163c72275cf3db9abb10a7dce856d42a818c81d0d0b0151f2d436b7e170246570d8c32f2a47ad5d0770ca95c1fd6a5dcda3633e68d338d8cedd72385cfb9359d7335f5bb318fecd0dba8f98846661efbb200fcab46fae663ba3b68cb9c637f400fa67d7f3ac6bed26cb44d2ae2ffc43a9086c6305d9e798951c64fdf2573c1e80526dec672d6f63cb3e2bf81b47f1f5b4b0ea960babdc79642def9659edfef0cab2fcdc673b7915f26f8a7f67ed5ad1efae3c3d1dcea7a7da825cde41f65973fdd4463b9f8c608033dabea4f10f8b75cf1beb3a269be1bd3e4d1bc357b7cb0ff68df07fb65cc4a0b3cf0479c080263f79d32401c902b67c5dfb2d687aeeb569a8ea1acead2eb378cb1da5ad91856180004b4ceae8e7099259b3e8072456b1adecf791c8a84e4dd8fcf67b596da578a689a2950e191c1041f706a7b504c9f415f747c45fd9bfe13f8674799f5393c47e21d49d4c714b6d722e2e13018fcb808800c74607af4e6be4bf885f0eeefe1eeac91cf05c5adadf2b4f650df2ecb9106e214c8b80324771c120fa575c6aa9e884a0e0ec722172dcf415a1a55dcda6dedb5dc32b432c322babc6486520f506aa46bf37d6ac20ede952ce8868d1d77ed177567a869fe11bbb42184d1ce59c63278870091dc64d78ad7a17c44bb5b9f05f84d4dc79b2c52de2b464f28310638cf43cfe46bcf6bb697c08e6c469518514515a9ce14514500145145001451450014514500145145001451450014514500145145001451450014514500145145001451450014514500145145001451450015eb5f00d7235effb61ff00b52bc96bd77f67e19fedeffb61d7feda56553e0638ee7ac04247183c54653271560608c77a4d8324e3f1ae1352a11c900118f6a8a584fdee4fa015764191d334c0bc1a0466b46e8b923a7a76aaf245bf92324f5ad4962254fa62ab18c600eb401912da8048dbd7a9aa1736a0f0056f4d6fb578c8e2a85c5bff002c55ad00e6aead828208e6b22e6cc8c95e9e95d5dc5a31c8c7cb597736a5588c60552d40e567b72a09038f4aadb7bd6f5c5a6d3c0acc9e0c1623f2a9b16b5d0ce7254fca70c3907b8af56f863f18a5b37b7d275a981846121ba7edd061c93d3debcae418c9aa920e0d344bd0fb2ad6f52f6dd658d83c6ea08707208f6a73105815e706be6ef877f15ef3c31e4e9d7ee6e34c2c006624b45c81c1cfddc0e95eff00a6eab06a56cb3db4a92c520055c302187b6286ac234c3f27352c5328359de6e0f1919eb9eb52c4c4039a57035609988ea0e3b8aa7e2cf140f0a784f55d618a66d2069115fa33e0ec53f56c0fc696190a91cf5acdf1ef87c78bfc15ab68eac126ba8bf7449c0f314ee4cf078dc067daae2f513d8f8cfc49afdef8ab5dbed5f5194cb77772995ce490324e14649c003000ec00acf4e0558d534bbbd0f50bab0bf81adeeeddf6491b8c1047f4f7aaf103835d2f6321ebd48a7a0eb51a1e0d3d476a374038d2a8a455a910648a2da06c5bd174a935ad5ec34e87fd75e4f1dba1ebcb3051fcebdafe34fecafa9781213abf85a49bc43a19da2487613796cd862dbd1570506dfbe38e7a57987c317f23e2478525c6e11ea96ce47ae2543fd2bf43ecf518356433c0e7739cb0ee0fbff8d612959d8a4ae8fcc986696d274962768a5460cae8486520e4107b1af73f851fb474da4cb6d65e229e6529858754849f313a0f9c96e4772473f5af6ef8b5fb2ee89f12567d4b458e3d0bc4453ac6812d6e1b2c4b48aab90c49e5c7e20d7c75e3cf877e21f86dadcfa5f8834e96ca646658e5653e54ea091be3620065f71eb55a4914a4d1fa4bf0ff00e355bdfe976ffda1731df5ac9810ea56c4383d3eff003f5248fcabd3ede4b6d5ed1678668e589be6578dc1cfe55f92de00f8abaffc3dbb57d3eebcdb5c9df6571b9a16ce39da08c1e073d6bebbf82dfb455a6b8f0ae957e2cafc8fdf697767e590f1928037233c7ad7154c3daf281d50add247d5d3e81f68b6c30cf70c3b0fad626a5e17b8b3859c27984a10acdcf634ef0c7c40d3bc465625b83637dc2bdb4cc1771efb0e7919edd6baa8753492530499994020205c9cd715ea44ebb5392d743ce219e6b54430b2b041f342fd2b62c357b796d814710ccc7061723afb0ad5d4f45826b932c36ab0c9202492980d5ccea9e1b679599e10831f7e2ce07bfb56a9dd5cc1de3a2376faf63410058cacaa7e50e3081bb671fcbad605dfc36b2f146ab16afe2f94dfd9d9b7da20b09df16f19033ba442318193f29cfb93c621d3352b8d25d12ecff685b7556277329fa9ebf5adefed28357963b3b5905d45200f7310e711e7ee1faf423b8cd438dd1519abdce4748d12e750f12cbe32d4dadad0de486d2c132563b4d161fde972a47cad2103711c6d641c5744ba8a5adbc9e29d6cc51c9a8136da544ab995edd8e6386346fbd34846ec0edb7fbb58de2cf17e93a8f8fbfb2edaf1e596dede3b3934b894179d99cb340ab9c65f10a9cf1b165e98cd6f0d248f18598be31de78d25b7f321b42775ae896d923ce54ecc395f33ab74e074e5774f53a534d32fc70c56d750acf6d1de6bb22878ed08052ce32722498f6231cb74c8e057c03fb55f88affc57f182fafaf353b0d56110ac36b369ec4a2c4af27c8f927e70492467b8e9d07db16de18f157c5ad46ebc33f0fae8a78621bb30f88fc56f29fb45e480e24b781d338386f60b9e3dfe68fdbe3e1d5afc31f893e15d02cacd6cad61f0f4522448a00c9b89d49e9c93b4124e492724d7561ea45c9c53bb32941a5cdd0f99234c7e353a8ce7229a8b8fad4a83f1cd77192d8c1f17ca5adac23e30ad29e073ceceff00857355d0f8b738b4cffb7fd2b9eaeea5f0238eabbcd8514515a98851451400514514005145140051451400514514005145140051451400514514005145140051451400514514005145140051451400514514005145140057affecf8a4ff6fe3fe9dfff006ad79057b17ecf09bbfe120ffb77ebff006d6b2a9f032a1b9eb68b8ce1718f5a52bd4e2a50b863dfb503014e4605709b3562ab27e1df34cd9c73d2ac327400fbd31a36da463f1a092b32e3dfeb51ba8504e339e9560e705702ab346c09ce698ac4127cc849aa6d18dd8c55f915c0391ed55655279ce0f6c5520336e2d8e5f07a1e87f1accb884321f9793ffd7ada932ead9e49aa534202e39ce6a93b0ac73b2c380d919c8acabab7c0660a48aea2e600e0823915993db246adbb93dbd2aed75726f6392b8b7ea40c5674c8c335d35d5970481ef58d756d9ce2a2d62af732c82060d759e03f8877de0fba58ddde7d398fcf112498f91964e719e2b9cf28f3914c68f0698cfaaf43d7ecf5ab58af2ce713dbcaa30dbb241f4383c1e7915a6a46386e0f7af977c21e32bff085f2b43233d939fdf5b313b58719206701b03835f407863c5b65afe9b1cf63234c98f9d072d19c0e1803d79a9680eaa3ca0049fa0a9ede666dd9c051d335996f7425c06c82bc9c0ab70b15662784639ef509d8426a1e0ff0ff00882e56e753d1ecb50b850009678119b193c648e475e3debc53f69ff0e59e956be1b974eb082cad93ce8596de258d73f211c281fed57bd4526d5e0e4e2bcaff0069f1e67c3fd3a4c0dc9a8a2f1ef149fe15bd396a4b47cc8839a7a52eda00da78ad93b9171cbd2a54e845440f5a7a9e0d37b01d8fc23b29750f88fa2c305bfda64f319d536eee554b038f6c66bebcf0278c16f2d2dee210d1b91e5cb038c3c6e3ef46c33c10735f3a7eca16b1cff17eca471936f693c89f5f957f931afaeaff00c27a6df3f9e908b69f7990b420287639e5b8e4e4e73d78ae6ab072778ee33a7d23535b9b61342d953c107aa9f43ef4cf16681a1f8ffc3d3e8fe21d320d4ada45608d2a297858a95df1b104a3004e1874ae3e1be9bc27a7dc5e6a73011d9db19256524a346992c79fe2c0ce7dabadd3efe0d4ace0bbb49567b79943a48872181190735946fd746697ba3e31f8cdfb286b5e0413eabe1a59b5ed0b701e4a46cf776e30c4970ab82800fbe31d7903a9f0bb4bab9d3ee639eda57b79e260c9246c559483c1047435faaf631497527971446490a9f957a9af17f8c5fb25e8df10daef54d2234f0df888af086311dadc3e589322aae43927971e9c835d0a77d1936b1e03f0dbf696bcd3841a7f8a0c977026163d423c99d3a0cb65be6f5cf5fad7d71e01f8ca2eec6d275be5d634ce36dddbb6645e876b1cf51e879e6bf3dbc75f0f3c43f0db5b974bf10e993e9f3ab308e4923611cea188df1b1003a9c70453fc15f1075cf02ea11dce957cf1286064b6724c528c8e197383d3eb4a50522e3368fd75d0bc4ba6ebb69e74128962231b9880549c71d783ed5be74cb69232c195be5c046c1c9c1af84be10fed1f61ae4f6f135d8d1b592416825702dee1b206d525b9c9fe13f81afaabc17f14ac353315aea0ff00d9fa86000ec4085b9006d24f079e87f3af32ad29435476d39a7a1b5aef840c5209adedd0291b88073ebec2bca7c69707c05a65feb8249adee63dd28b7b5cac9360160aa3b8e3bf15eee970f72e222e19491f3a9ce47af1d456278b3e177fc2671bc70db8d424797ec916d62acd2162a231c1e0293231ed853dab9a75a34e3fbc1ba77d62780f823c41a4f872d9fc432698d71f107c5edf6f8279b0e6dd6555dbb9b831c11823711e98e4902ba2f19788b539754d3fe12fc3fbe1e20f1bf8ba349fc41e25b7fdfbd859392ae0386dd185c92a87850c31cb0aefbe217c1e93e11785aff589208b53f105fc7f6481d90b9b72509d830015b588aee639c8009ea6bcd3e117c23f167c28b993c7961306f11ea619a4511b67ecec438495700866c02c3385e00fba0d66aa46a479a9bbbe8bcce88a707efec7d89f0d6f7c0ffb3cfc1db6d26cd05ae97a245e5c85820b8bcb8da3271c6f9a561c0eac4803b57c27ff00051ad364f15cde15f888a5da3bb3269d219dc8607fd6a4712630624cb8df9cb397ed8aea759f8a577fb477c74f07f830dc5ae8da1e857297facb994e2eef229002808620839555079dc5f93b6b92fdbdbe24c7e23d1345f0d69dfd9eba6695a8c892089879c274464288a0f11a03b5bfdac0ed5860f0aa8e21d48eef7b952e492ba3e348d7ad4814d2c4b93f4a942d7be6115a1cb78c0605a7fc0fff0065ae72ba6f1a8c7d8ffe07ff00b2d7335dd4be0479d57e361451456a6414514500145145001451450014514500145145001451450014514500145145001451450014514500145145001451450014514500145145001451450015ecdfb390cffc243c67fe3dff00f6ad78cd7b5fecd833ff00091fa8fb3ffed5acaa7c0ca8ee7b1ac7873cd23c676e00e2ac053ffeaa6c8a4f4c0ae12d6accf65c286e3d2a375ee3ae3a8f4ab8e9b7ef01b7daa27002b019e474a0a65329b949eab51c8aa8a7afd2ad796a2300707d055675dbf7875e9408ab315036839e33cd579130d9efed56994e369eb9fcaa265c64fbf41fcea908a6f10c9c0c5569211b72d8ad12a496200607d6abf958c92475a606635aab0257b73cd665d5a8dce0838f5fceba0687a90bc7722a8cf0707a1ab8b21aea72d73010482b8fc2b1ae6d36e78aeb6e2d4befc73d7f0159535bf0c304107f0c553147739892dbdaaa988e4d6ecf6b8ce0645519adfaf1506865b271577c39e23d43c2ba9c77b613146520bc673b2400e70c3b8e2a278f04f15098bad2b8cfa37c07e38d3bc6364a639921d4718781b00ae3ae39e464f06bb256645dbc3023a8e95f22e9ba85de8d7b1ddd8cef6f7119c864241fa57d09f0bfe27db78b6d63d3afd920d551782781281819193d7da93423bd8142a31033e99af2efda4b77fc2bdb3dc724ea51f4ff00ae52d7aa424163b4f23839af2afda5496f04d87385fb7ae47bf972734e9fc44bd8f9bc2d1f74d3cad318fbd6e6218e29e1b8a611ef49c80d57d0ae87affecaba87d97e2fd845ff003f16b345d3d837fec95f6b29de303a57c57fb2959adcfc568e661936b6334a39ee5913f93d7d970b8c119c1a96f50b0977a1c3a9c125bddaadc5acaa5248e41b8329c82083c1073d2b33c21e1d93e1fe9cba745733dee951be20f37978138c2e78c81838f418adf865c77ab11b0393d41e08a99fbfb847ddd8d1b1bef24a4d0498c8c8753c1ad1fed59ee76096669581c02d93c573f046200444b84fee0edf4ab70cc3183ffeaacb956ecbbf425f19782f42f889e1e9f47f1169f16a56d22958d9954c96ec411be2620ed6193822be2af8d7fb22f887e1d5bdceb9e1f8e6d7bc388e722342d756ca03316955571b005e5c607a815f73dadc41115dc5c9007dde95b00c6610237055864827d7d692938e816b9f90e8c50f04a91debd73e18fed0bab7854c361adbc9abe923e50ccc4dc4438e1599b0463f84fe62be9bf8e5fb22e85f10fed1ab785d61d07c44e06615509677072c4b3854cab92df7871c723bd7c47e35f02ebdf0f35eb8d1fc41a6cfa6de444edf351956650c577c6481b90953861c1ad935204ec7e877c1bfda0ecaead2c66b6bf8f5cd1d5d4cf6c1c7daad5303e50377cb81c6d3f2fbd7d99f04b5ff000a788edae3c436ba85b4d76e5e56b372892d8267f8973dd4aee7e848c678afc1df0cf8af57f08ea915fe917d358dc211931b101c039dac33f32f1c83c1afa87e127ed3f16a73c36daa5eff00c237acb294fb65bb98ada75e3e4625f8c9ce54e54e3df15e2e332e55d374dd8eea75f4e591fa937d6363f10fc5be76a10b7d8d023c6f1b8f2dedc3931c6c0820995be7603aa2463b9af36fda835093e19fc3dbd9f45b4373ae6b728d1f47b7b55cc8d7330708c00c7dce0fe43bd735f07ff690b7fb4dbe9fe25922b4fb4b7c9aa20fdc8c845576cb6142850011f2818e95ea3a43e9be3af88779f10351b98350f0af842d8da581970f07dad4f9b3de2ff0e5576a8707b37a0c7ce2854c24b6f91deadc9a6b73e37f1ee93a5fecb7f0534db29d247f1feaf87bab90e1ee5242a5a6b85276b622c707fbe467a935f3bfc5af0eea5a3f81f49bff0011dbc89ae6b174b7b6ed3ee69a1b331b95594903123bb3c8dc7cc72d9ce6beb6d6bc3d6df1bff68bbaf8a7e3a90db783b4083ccb3d36df66dbb8d64f32d2c991b21e6932cf2479e43c607dee3ceff6df9a3b5f877a745a9df432f8935bd77fb58d8ed50f636a20748edd78c848f705c74dc58f24d7bd87aadc942dd3532e4de4f73e3785320e7ad49b73f4a20518c54c7a57a84a392f1bae0597fc0fff0065ae5abaaf1d0c0b1ffb69ff00b2d72b5df4be0479b5bf88c28a28ad4c428a28a0028a28a0028a28a0028a28a0028a28a0028a28a0028a28a0028a28a0028a28a0028a28a0028a28a0028a28a0028a28a0028a28a0028a28a002bdb3f66ae3fe1233c7fcbb707fedad789d7b5fecd640ff00848f278ff46cff00e45acaa7c0c68f6f0063a8e7b531c6d036f20f5a03f271d08cd3086ea08cfbfa5711431937646338aaeff7c8033818c9ab07e66c13c540ccbf30e738fce90d15d9bb9ed55a4e093c6dab2fc061f962a075214f00e719a0bd8ae7be54fa8a42018fd01fcea5032e78e7f3a1e32323a6074a05b32a3210a180391f28fa54054107b60fa55d50403c8cf5e698c0ed60a00e3a0eb5484502855f3c119e9f9d55b989776318e3d2b4fc9c70c3af19a864b6462c172d81952315a4496624f6e4ab90a01c7e759f736598c009827a9e739e7f4ae85adcee19e0e7b9e9552e2d8231e5be7e84739e6ac839496d705815edf95674f6454fddc64679ef5d55dd9ae59915941e84f7acd92d8e483f36df968039992d339e2a9cb015cf15d2dcd885c918fc2b3ae6d40078ac59a27730cc600e9496f713585cc7736d2b433c4c1d1d0e0a907208ab5343b73c62a9c8060f6a48a3df7e167c5bb5f12c50e93abcab06aff7525621527e80753f7c9ed5c4fed21aebcde22b2d1524061b383cd9154f3e63161c8f655047fbc7d6bcbc4ad0c8248dda391082aca70411dc557d4352bad5efa6bbbdb892eae5f1ba5958b31c70324fb0ada2ada99c9f42b374a6e0834f232453075ab321501a5db4aa734e2bd698cf7bfd9174756d6bc41ab1dc1e0823b65c7421d8b37e5e5afe75f4f412807f9d7807eca2562f086ae76804de8190393fbb5e3f9fe75eed1b8c706b27bb2ec6ac4c18824f43c7b55c89b3d0d63c5260f5ab513991595999578e54e0d0a43b686bc6db8d4ab81fef551463b491cfb5598246db9c63d8d5925c866c360f07f9fd2b5f4dba24ba1232471c562ec59530dd3d8d4b0bbc1821b207f177a871b8266edb1d84f9a5973c8dbeb593e3ff0000e81f13fc3d268faf58c37d0bab2c72b2813db31046f8d883b58678fd41abb6979e6a8dc4161d0d5d5963738048239c8ac9dd6a5791f027c6efd947c43f0c1aeb54d215f5df0e2b9db2428cd716e98639982ae3002f2e38f50335e248306bf5bb724aa438f3148da4100d7cf5f1bff641d0bc6627d5fc1d1db787b5bf97367811d94e06ec9c2a651ce47238e3a0ce6b48cefb85ac7ccff0dbe3a6b9e0b582c6ea53aa68ca40304c49789781fbb6cf18038078afb03e117c7dfed1d01ecb44d5db50f0f5dba36a3e1f99c2ee8f7ab4aa572766f505188c82091cd7c17e28f086b5e07d6a6d2b5cd3a6d3af62270b32150e0315dca48f994953861c1a6681e20d43c3ba9457da6ddcb677511c878988279ce0e0f238e86a2ad1a7595a68da15250d8fd5dbaf13781fc6b247776b67168f61a64efabc9a6dd3c71b3ddee6612e01c345126d0a71d40e9b457cb7fb5fa3ea7e1bb0f10dd5834d79aa5ea490dfa447cbb5b2d931b7b72e7f8e4cbca547a0f415c7f807e3ee9be26863d37c52915a5cc80c5f6c40044c08c1dd93c672727a5745fb47f8ef53d4be13e97a0cd7306a3a74bacaea11df6732b6db630aa647ca502e48c6396ae4861dd1768ec7646aa99f395b9e6a70339cd55848f5e6acc6739adf6345b1ca78e863ec5ff03ffd96b95aeafc75ff002e5ff03ffd96b94aefa3f023cdadf1b0a28a2b5310a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800af69fd9b4e0f88b8cffc7bff00ed5af16af69fd9b80cf88baffcbbf4ff00b6b5954f818e3b9ed7181f30c673d31eb48a4b1038009c75a0128c481d7bd0caa0127b7b5709646dc3e073cd318967395c1cf4238a555393803d8d2b72181ebd801cf7a00af21cb3202383c1a8d81c0503209a9da338c6cc607d4e79a8c039c0e09e940efa5880aecce460d318673d39f5153b2b32738c8e393cd279631824138fe1fe54125523e5faf434c20f3b813c75cf5ab5b54201804f3f97a54727091e3273c703a53432b302c50f519c7cc781ed50b204ca018efb8f7fa55bc6d2411cafa8ef4c76dd863190b8e33c0cff0085520b74334c38072311939e7af7a85d7cb57daa58905371038ad56442ca4818183b7d7dbeb555d46f62170a474dbc7f9c55a33316643b97d86003ce2a9cf6ebb091f7b1c8238ffeb56d98396c05e3d45539e367c8185c9cfa7e34d6a061b5bee0462b3aeed304f1ed5bd342464f56e87bd529a3ea09c1eb9f7a2c55f4b1cbde5ae378c60fa560dd26ccd75d7d66c15982965e7e615ce5f44b8236e0d45ba157d2e60ccf9c8a83d78cd4f2ae246151e3ad6e8c4605c67de8c62948db4e519a00551c629eabd69634e2a531ec14c0fa43f65e8bcbf04ea131e0bdfb2fe51a7f8d7b541213debccfe0568c743f869a6ef52925db35d9cfa3602ffe3a16bd12ddb3d4f1ef5caddd9a9a9148481deae40e4a738191dab2e173d3b7a55d81c63938a7b8b635ada4c0c67f1ab2afc1ace89c609eb56e062401d2b44fa09f7342ddcece7afb54c670807ca5c938c28e955200001c8ab4071c74f4ab236248e42adf2f1ed56a0b9cf01b0475f5aac982791cfbd2941d4fcac3b8a9687735e1b8e7ef66acb1574c1391d722b1239cc780e700f19ec6aec53ac58c74279159345230fc7df0bbc39f133459ac35fb08ae18a9582e42a89e024758dc8383d0e3a71c835f177c62fd98bc49f0ce6babfd3ade4d6fc3aacccb7102334d020c9fdf285e30072e3e5fa6715f7b8b9418e011ed564c69221c00c1872a79c8f4a6a56dc6b7d0fca281caf39adf1e23d46f74b834d9ef669aca17df1c2ee4aa1c63804f1c1afadbe317ec8ba5f8abcdd5fc230c3a16ad231692d5be4b4914063c2aa12ad92a38e38e9debe47d67c35aaf847579b4dd62c26b0bb8bfe59cca46e192372e7a838e08eb4dbbec6d4dabf992db9c9eb562338aa709c1e3b5588db8279cd61d0f416a737e3839fb17fc0fff0065ae5aba8f1b8c2d8ffc0fff0065ae5ebd0a5f023ceaff00c461451456a6014514500145145001451450014514500145145001451450014514500145145001451450014514500145145001451450014514500145145001451450015ed9fb348cff00c247dffe3dbff6ad789d7b7feccf8dbe25cffd3b7fed5acaa7c0c68f69de3eefe228239e70c08e714ec32ab9299e78cf38a39d9ce738cf0303ff00d55c25d8aecdd40c71c1c75a6950bb4e3e5cfdecd3e342c4e4e7d4f6a491014180720f0339fc6802150417e771c9e47a7bd05769f98023da9de526cc7277039038c1a458d4864276aede0714011c926f5390a31dc7a7bd46176b821474c923f9d4c146d25403c6d20f7f7a7245c73c9618c03f5eb4015ca7cae1718ebd39a698731edf9b18ce3e956361453b95413d33d314d270814e33d38e281154ef032bb73d4e7d2ab60956ebf7b1c1ff003c55b2a493bc6d078233cd44d0ef5621401c0c838aab8ca8d191229420ef1c0039e491f854c22dd1905808d1719ebcff00852b41c060a7cbc6dcf5c52c0ac0e4ee1db8e063b03551135d4a13c2aa0839638c703a55436a481b81e9907a1c7e35af20370cc368518fe1ef51c9022a29f95b001ffeb55a48930ae6d8003be47a5675edbaec384e73f29f5ae965b50c402d904741d8e7a5675d420160bc9f5a047313c6638b254b10dd0f2b8e6b94d6edc2ef74e9f78e3a77aefb5085941dd809e5ed00281dcfebef5cf6af691c90dc2471be0a301bbaf43d2a901e672312ec7d6901c9f4a7b4586231ed42463b5512369541a7aa9a7ed38e6a751a1b1120d5ab1826d46f20b3850c934eeb1c6a3bb13803f3351245f29ad3f0b6acbe1df12e9daa340b70b6932cbe5b743820fe7c71ef4fa023ec5d1749fec8f0ee97a724847d8ede287701cb6d50bcfd715a713608e3207a560784fc67a6f8cb4a8aff004f9832b0fde4648dd137f75802706b6924f7fceb91e86c8d18a41ebcd5c825001ac847dadc722ad4738247a53b88d9864c0e4e055c8e62075c66b1a29f9ea48abd1483e5186393fa55a07b1b36d21604771cd5c8e4e3fad6440d823924fb55ff0030ae7f95689999750835246c39cfe46aa4728e303eb53c67273919f4aa4ee2b16062452080cbd08a4855ed73826688924863965f61ed4c46ce706a78f04633f350d5c13b12c52c7326f89d5c0254853f74fa1f7abb6527ce096c9e9cd6688ce4941e5b67391dfeb562d18c8e55bf76e3b1eff4ac9ab6e52f2362e658d2d676964548d636dcee70aa3072493d00eb9af887f69ff146a9e27d5f4d95ad3c8d06047fb0ca06efb42b4b2aacdb80fbae2225067955cf7e3ebbd7eda4d5fc9d1637536d71f35f86e775b8c868c7bb92060f55dfdebc17f6bcfb0d97c3cd36da3482d6e27d553c8b78d554a5b4314a88aa074405f38e80bfbd64b768da0f53e5980e7156636201aa76e7e6fc2aca7def5a1abe877c3539ef1b72b627fdff00fd96b97aea7c6ff76cbfe07ffb2d72d5df4be047056fe230a28a2b5300a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800af6efd99c0ff008a933ff4edff00b56bc46bdc3f664191e25c9c0c5b7fed5acea7c2c6b73db8ed2720670393efcd4654b633df8e7a7e02a650154f03fa9a629cbe320f1919e05701688c8da08c75a888fde28da4a8e9b074f7a998860e0fe3cf4151eef971b8051c02dd703fad0046f87c315009fe151d48f5f7a6828bf3101b3c600e952fccd1ab96d8579f97d298c53700b9618cf3cf3ea3f5aa0181577165f9573f7474cd0c06d6cfaf23b52ae4649639ec7d283c28f90b21e72e3a9e7bd211146858e5b38cf039a5d832c003c70334e1fbc3263e541ced18e948a70a4a29015782ab9e7de900cda0a1c29201f980ea2a2940fb3aa92c08e42b1e38a9c1185c3ab6473ce7069bb0e4b3a1d89ef939cd52194e3704c8368c15209cf4a595429f9f078ce50f03ae09a7b1550cdbb9fe1ce0134d8db7a866c382718c9c86cf7a0023545f99082d8e3be7be7e9511411c586c6e6e391cf4ebed536c3839186ce3e53f28a84210db5dbe5272777181d335a264b2bcabb54aec1f81aa770810640047b7209f4abeea651f74039c9232302a8c88021f9f9cf037103afd2a7a8d2ba33afe15b83273b5153761bae7a605616ab6fb301501453c9030c477c9fc2b7ae61c285dc4e581de0645645dc21e79ad959e5690ed0cbd58f3c63d2ad321e8ec7966bd646cf57b9531f96acc5d17d0126a8055cd74fe3cb36b6d4516472594140aff007b683804febf9573d14608ad092340bdaa4030381520833d05588acd9fda9015ede2324aa319ab5a8daac7b0803918c0ab514715b80c482476a86ea4172c3030ab49bb2044de18f11ea3e13d4e2bed3a7689d082f18242c801ced600f238afa53c03f1274ff1b59feec982f900f36ddd8673c72bcf2b935f2f88aade9b7f75a2df4779653b417119caba1c7e07dab9d9b23ec78ae372eee80f18ea455e8e3f2c9c7cc7debcd7e16fc4bb1f14c315a4a52db5851874938590faaf3ebdabd3215672a010b93ceeedef52975196adb90370dbed571242800eb9c01cd56e412809902fcbb853adf76429c91d053d856356090b1049c01c568a5c0d9807a0c7359305a5dee0043294eb9d84fe557521b93f29b69703b943fcead5d90d17165c8e0e79a983160007dbcfa75aa84bdbb9de86304f56079a904cbc85e077e6a846824813bd4a1f70e4f3e95989295ee769ab56f36eff00688e2a901a0921036b73e98a90859170c3207423b7bd5159c2be09c83d855849c28da06ecfe94f7118dac6a3ae68b2bdd41609abe9e91fccb6cfb6f3764f40d85618f70735e01fb4c78b744f19f81ec6e6c65cdf5b6a6b6b25bce9b67836c52ef53c9fe22324120903938afa6a6693ecf2081d5262bf2965ca86ed915e03fb5a689143f0ef4ad45d523befed248e54b705626668a52cdb79e72a39fad63ecb95dd335a6eeec7cb56ebd38ab0ab8cd4708f6e956625acdbd0f461b1cc78dc616c7fe07ffb2d72d5d5f8e4616c3feda7fecb5ca57a14be0470d7fe230a28a2b5300a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800af72fd98b1ff152838ff976ebebfbeaf0daf72fd988e3fe125e40e6d493dc0fded6753e1635b9ee2571b470700363b5464ed2c7819e831539e7702588237063d4d3255000e016e091e95c25a21f28eec86038c100f06a19542bf4524ae7e53d3ad4ee4fcd818eff002f4a85972090096cf38ec290c6609c2ef51b467e7e338e7033fca90b02015e00e38eb4ac8377cc0e7b53820c6e1f7c9cff00f5eaae222046394181ce0f3f854782a78e9534808eadb875ea38a8e4caeec6067bf6a91a571a1433ee390718c938cfe3427cccc109c16fc48f7f7a6e5b23277a9e83b75a92d9b13338281b07861c0fa7bd0b504ac218f64595609ce08ef4d6898c5b9b0411c1639cf5e295d97792dc83f30db4c76fe13c28c103a71ed40fc863fca01c2eee8368e0673ed51287f2d9403b786e9dc7afb538aee2594607538f5a72b16214b6cdc3ef13818cf7a64dac3244cc4550b1390c5bd7ae71fecf4a89d44a1f69523a74040e0e702a67923601137b328e49e077ef519dc91b70369e80f6aa02348048783c05dc32393ec4544d66aa8ef28daa1880a400dbb04f43daa5768e46e01660990106483e84fa54176a65f3a37c01c90b1938cff78fb63f1a681ec655e471dd4f028591559b6baa30c81fde1edd79ae7f53b728485c46be6ecf31c9073f53e9919ae82e21f304b3423968c44af23608c9233827d0571de2f94d9db480e54b2f9470d9cb0ea7f4e6ad199c378825375ab5ce6412ac4c634707208048c8f63d7f1acf8be43d323bd4ec992d8a62c4476c558916a12980c39e3a549e61ec48155e3859b181c5594b7c9193dfa5437a0585b48965b88c30ca1600fe75a5a8e8c2391a4806623dbd3ad3f46d38dcdc0250f96bce7d4d7426d782bb72a7d6b1bdca5a1c5ac07072bd29ad0d6fdfe966225d14f3e9598f011daa1bb168ab6b34d65711dc5bc8d0cd130657438208e95f40fc25f8c51eb863d27599163bf2008a73802539036f27ef1cf41d6bc08c5c6698bba3757426375219594e083d88a13ea523ee02cb2230c320006eec6ba2f0858acf33c92a861101b41ea0d7cd5f0afe365c335ae8de20b842a8bb21bc7e198f000724f3f5afa6be1fdd0bc86e248c87565420a9c83d79fe55ac35644b44747e746b722db91215dc0638c74a73910c6ceedc28c9359b7c65ff00848214819564301cbb73b467a8f7aaf05fde5bdc6a3677320b8786232a49b7191e845745f732b1a4561bfb6c901e375c826b9559f6ccf1838d8769c9e0e0e2ba6d3ae4dce9b04cd852c8090062b85b9bb3f6d9c1f946f3f8f26b29f465455cec61093692ae132ec78da327350ec9a08c9789901ee6a0b2d41edfc35e74780fb8804d4da76a725f69d74b3112346a486c7b1aadc45c59505927ee8efce37e3fad5bbd5113c7b576923b56779c5345819875607f9d6ce158891fe7d8836a77a68456f2dc1e5082dc838c66bcaff6abf0ceafac7c2eb28ec74eb9bd923d4e291960899d82f9337cc4004f71cfbd7ae69773f6dd441932360c853d8e6b9df8c13dcc5a468f751f896d3448e1d563926fb4cdb1268f649ba2e480491ce0fa67b552d469d99f012c6e92323a9565382a46083e956235aef7e3a41a28f88535ce89716d736f7702cf335ac8ae8252ce1b95e0138048f7cf7ae1a1e2b82a2b687ab49dd1ca78fc616c3feda7fecb5c8d75ff00107a587fdb4ffd96b90af4287f0d1c75ff0088c28a28adce70a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800af73fd9801cf894e46d1f66273dffd6d78657b97ecc48ce7c4aaa5467ecdcb1c7fcf5acaa7c0c6b567ba24837704601e73dc7b524a4b39c100fddc7b73cd4ab1a942b93b80ea3bd23a72a18b1280671e9ebfad7158d5685731e1fe5e71df1c7d2a1933b89c94c924841818f4152cdf2b060d8040e7152123cb565036639c81c9eb52b51b2888dc1c86c1eb827ad226e76e46e6ce066a6626691f0437b9edf4f6a6b47e407c94917690402793ed40acc8de458c0c28f9b9cd24ae536e4028c7238fad3654288b8239c70c69b19264653d15792ca71df81ef40b944c824ae47cadf2e39fc691223e601c95cf27fad4801f91c85da78c814edfb235894aba862c1c0e4e71c67f0fd698d09244cd921130171b471f2fad5360016419c76cfa74ab32cade63c601c16c73d7e87daa0085a52aebb400705c7eb93406c2a8211828dc0310474fc7e94c5507e619c03ceefba0f3d2ad46aa536c7b647c649f6f403d6a1f21412ca4800e7616c7e94088a455dbb0a92ec4f2707a8e2a35c4c0287191c316cf27ebeb5338308318da11c798719c83d054528c0dc5d8af0e00ec6a90911ac3f36ddc4055dd9230073df354a7884cc6204365b03007073cf4eb56e70542e2191fccc125390a32704fb7155917cc2031dca790a3711d7afe54d03d8a12db4599a665977a2f980edc679e73f4f6af2bf14eaedaaea2ecc4f94bc28fc4f3f8d76fe36d51ace27b68772b5c2920b13f2c6491c7e23f4af389a37c91dab68ab18951106f381915616007195cfd29b121df8c56e59408e1030c8fa555b4114edacc040db7f4ab5a7e952dfbb88d46d5eac6a5bb85e3c44aa1476da3b7a9aea743b04b6b2455525d802c48efe9584f5d0a8ab9169d6296702c6109c7723afbd3deda407701c77e2b4ded8e41e471c530c791d326b3344b531e588156561923d2b0751b1f2db7a8aeba7b5c06c28240edd2b1ee21dea571d7da93572968730471f5350c89804d695eda1424a8e9e954197359ecc65603bf4c57d37fb23f8f27b89f53d02fee5a60912cd6ece724282148e4f4e56be682b9ed5a7e17f12ea5e0fd661d4f4bb96b7b98bd33b5d720956008ca9c0c8ada2f95dc4f5563f435ac0beb515fab02821f2f603ce739cd53d4b47ba92f6e2e6cde206687c975973ea7918af9bfc0ff00b5a6b275bb2b2d76d6c058cd2244d345bd3cbcb01b98b39180324d7bbde7c4fd3ee2259346b8835288fde9a2903a7d01535d1cd168caccde8edbfb3b4e8a3ed1c7863dba727f4af2e96f7ed12cae3728321e7f1ad7d4fc697fa840621e5471b707cbce48f43cd73a5c73b7f3acaa3525a0e2747178823fec0163b5bcddfb8b10318fceae685ac456a268e7dde548bb495ae7eca7b48d6dccc0390771db8e79c60fe59ab31ddc06d2108d18757cb6e1d467bf19c51aef711d3cdabdacb691db5b799e5ab64b38c1ab32ebdba689edd98055c1dddfdbad6126a16a249b94e63c64018ce0f4fc7e9535a5ec2e2d9d9536aa8f317001271f4aab88e88788638e586e208d84c302446e8c3bfe35c5fc78d6fc22be0bb2bef105a5ddcdbc5a94522dbdb853be4f2e5c060c465719cfe15d35bc9672dc12ae888369cb81d0751f5ae2fe3a7f669f01e92d335b25aa6bd6a66170aa77479707391d36924e4e319fc6a2df5638ee7ca9e27d5ad35ef11dfdf69f61169b672bfee6da240a11470381c648e4e3b93546319aeabe26dee857fe20b797c3c201646db0de442b17ce2493ef2aa819c631ea36e4e6b988793ed5c93dcf4a9b393f88231f60ff00b69ffb2d7215d87c4218fb00ff00ae9ffb2d71f5e851f811cb5ff88c28a28ad8e70a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800af73fd9889dbe26c2e71f663bb1d3fd7578657bc7ecb5bb678a767dec5afd4ffaeacaa7c0ca8ee7b933ac4b1b0f4fccd42f70cf0f500e7007b7d2a564f9090fb9c37dd07da9218f2f9720f070715c5735d111b233a21c264aed21bb52cd0b48aa0ed2de581f2f031cfcc6a57649402502aed201ff006bfc3fc6868a491d01daff0028e5c670b8e3fad2b0ae53c2a208d93058ee590138c773511037eedccf9fa7e9ef57157cdc8281622bb159c700e0e2a101d08597321c00075007a807bd2b0c867dcce0332a9dc4124e001fd2a285c4692028c72db813df9ebcf5ab12a40143429842c7696c65bb73efc551b92e436e8d7630da5501047d7de8db505d89da570372a98c647dc1800e4d429b778593bb750bdb34e0ab1c71042eb1000039ce48eff87e74c8c390d279ad83f28ebcfafe1400e99152473869a108319e3e6f5c0cf1d6ab2988966e376303b0f6153c65c1e5812a380e78c0a4550aabbd6261d4e481f8d3241650646c011a9032001807bfe19a71db23fdc567031fbbcf38c924e69801c062b94ce03673f5c53d272c1c82781d4f5e9da9dc0246662d1800363002e4e71d8fad5336cec4953b005dccb8c648eab8fcaad4b9c9901c00b904f5183c64fa9c5573b99d8f2ca33d4f63df07dcd34045732aa46e55cfcf852a83008e7fce6b2f50b98b4a8a59e64686054dc320e587f740fcab426091c91e70c480ec413c727208fcab98f1131d5355161bbf7113f9b23a9fbc7b29fc2ae0aecca4ec735730cd7f34b7b2f02524aab67e54c9200ac8b9d3823332a8c1aee6f2248e22bb576815c9ea09ba52a9d4f4c576a8a48e7bdcc882041300c3e95d00820b7b6472a15b159b0b41a76e6b81be7c655323f5a6c73dc6a12aa00646739118edff00d6ace4d2d0b5d8d0d36d1f53d4131800b64e7d335da5adbc712156fa7cb591a3e95fd9f0abe7f7cd82c7d2b7201f282f81f2f1802b91bb9ba4308421549c7bfa54136048cb8e01e6adb0551cf5cf50074a8da1f9b7965619fbbdea52be83b9533b94a84cf6accbfb50bf300471ce7f1ada910203c32b8e873c62b3ae41653bb91d3355ca09dce7ae1148618e2b16e60d84e17deba4bbb6084107b743dcd64dd47c3e066b36ae527631f8240346d0322a59613ce062a2eb9a12b06e57916b7fc17e39d47c1ba847241333d916fdedb364ab0ee40cf0703ad613d458dc0d303eaaf0ef8a6c3c4d610dc594eadbd46e8d88dd19f43cd69872d8c75e95f2bf863c59a8f84b504b8b399953204909c95719e78fc2be83f07f8e74ef16d9acb6f218e703f7b11c7ca7db9e9cd34c86ac748a704e78352a363ee8cfd2a15c31241e3d6a48f824e6905ec8992470304e2af5bcec23c1395c609f5acde723a7d6a7490ae475c7614af624dbb4b93955fba48e066b82fda31d8fc3050483bb5088609ff624e9f957596d39520a8e07b76ae43e3c4893fc2db938dc05d4241f43923f9134e2ca8fc47cdf0e41c76356e1e0e7155a1c0e31cd5a8c0ac9eba9dd076394f885c8d3c8ff00a69ffb2d71f5d8fc42184d38679fde7fecb5c757a343f868e5adf1b0a28a2b7310a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2803ffd9, 'Fr. Agnel, Vashi');

-- --------------------------------------------------------

--
-- Table structure for table `timetable`
--

CREATE TABLE `timetable` (
  `mon_slot1` varchar(255) NOT NULL,
  `mon_slot2` varchar(255) NOT NULL,
  `mon_slot3` varchar(255) NOT NULL,
  `mon_slot4` varchar(255) NOT NULL,
  `mon_slot5` varchar(255) NOT NULL,
  `tue_slot1` varchar(255) NOT NULL,
  `tue_slot2` varchar(255) NOT NULL,
  `tue_slot3` varchar(255) NOT NULL,
  `tue_slot4` varchar(255) NOT NULL,
  `tue_slot5` varchar(255) NOT NULL,
  `wed_slot1` varchar(255) NOT NULL,
  `wed_slot2` varchar(255) NOT NULL,
  `wed_slot3` varchar(255) NOT NULL,
  `wed_slot4` varchar(255) NOT NULL,
  `wed_slot5` varchar(255) NOT NULL,
  `thu_slot1` varchar(255) NOT NULL,
  `thu_slot2` varchar(255) NOT NULL,
  `thu_slot3` varchar(255) NOT NULL,
  `thu_slot4` varchar(255) NOT NULL,
  `thu_slot5` varchar(255) NOT NULL,
  `fri_slot1` varchar(255) NOT NULL,
  `fri_slot2` varchar(255) NOT NULL,
  `fri_slot3` varchar(255) NOT NULL,
  `fri_slot4` varchar(255) NOT NULL,
  `fri_slot5` varchar(255) NOT NULL,
  `sat_slot1` varchar(255) NOT NULL,
  `sat_slot2` varchar(255) NOT NULL,
  `sat_slot3` varchar(255) NOT NULL,
  `sat_slot4` varchar(255) NOT NULL,
  `sat_slot5` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `timetable`
--

INSERT INTO `timetable` (`mon_slot1`, `mon_slot2`, `mon_slot3`, `mon_slot4`, `mon_slot5`, `tue_slot1`, `tue_slot2`, `tue_slot3`, `tue_slot4`, `tue_slot5`, `wed_slot1`, `wed_slot2`, `wed_slot3`, `wed_slot4`, `wed_slot5`, `thu_slot1`, `thu_slot2`, `thu_slot3`, `thu_slot4`, `thu_slot5`, `fri_slot1`, `fri_slot2`, `fri_slot3`, `fri_slot4`, `fri_slot5`, `sat_slot1`, `sat_slot2`, `sat_slot3`, `sat_slot4`, `sat_slot5`) VALUES
('hist_civ', '', 'sci', '', '', '', '', '', '', 'maths', '', '', '', 'maths', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `toppers`
--

CREATE TABLE `toppers` (
  `sr.no.` int(255) NOT NULL,
  `rank` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `score` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `toppers`
--

INSERT INTO `toppers` (`sr.no.`, `rank`, `name`, `score`) VALUES
(1, 1, 'Monali Nayak', 985),
(2, 2, 'Purvesh Jain', 845),
(3, 3, 'Gurvir Singh Pabla', 784),
(4, 4, 'Naman Lazarus', 654);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`username`),
  ADD UNIQUE KEY `sr. no.` (`sr. no.`);

--
-- Indexes for table `attendance`
--
ALTER TABLE `attendance`
  ADD PRIMARY KEY (`sr. no.`);

--
-- Indexes for table `batch1`
--
ALTER TABLE `batch1`
  ADD UNIQUE KEY `rollno` (`rollno`);

--
-- Indexes for table `bio`
--
ALTER TABLE `bio`
  ADD PRIMARY KEY (`quest_id`);

--
-- Indexes for table `bio11`
--
ALTER TABLE `bio11`
  ADD PRIMARY KEY (`quest_id`);

--
-- Indexes for table `bio12`
--
ALTER TABLE `bio12`
  ADD PRIMARY KEY (`quest_id`);

--
-- Indexes for table `chem`
--
ALTER TABLE `chem`
  ADD PRIMARY KEY (`quest_id`);

--
-- Indexes for table `chem11`
--
ALTER TABLE `chem11`
  ADD PRIMARY KEY (`quest_id`);

--
-- Indexes for table `chem12`
--
ALTER TABLE `chem12`
  ADD PRIMARY KEY (`quest_id`);

--
-- Indexes for table `faq`
--
ALTER TABLE `faq`
  ADD PRIMARY KEY (`sr. no.`);

--
-- Indexes for table `marks`
--
ALTER TABLE `marks`
  ADD PRIMARY KEY (`sr.no.`);

--
-- Indexes for table `maths`
--
ALTER TABLE `maths`
  ADD PRIMARY KEY (`quest_id`);

--
-- Indexes for table `maths11`
--
ALTER TABLE `maths11`
  ADD PRIMARY KEY (`quest_id`);

--
-- Indexes for table `maths12`
--
ALTER TABLE `maths12`
  ADD PRIMARY KEY (`quest_id`);

--
-- Indexes for table `notices`
--
ALTER TABLE `notices`
  ADD PRIMARY KEY (`sr.no.`);

--
-- Indexes for table `phy`
--
ALTER TABLE `phy`
  ADD PRIMARY KEY (`quest_id`);

--
-- Indexes for table `phy11`
--
ALTER TABLE `phy11`
  ADD PRIMARY KEY (`quest_id`);

--
-- Indexes for table `phy12`
--
ALTER TABLE `phy12`
  ADD PRIMARY KEY (`quest_id`);

--
-- Indexes for table `quest`
--
ALTER TABLE `quest`
  ADD PRIMARY KEY (`quest_id`);

--
-- Indexes for table `signup`
--
ALTER TABLE `signup`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`username`),
  ADD UNIQUE KEY `sr. no.` (`sr. no.`);

--
-- Indexes for table `toppers`
--
ALTER TABLE `toppers`
  ADD PRIMARY KEY (`sr.no.`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `sr. no.` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `attendance`
--
ALTER TABLE `attendance`
  MODIFY `sr. no.` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;

--
-- AUTO_INCREMENT for table `bio`
--
ALTER TABLE `bio`
  MODIFY `quest_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `bio11`
--
ALTER TABLE `bio11`
  MODIFY `quest_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `bio12`
--
ALTER TABLE `bio12`
  MODIFY `quest_id` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `chem11`
--
ALTER TABLE `chem11`
  MODIFY `quest_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `chem12`
--
ALTER TABLE `chem12`
  MODIFY `quest_id` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `faq`
--
ALTER TABLE `faq`
  MODIFY `sr. no.` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `marks`
--
ALTER TABLE `marks`
  MODIFY `sr.no.` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `maths11`
--
ALTER TABLE `maths11`
  MODIFY `quest_id` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `maths12`
--
ALTER TABLE `maths12`
  MODIFY `quest_id` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `notices`
--
ALTER TABLE `notices`
  MODIFY `sr.no.` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `phy`
--
ALTER TABLE `phy`
  MODIFY `quest_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `phy11`
--
ALTER TABLE `phy11`
  MODIFY `quest_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `phy12`
--
ALTER TABLE `phy12`
  MODIFY `quest_id` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `quest`
--
ALTER TABLE `quest`
  MODIFY `quest_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `signup`
--
ALTER TABLE `signup`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `sr. no.` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `toppers`
--
ALTER TABLE `toppers`
  MODIFY `sr.no.` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
