<?php include "../../includes/calendar_entry.php"; ?>
 <!DOCTYPE html>
  <html>
  <head>
      <title>Synergy</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
 
 <style>
     body{
         background-image: url(../../images/cal.png);
     }
      div.row {
  background-color: rgba(255, 255, 255, 0.8);
  border-radius: 30px;
  padding: 10px;
  margin: 10px;
    }
      </style>
  </head>
  
<body><br>
   <br>
   <br>
   <br>
   <br>
   <br>
   <br>
   <br>
   <br>
   <br>
   <br>
   <br>
   <br>
   <br>
    <div class="container">
    <div class="row">
            <div class="col-md-9 col-sm-12"> 
   <div class="tab_panel tab_panel_5">
    <h3>Calendar Update:</h3>
    <h4>Please fill the form given below to update the calendar.</h4>
    <br>
    <form action="" method="post">
       <p>Date:</p>
        <input type="date" class="form" name="date">
        <br>
        <p>Month:</p>
        <select name="month" id="month">
            <option value="january">January</option>
            <option value="febuary">Febuary</option>
            <option value="march">March</option>
            <option value="april">April</option>
            <option value="may">May</option>
            <option value="june">June</option>
            <option value="july">July</option>
            <option value="august">August</option>
            <option value="september">September</option>
            <option value="october">October</option>
            <option value="november">November</option>
            <option value="december">December</option>
        </select>
        <br>
        <br>
        <p>Event:</p>
        <input type="text" name="event">
        <br>
        <br>
        <input type="submit" class="btn btn-success" name="calendar_add" value="Update">

    </form>
</div>
    </div>
        </div>
    </div>
      </body>
</html>