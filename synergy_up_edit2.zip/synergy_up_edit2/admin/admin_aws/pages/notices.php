<?php include "../../includes/notice_entry.php"; ?>
  <!DOCTYPE html>
   <html>
   <head>
       <title>Synergy</title>
         <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<style>
    body{
        background-image: url(../images/notice.png);
    }       
     div.row {
  background-color: rgba(255, 255, 255, 0.8);
  border-radius: 30px;
  padding: 10px;
  margin: 10px;
    }
</style>
   </head>
   
<body>
   <br>
   <br>
   <br>
   <br>
    <div class="container">
        <div class="row">
            <div class="col-md-9 col-sm-12"> 
    <!-- ADD Notices -->
    <div class="tab_panel tab_panel_4">
        <h2>You can update the notice and calendar section here</h2>
        <br>
        <h3>Notice Update:</h3>
        <h4>Fill the notices in the form that you want your visitors to see</h4>
        <br>
        <form action="" method="post">
            <p>Notice 1:</p><input type="text" name="notice1" class="text-area">
            <br>
            <p>Notice 2:</p><input type="text" name="notice2" class="text-area">
            <br>
            <p>Notice 3:</p><input type="text" name="notice3" class="text-area">
            <br>
            <p>Notice 4:</p><input type="text" name="notice4" class="text-area">
            <br>
            <br>
            <input type="submit" class="btn btn-danger" value="Reset" name="reset_notice">
            <input type="submit" class="btn btn-success" value="Update" name="update_notice">
        </form>
    </div>
    </div>
        </div>
    </div>
       </body>
</html>