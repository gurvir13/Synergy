<?php  include "../../../includes/db_conn.php"; 
?>

<!DOCTYPE html>
<html>
    <head>
        <title>Synergy</title>
        <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
   
<style>
    body{
        background-image: url(../../images/attn_back.png);
    }     
    
   div.row {
  background-color: rgba(255, 255, 255, 0.8);
  border-radius: 30px;
  padding: 10px;
  margin: 10px;
    }
</style>
    </head>
           <body>
           <br> 
           <br> 
           <br> 
           <br> 
           <div class="container">
        <div class="row">
            <div class="col-md-9 col-sm-12"> 
            <!-- Attendance -->
            <div class="tab_panel tab_panel_3">
                <h2>Enter attendence details.</h2>
                <br>
                <br>
                <form action="" method="post">

                       <p>Select date:</p>
                    <input type="date" name="date">
                    <br>
                    <br>
                    <br>
                    
                   
                    
                    
                    <div class="table-responsive">
                    	<table class="table table-striped">
                    		<thead class="bg-dark">
                    			
                    			<th>Roll No</th>
                    			<th>Subject 1</th>
                    			<th>Subject 2</th>
                    			<th>Subject 3</th>
                    			<th>Subject 4</th>
                    		</thead>
							<tbody>
							
							 <?php 
						global $rollno ;
						 $rollno = array("");
						$query = "SELECT roll_no FROM `signup`";
						$student_query = mysqli_query($conn,$query);
					
						if(!$student_query){
							die("somthing went wrong ".mysqli_error($conn));
						}
								$c = 0;
						while($row = mysqli_fetch_array($student_query)){
							
							if($c == 0){
								array_shift($rollno);
							}
							
						$roll_no = array($row['roll_no']);
						 $rollno = array_merge($rollno,$roll_no);
						
					
					?>
                    
								<tr>
								
									<td><?php echo  $rollno[$c];?></td>
									<td>
									<select name="sub1[]" id="sub1">
									    <option value="present">present</option>
									    <option value="absent">absent</option>
									</select> 		
									</td>
									<td>
										<select name="sub2[]" id="sub2">
										   <option value="present">present</option>
									    <option value="absent">absent</option>
									  </select>			
									</td>
									<td>
										<select name="sub3[]" id="sub3">
									    	<option value="present">present</option>
									    <option value="absent">absent</option>
										  
										</select>			
									</td>
                    			<td>
                    				<select name="sub4[]" id="sub4">
                    					<option value="present">present</option>
									    <option value="absent">absent</option>
									  
                              		 </select>			
                    			</td>
                    		</tr>
                    		 <?php 
								 $c++;
						}
								?>
                    			
                    	</tbody>
                    	</table>
                    </div>
                    
                    
        <?php 
if(isset($_POST['submit'])){
	 
	
	$date = $_POST['date'];
	
	$sub1 = $_POST['sub1'];
	$sub2 = $_POST['sub2'];
	$sub3 = $_POST['sub3'];
	$sub4 = $_POST['sub4'];
	
	
	$date = $_POST['date'];
	
	for($i=0;$i<$c;$i++){
		
		$add_attendance = "INSERT INTO attendance (roll_no, date, sub1, sub2, sub3, sub4) VALUES('$rollno[$i]', '$date', '$sub1[$i]','$sub2[$i]' ,'$sub3[$i]' ,'$sub4[$i]')";
		$result = mysqli_query($conn,$add_attendance);
                        
           if(!$result){
			   die("something went wrong ".mysqli_error());
		   }
	}
}            
                    
                    
                    
      ?>              
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    <input type="submit" class="btn btn-success" name="submit" value="submit">
                </form>
                
            </div>
               </div>
               </div>
               </div>

    </body>
</html>