<?php


if(isset($_POST['faq_submit'])){
    $que = $_POST['que'];
    $ans = $_POST['ans'];
    
    
    $query = "INSERT INTO faq(que, ans) VALUES ('$que', '$ans')";
    
    $faq_query = mysqli_query($conn, $query);
    
    if($faq_query){
        echo ('<div class="container">
	<div class="row">
	<div class="alert alert-success alert-dismissible fade show">
            <button class="close" data-dismiss="alert" type="button">
                <span>&times;</span>
            </button>
            <h4>Signed in successfully!!</h4>
			</div></div></div>');
    }
    else{
        echo ('<div class="alert alert-danger alert-dismissible fade show">
            <button class="close" data-dismiss="alert" type="button">
                <span>&times;</span>
            </button>
            <h1>Signed Not successfully!!</h1>
			</div>');
	die("Error have oucceered submitting the query ".mysqli_error($conn));
	 
    }
}
?>
<?php
if(isset($_POST['delete'])){
    $dque = $_POST['dno'];
    $dquery = "delete from faq where que = '$dque'";
    $delete_query = mysqli_query($conn, $dquery);
    if(!$delete_query){
        die(mysqli_error($conn));
    }
}
?>