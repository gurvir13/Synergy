
<?php session_start();  





include("function.php");
include("db_conn.php");

if(isset($_POST['login'])){

 $roll_no = $_POST['roll_no'];
 $password = $_POST['password'];
    

    

$roll_no = string_check($roll_no);
$password = string_check($password);



$query = "SELECT * FROM `signup` where roll_no = '" . $roll_no . "'; ";
	
$select_students_query = mysqli_query($conn,$query);


query_check($select_students_query);

        while($row = mysqli_fetch_array($select_students_query)){
			$stud_roll_no=$row['roll_no'];
			$stud_password = $row['password'];
            $stud_firstname = $row['fname'];
            $stud_lastname = $row['lname'];
            $dob = $row['dob'];
            $stud_address = $row['address'];
            $stud_phone = $row['stud_phone'];
            $par_phone = $row['par_phone'];
            $course = $row['course'];
			$present_school = $row['present_school'];
			$par_email = $row['par_email'];
           
           
    }
    
  
	
	 $stud_password;
	
    $password = crypt($password,$stud_password);
	$password = $password;

	
	
	if($password !== $stud_password && $roll_no !== $stud_roll_no){
        header("Location: slogin.php");
        echo "<h1>Invalid username or password</h1>";
    }
    

	
	else	if($password == $stud_password){
            
            $_SESSION['roll_no'] = $roll_no;
			$_SESSION['fname'] = $stud_firstname;
            $_SESSION['lname'] = $stud_lastname;
            $_SESSION['dob'] = $dob;
            $_SESSION['address'] = $stud_address;
            $_SESSION['stud_phone'] = $stud_phone;
            $_SESSION['par_phone'] = $par_phone;
            $_SESSION['course'] = $course;
            $_SESSION['present_school'] = $present_school; 
            $_SESSION['par_email'] = $par_email; 
            
            
 
           
            
            
			/*echo"<br> password";*/
			header("Location: ../students/profile.php");
		}
    
		else{
			echo"<br>invalid username or password";
        }
    
}

	
	

?>

