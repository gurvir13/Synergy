<?php 


$conn = mysqli_connect("localhost","root","","synergy");

if(mysqli_connect_error()){
	die(mysqli_error($conn));
}
if(isset($_POST['quest_gen'])){
	
    $subject = $_POST['sub'];
	$quest = mysqli_real_escape_string($conn,$_POST['quest']);
	$opt1 = mysqli_real_escape_string($conn,$_POST['opt1']);
	$opt2 = mysqli_real_escape_string($conn,$_POST['opt2']);
	$opt3 = mysqli_real_escape_string($conn,$_POST['opt3']);
	$opt4 = mysqli_real_escape_string($conn,$_POST['opt4']);
    $correct_ans = mysqli_real_escape_string($conn,$_POST['cor_ans']);
    $chapter = mysqli_real_escape_string($conn,$_POST['chap']);
	if(empty($correct_ans)){
		$correct_ans = "";
	}elseif($correct_ans === "1"){
		$correct_ans = $opt1;
	}
	elseif($correct_ans === "2"){
		$correct_ans = $opt2;
	}elseif($correct_ans === "3"){
		$correct_ans = $opt3;
	}elseif($correct_ans === "4"){
        $correct_ans = $opt4;
    }
    else{
		
	}
    
     $errors= array();
      echo $file_name = $_FILES['img']['name'];
      echo $file_size = $_FILES['img']['size'];
      echo $file_tmp = $_FILES['img']['tmp_name'];
      echo $file_type= $_FILES['img']['type'];
      echo $file_ext = strtolower(end(explode('.', $_FILES['img']['name'])));
      
      $expensions= array("jpeg","jpg","png");
      
      if(in_array($file_ext,$expensions) === false){
         $errors[]="extension not allowed, please choose a JPEG or PNG file.";
      }
      
      if($file_size > 2097152){
         $errors[]='File size must be excately 2 MB';
      }
      
      if(empty($errors)==true){
         move_uploaded_file($file_tmp,"images/".$file_name);
         echo "Success";
      }else{
         print_r($errors);
      }

$query = "INSERT INTO $subject (`quest`, `correct_ans`, `opt_1`, `opt_2`, `opt_3`, `opt_4`,`image`, `chap`) VALUES ('$quest', '$correct_ans', '$opt1', '$opt2', '$opt3', '$opt4','$file_name', '$chapter')";
$result = mysqli_query($conn,$query);
if(!$result){
	die(mysqli_error($conn));
}

}


?>

<div class="container">

	 <form action = "" method = "POST" enctype = "multipart/form-data">
	    <p>Subject</p>
	    <select name="sub" id="sub">
            <option value="">Select</option>
	        <option value="phy11">11th Physics</option>
	        <option value="chem11">11th Chemistry</option>
	        <option value="maths11">11th Maths</option>
	        <option value="bio11">11th Biology</option>
	        <option value="phy12">12th Physics</option>
	        <option value="chem12">12th Chemistry</option>
	        <option value="maths12">12th Maths</option>
	        <option value="bio12">12th Biology</option>
	    </select><br>
		<p>QUESTION</p>
		<input type="text" name="quest" id="quest"><br><br>
		<p>opt1</p>
		<input type="radio" name="cor_ans" id="cor_ans" value="1"><input type="text" name="opt1" id="opt1"><br><br>
		<p>opt2</p>
		<input type="radio" name="cor_ans" id="cor_ans" value="2"><input type="text" name="opt2" id="opt2"><br><br>
		<p>opt3</p>
		<input type="radio" name="cor_ans" id="cor_ans" value="3"><input type="text" name="opt3" id="opt3"><br><br>
		<p>opt4</p>
		<input type="radio" name="cor_ans" id="cor_ans" value="4"><input type="text" name="opt4" id="opt4"><br><br>
		<p>img (if required)</p>
		<input type="file" name="img"><br><br>
		<p>Chapter no</p>
		<input type="text" name="chap" placeholder="eg. 1, 2 etc">
		
		<br><br>
		<button class="btn btn-success" type="submit" name="quest_gen">Submit</button>
		
		
	</form>
</div>