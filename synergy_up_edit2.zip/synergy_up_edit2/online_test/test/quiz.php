<?php
	ob_start();
session_start();
$conn = mysqli_connect("127.0.0.1","root","","synergy");

if(mysqli_connect_error()){
	die(mysqli_error($conn));
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>quiz</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
</head>
<body>


<div class="container-fluid">
	<div class="row">
<form action="ans1.php" method="post">
<p id="demo"></p>
<?php 
	if(isset($_SESSION['quest'])){
		
		$id = $_SESSION['quest'];
	 	$id = implode(",",$id);
		
		
		$query = "select * from quest where quest_id in ($id)";
		
	}else{
		$query = "select * from quest";
	}


	$result = mysqli_query($conn,$query);
	$count = mysqli_num_rows($result);
	if(!$result){
		die(mysqli_error($conn));
		
	}
	$array=array("");
	$quest_array = array("");
	$cor_ans_array = array("");
	while($row = mysqli_fetch_array($result)){
		
		$quest_id = $row['quest_id'];
		$quest = $row['quest'];
	    $opt_1 = $row['opt_1'];
		$opt_2 = $row['opt_2'];
		$opt_3 = $row['opt_3'];
		$correct_ans = $row['correct_ans'];
		
		$opt_1 = sprintf('<input type="radio" name="%s" id="%s" value="%s">%s<br>',$quest_id,$quest_id,$opt_1,$opt_1);
		$opt_2 = sprintf('<input type="radio" name="%s" id="%s" value="%s">%s<br>',$quest_id,$quest_id,$opt_2,$opt_2);
		$opt_3 = sprintf('<input type="radio" name="%s" id="%s" value="%s">%s<br>',$quest_id,$quest_id,$opt_3,$opt_3);
		
		$range = array($quest .'<br>' . $opt_1."\t".$opt_2."\t".$opt_3."\n");
		$array = array_merge($range,$array);
		
		$quest_id = array($quest_id);
		$quest_array = array_merge($quest_id,$quest_array);
		
		$correct_ans = array($correct_ans);
		$cor_ans_array = array_merge($correct_ans,$cor_ans_array);
		
	}
	

	$re =array_pop($array);
	/*$re =array_pop($quest_array);
	$_SESSION['quest'] = $quest_array;*/
	$_SESSION['corr_ans'] = $cor_ans_array;


	$rand_keys = shuffle($array);
	


	for($i = 0; $i<$count;$i++){
		
		$j = $i + 1; 
	 		echo $j." .&nbsp;&nbsp;". $array[$i] . "<br>";
		
		
}
	
	
	

	
	
	?>
	<input type="submit" value="SUBMIT" formmethod="post" id="myBtn" name="ans">
	
	
</form>
</div>
</div>

 <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
	<script>

	
	//5 min
/* time =  300000;*/
 time =  10000;
// Update the count down every 1 second
var x = setInterval(function() {
	
	   time = time - 1000;
	
	 var minutes = Math.floor((time % (1000 * 60 * 60)) / (1000 * 60));
    var seconds = Math.floor((time % (1000 * 60)) / 1000);
	
    
    // Output the result in an element with id="demo"
   document.getElementById("demo").innerHTML =   minutes + "m " + seconds + "s ";
  
    // If the count down is over, write some text 
   /* if (time = 0) {
        
		
		
         
    }*/
	if(time < -500){
		document.getElementById("demo").innerHTML = "time up";
		clearInterval(x);
		document.getElementById("myBtn").click();
		
	}
}, 1000);
	
	
</script>	
	
	
</body>
</html>