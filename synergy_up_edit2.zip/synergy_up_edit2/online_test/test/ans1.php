<?php 
ob_start();
session_start();

$conn = mysqli_connect("127.0.0.1","root","","synergy");

if(mysqli_connect_error()){
	die(mysqli_error($conn));
}

?>
<?php 
		if(isset($_POST['ans'])){
			$quest_id = $_SESSION['quest'];
			
			 /*if(isset($_POST['1'])){
				echo  $_POST['1'];
			 }else{
				 echo "not working";
			 }*/
			
			$ans = array("");
			foreach($quest_id as $key => $values ){
				$answer = array($_POST[$values]);
				$ans = array_merge($answer,$ans);
				
			}
	array_shift($ans);
	print_r($ans);
		}
	?>




<!--
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>

<p> <br><table  width = "75%"  border="0" align ="center">
		<tr>
			<td>&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
			<td><table border="0" align ="default">
				<tr>
					<td></td>
					<td></td>
					<td></td>
				</tr>
				<tr>
					<td><font face = "georgia" size ="4" color= "blue"><u><b>QUESTION</b></u></font></td>
					<td width = "230"><font face = "georgia" size ="4" color= "blue"><b><u>Your answers are: </u></b></font></td>
					<td width = "230"><font face = "georgia" size ="4" color= "blue"><b><u>Correct answers : </u></b></font></td>
					<td><font face = "georgia" size ="4" color= "blue"><b><u>Results</u></b></font></td>
				</tr>
				<tr>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
				</tr>
				<tr>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
				</tr>



<?php
$wrong = '<img src="images/wrong.jpg"/>';
$check = '<img src="images/check.jpg"/>';


if($_SESSION['quest']){
	$quest_id = $_SESSION['quest'];
	echo $id = implode(",",$quest_id);
	
	echo "<br>";
	$query = "select * from quest where quest_id in ($id)";
	$result = mysqli_query($conn,$query);
	
	$result = mysqli_query($conn,$query);
	echo $count = mysqli_num_rows($result);
	
	if(!$result){
		die(mysqli_error($conn));
		
	}
	
	while($row = mysqli_fetch_array($result)){
		$quest = substr($row['quest'],0,20) . "..";
		
		 $cor_ans = $row['correct_ans']; 

?>

	
				<tr>
					<td><?php echo $quest; ?></td>
					<td><?php echo "ans;" ?></td>
					<td><?php echo $cor_ans; ?></td>
					<td><?php echo $check; ?></td>
				</tr>
			
	
<?php 
	
	}
	
	
}else{
	echo "dck";
}	
?>
	</table>
			</td>
		</tr>
	</table>
	
</body>
</html>-->