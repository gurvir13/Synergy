<?php 
session_start();

$quest_id  = $_SESSION['quest'];

 $corr_ans = $_SESSION['corr_ans'];
$correct_ans = $corr_ans;
array_pop($corr_ans);
/*print_r($corr_ans);*/
$count = count($corr_ans);

echo"<br>";

$wrong = '<img src="images/wrong.jpg"/>';
$check = '<img src="images/check.jpg"/>';

if(!empty($_POST[$quest_id[0]])){
$ans = array($_POST[$quest_id[0]]);
}else{
	$ans = array("");
	
}


for($i=1; $i < $count;$i++){
	if(!empty($_POST[$quest_id[$i]])){
	$arr = array($_POST[$quest_id[$i]]);
	$ans = array_merge($ans,$arr);
	}else{
		$arr = $_POST[$quest_id[$i]] = array("not answered");
		$ans = array_merge($ans,$arr);
		
	}
	
}
//print_r($ans);
$query_ans = array("'");
for($i=0;$i<count($corr_ans);$i++){

	$corr_ans[$i] = $query_ans[0] . $corr_ans[$i] . $query_ans[0];
}

$corr_ans = implode(",",$corr_ans);
/*echo $corr_ans[0] = "' " + $corr_ans[0];*/



/*echo "<br>".$corr_ans;*/
$conn = mysqli_connect("localhost","root","","synergy");

if(mysqli_connect_error()){
	die(mysqli_error($conn));
}
$score= 0;
if(isset($_POST['ans'])){	

    $query = "select * from `chem12` where correct_ans in (" .$corr_ans.")";
	$result = mysqli_query($conn,$query);
	$count = mysqli_num_rows($result);
	
	if(!$result){
		die(mysqli_error($conn));
		
	}
	print('<p> <br><table  width = "75%"  border="0" align ="default">
		<tr>
			<td>&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
			<td><table border="0" align ="default">
				<tr>
					<td></td>
					<td></td>
					<td></td>
				</tr>
				<tr>
					<td><font face = "georgia" size ="4" color= "blue"><u><b>QUESTION</b></u></font></td>
					<td width = "230"><font face = "georgia" size ="4" color= "blue"><b><u>Your answers are: </u></b></font></td>
					<td width = "230"><font face = "georgia" size ="4" color= "blue"><b><u>Correct answers : </u></b></font></td>
					<td><font face = "georgia" size ="4" color= "blue"><b><u>Results</u></b></font></td>
				</tr>
				<tr>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
				</tr>
				<tr>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
				</tr>');

	$corr_ans =array("");
	$que = array("");
	$count = mysqli_num_rows($result);
	if($count > 0){
	while($row = mysqli_fetch_array($result)) {
		
		$quest = array(substr($row['quest'],0,30) . "..");
		
		$que = array_merge($quest,$que);
		
	   $cor_ans = array($row['correct_ans']); 
		$corr_ans = array_merge($corr_ans,$cor_ans);
			
			
		}
	array_shift($corr_ans);
	array_pop($que);
//	print_r($que);
	
	$corr_ans = array_reverse($corr_ans);
	
	for($i=0;$i<count($que);$i++ ){
		if(!empty($ans[$i]) ){
		
		
		if($correct_ans[$i] == $ans[$i]){
		
				echo"	<tr>
					<td>$que[$i]</td>
					<td>$ans[$i]</td>
					<td>$correct_ans[$i]</td>
					<td>$check</td>
				  </tr>";
			$score = $score +1;
		}
		else {
			echo"	<tr>
					<td>$que[$i]</td>
					<td>$ans[$i]</td>
					<td>$correct_ans[$i]</td>
					<td>$wrong</td>
				  </tr>";
		
	}
		}else{
			echo"	<tr>
					<td>$que[$i]</td>
					<td>not answered</td>
					<td>$correct_ans[$i]</td>
					<td>$wrong</td>
				  </tr>";
		}
		
	}
	
	
	
	print('<tr><td>&nbsp;&nbsp;&nbsp;</td></tr>
				<tr><td>&nbsp;&nbsp;&nbsp;</td></tr>
				<tr><td></td></tr>
				<tr><td></td></tr>
				<tr><td></td></tr>
				<tr  ><td  colspan ="3" align ="center" ><font face = "georgia" size ="4" color= "blue"><b>Your score is:');
	echo $score;
	print('  </b></font></td></tr>
				<tr><td></td></tr>
				<tr><td></td></tr>
				<tr><td></td></tr>
			</table>
		</td>
	</tr>
</table>');
	
	}
}


?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>ANSWER</title>
</head>
<body>
	
</body>
</html>