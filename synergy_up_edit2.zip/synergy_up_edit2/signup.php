<!DOCTYPE html>
<html lang="en">
<head>
    
    <!-- title of the site -->
  <title>St. Xavier's</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  	

	<!--<link rel="stylesheet" href="css/bootstrap.min.css">-->
	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="css/font-awesome.min.css">
	
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" integrity="sha384-WskhaSGFgHYWDcbwN70/dfYBj47jz9qbsMId/iRN3ewGhXQFZCSftd1LZCfmhktB" crossorigin="anonymous">
	
</head>
<body>
<?php
include("includes/function.php");
$db['db_host']="localhost";
$db['db_user']="root";
$db['db_pass']="mysqlpass";
$db['db_name']="synergy";
 
foreach($db as $key => $value){
	define(strtoupper($key),$value);
	
}

$conn = mysqli_connect(DB_HOST,DB_USER,DB_PASS,DB_NAME);

if(mysqli_connect_error()){
	die("something went wrong ".mysqli_error($conn));
}



if(isset($_POST['sign_up'])){

$fname = string_check($_POST['fname']);
$lname = string_check($_POST['lname']);
$dob = string_check($_POST['dob']);
$father_name = string_check($_POST['father_name']);
$mother_name = string_check($_POST['mother_name']);
$father_occ = string_check($_POST['father_occ']);
$school = string_check($_POST['school']);
$school_board = string_check($_POST['school_board']);
$present_school = string_check($_POST['present_school']);
$present_school_board = string_check($_POST['present_school_board']);
$stud_phone = string_check($_POST['stud_phone']);
$par_phone = string_check($_POST['par_phone']);
$stud_email = string_check($_POST['stud_email']);
$par_email = string_check($_POST['par_email']);
$address = string_check($_POST['address']);

	$errors= array();
       $file_name = $_FILES['image']['name'];
	
       $file_size =$_FILES['image']['size'];
      
		$file_tmp =$_FILES['image']['tmp_name'];
	   	  
       $file_type = $_FILES['image']['type'];
	   
	   $file_error  = $_FILES['image']['error'];
	   

      $file_ext=strtolower(end(explode('.',$_FILES['image']['name'])));
      
      $expensions= array("jpeg","jpg","png");
	
	if($file_error == 0){
      
      if(in_array($file_ext,$expensions) === false){
         $errors[]="extension not allowed, please choose a JPEG or PNG file.";
      }
      
      if($file_size > 2097152){
         $errors[]='File size must be excately 2 MB';
      }
      
      if(empty($errors) == true){
		  $file_name = $stud_email . "." .$file_ext;
         move_uploaded_file($file_tmp,"images/student/".$file_name);
  
      }else{
         print_r($errors);
      }
	}else{
		die("try to upload image later ".mysqli_error($conn));
	}

	

$query = "INSERT INTO `synergy`.`signup` (`fname`, `lname`, `dob`, `father_name`, `mother_name`, `father_occ`, `school`, `school_board`, `present_school`, `present_school_board`, `stud_phone`, `par_phone`, `stud_email`, `par_email`, `address`) VALUES ('$fname', '$lname', '$dob','$father_name', '$mother_name', '$father_occ','$school', '$school_board', '$present_school', '$present_school_board', '$stud_phone', '$par_phone', '$stud_email', '$par_email', '$address');";
	
	
$create_student_query = mysqli_query($conn,$query);
if($create_student_query){

	echo ('<div class="container">
	<div class="row">
	<div class="alert alert-success alert-dismissible fade show">
            <button class="close" data-dismiss="alert" type="button">
                <span>&times;</span>
            </button>
            <h4>Signed in successfully!!</h4>
			</div></div></div>');
	/*echo "submitted";*/
}
else{
	echo ('<div class="alert alert-danger alert-dismissible fade show">
            <button class="close" data-dismiss="alert" type="button">
                <span>&times;</span>
            </button>
            <h1>Signed in successfully!!</h1>
			</div>');
	die("Error have oucceered submitting the query ".mysqli_error($conn));
	
}
}
?>

      <div class="container">
      	<div class="row">
<section class="text-center">
    <h1>Sign Up</h1>
    
    <p>Sign up to stay up-to-date </p>
    
    
    
    
    <form action="" autocomplete="off" method="post" role="form" enctype="multipart/form-data" >
		<div class="form-group ">
			<label for="firstname">Firstname</label>
			<input type="text" name="fname" class="form-control" required>
		</div>
	   
		<div class="form-group">
			<label for="lastname">Lastname</label>
			<input type="text" name="lname" class="form-control" required>
		</div>
   
	   <div class="form-group">
			<label for="dob">Date of Birth</label>
			<input type="date" name="dob" class="form-control" required>
		</div>
	   
	   <div class="form-group">
			<label for="pic">Upload a Photo </label>
			<input type="file" name="image" class="form-control"  required>
		</div>

	   <div class="form-group">
			<label for="father_name">Father's name</label>
			<input type="text" name="father_name" class="form-control" required>
		</div>
		
		<div class="form-group">
			<label for="mother_name">Mother's name</label>
			<input type="text" name="mother_name" class="form-control" required>
		</div>
		
		<div class="form-group">
			<label for="father_occ">Father's Occupation</label>
			<input type="text" name="father_occ" class="form-control" required>
		</div>
				
		<div class="form-group">
			<label for="address">Residential Address</label>
			<textarea type="text" name="address" class="form-control" rows="3" required ></textarea>
		</div>
				
				
		<div class="form-group">
			<label for="stud_phone">Student's Phone No</label>
			<input type="text" name="stud_phone" class="form-control" required>
		</div>
		
		<div class="form-group">
			<label for="par_phone">Parent's Phone No</label>
			<input type="text" name="par_phone" class="form-control" required>
		</div>
					
		<div class="form-group">
			<label for="stud_email">Student's Email</label>
			<input type="email" name="stud_email" class="form-control" required>
		</div>
		
		<div class="form-group">
			<label for="par_email">Parent's Email</label>
			<input type="email" name="par_email" class="form-control" required>
		</div>
		
		
		<div class="form-group">
			<label for="school">School <span class="text-muted"> (Apperad in 10th standard)</span></label>
			<textarea type="text" name="school" class="form-control" rows="3" required></textarea>
		</div>
		
		<div class="form-group">
			<label for="school">Board
				<select name="school_board" id="school_board" class="form-control " >
					<option value="ssc">SSC</option>
					<option value="cbsc">CBSC</option>
					<option value="icse">ICSE</option>
					<option value="igcse">IGCSE</option>
					<option value="other">other</option>
				</select>
			</label>
		</div>
		
		<div class="form-group">
			<label for="present_school">Present School <span class="text-muted"> (Apperad in 12th standard if any)</span></label>
			<textarea type="text" name="present_school" class="form-control" rows="3" id="present_school" ></textarea>
		</div>


			<div class="form-group">
			<label for="present_school_board">Board
				<select name="present_school_board" id="present_school_board" class="form-control " >
					<option value="hsc">HSC</option>
					<option value="cbse">CBSE</option>
					<option value="isc">ISC</option>
					<option value="other">other</option>
				</select>
			</label>
		</div>
		
		

		
		

		<!--<div class="form-group">
			<label for="user_password">Password</label>
			<input type="password" id="password" name="password" class="form-control" required>
		</div>
		
		<div class="form-group">
			<label for="user_cnf_password">Conform Password</label>
			<input type="password" id="cnf_password" name="cnf_password" class="form-control" required>
			
		</div>-->
		<!--
			<div class="hide invisible">
            	 Password length should be greater than 8
			</div>-->
   
   		<div class="form-group">
			<button type="submit"  name="sign_up"  class="btn btn-primary disabled">Submit</button>
		</div>
    </form>
    
    
 </section>
   </div>
      </div>     
    
    
    
    <!--
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>-->


	
	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js" integrity="sha384-smHYKdLADwkXOn1EmN1qk/HfnUcbVRZyYmZ4qpPea6sjB/pTJ0euyQp0Mk8ck+5T" crossorigin="anonymous"></script>
	<!--
	
	<script>
			$(document).ready(function(){
				
			
	
	$('#password').keyup(function() {
		var pswd = $('#password').val();
		
		
		//validate th  e length
		if ( pswd.length < 7 ) {
			$('#password').addClass('is-invalid');
			$('.hide').removeClass('invisible');
		} 
		if(pswd.length > 7){
			$('#password').removeClass('is-invalid').addClass('is-valid');
			$('.hide').addClass('invisible');
		}
		
		
		
	//confirm passord
	$('#cnf_password').keyup(function(){
		
		var cnf_pswd = $('#cnf_password').val();
		
	
		if(pswd !== cnf_pswd){
			$('#cnf_password').addClass('is-invalid');
			
		}
		 if(pswd == cnf_pswd){
			$('#cnf_password').removeClass('is-invalid').addClass('is-valid');
			$('button').removeClass('disabled');
		}
	});	
		
	
	});
	
});
	
	
	
	
	</script>-->

</body>
</html>