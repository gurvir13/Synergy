<!DOCTYPE html>
<html>
    <head>
       <title>Synergy</title>
        <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <style>
            body{
                background-image: url("images/back.png");
            }
               div.row {
  background-color: rgba(255, 255, 255, 0.8);
  border-radius: 30px;
  padding: 10px;
  margin: 10px;
    }
            #btn{
                display: flex; justify-content: center; 
            }
        </style>
    </head>
    <body>
        <br>
         <div class="container">
        <div class="row">
            <div class="col-md-9 col-sm-12">
               <form action="../../../online_test/chem11.php" method="post">
                <h1>Synergy online practice test.</h1>
                <h4>Select the chapter to practice</h4>
                <br>
                <br>
                <table class="table table-bordered">
                    <thead>
                       <tr>
                        <th>sr.no.</th>
                        <th>chapter</th>
                        <th>select</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>1</td>
                            <td>Lines</td>
                            <td><input type="radio" name="chap" value="1"></td>
                        </tr>
                        <tr>
                            <td>2</td>
                            <td>Numbers</td>
                            <td><input type="radio" name="chap" value="2"></td>
                        </tr>
                    </tbody>
                </table>
                <br>
                <br>
                <input class="btn btn-success" type="submit" name="submit" id="btn" value="Practice!">
                <br>
                </form>
            </div>
        </div>
    </div>
       
    </body>
</html>