<!DOCTYPE html>
<html lang="en">
<head>
  
  <title>Synergy</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    
<style> 
body {
    background-image: url("images/calendar.png");
    background-color: white;
}
.footer {
   position: fixed;
   left: 0;
   bottom: 0;
   width: 100%;
   background-color: red;
   color: white;
   text-align: center;
}
</style>    
</head>
<body>
    
   <!-- navbar-->
<nav class="navbar navbar-inverse navbar-fixed-top">
  <div class="container-fluid">
    <ul class="nav navbar-nav">
      <li><a href="">Synergy</a></li>
      <li><a href="display_marks.php">check marks</a></li>
      <li><a href="timetable.php">Timetable</a></li>
      <li class="active"><a href="calendar.php">Academic Calendar</a></li>
    </ul>
    
    <ul class="nav navbar-nav navbar-right">
      <li><a href="../login/logout.php"><span class="glyphicon glyphicon-log-in"></span> Logout</a></li>
    </ul>
  </div>
    </nav>


<br>
<br>
<br>
<br>
<br>

<div class="container">
  <div id="myCarousel" class="carousel slide" data-ride="carousel">
    <!-- Indicators -->
    <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
      <li data-target="#myCarousel" data-slide-to="2"></li>
      <li data-target="#myCarousel" data-slide-to="3"></li>
      <li data-target="#myCarousel" data-slide-to="4"></li>
      <li data-target="#myCarousel" data-slide-to="5"></li>
      <li data-target="#myCarousel" data-slide-to="6"></li>
      <li data-target="#myCarousel" data-slide-to="7"></li>
      <li data-target="#myCarousel" data-slide-to="8"></li>
      <li data-target="#myCarousel" data-slide-to="9"></li>
      <li data-target="#myCarousel" data-slide-to="10"></li>
      <li data-target="#myCarousel" data-slide-to="11"></li>
    </ol>

    <!-- Wrapper for slides -->
    <div class="carousel-inner">
      <div class="item active">
          <!-- January-->
          <div class="jumbotron" style="background-color: skyblue"><h1 style="text-align: center">January 2018</h1></div>
          <div class="row" style="background-color: white">
              <div class="col-sm-1">
                  <p>  </p>
              </div>
              <div class="col-sm-10">
                    <table class="table table-bordered">
    <thead>
      <tr>
        <th style="text-align: center; text-decoration-style: solid">Date</th>
        <th style="text-align: center">Event</th>
      </tr>
    </thead>
      <?php include "includes/calendar/jan_fun.php"; ?>
      
      
  </table>
                  <br>
                  <br>
              </div>
          </div>
      </div>

      <div class="item">
          <!-- Febuary -->
          <div class="jumbotron" style="background-color: lightpink"><h1 style="text-align: center">Febuary 2018</h1></div>
          <div class="row" style="background-color: white">
              <div class="col-sm-1">
                  <p>  </p>
              </div>
              <div class="col-sm-10">
                    <table class="table table-bordered">
    <thead>
      <tr>
        <th style="text-align: center; text-decoration-style: solid">Date</th>
        <th style="text-align: center">Event</th>
      </tr>
    </thead>
    <?php include "includes/calendar/feb_fun.php"; ?>
  </table>
                  <br>
                  <br>
                  
              </div>
          </div>
          
      </div>
        
        
         <div class="item">
          <!-- March -->
          <div class="jumbotron" style="background-color: greenyellow"><h1 style="text-align: center">March 2018</h1></div>
          <div class="row" style="background-color: white">
              <div class="col-sm-1">
                  <p>  </p>
              </div>
              <div class="col-sm-10">
                    <table class="table table-bordered">
    <thead>
      <tr>
        <th style="text-align: center; text-decoration-style: solid">Date</th>
        <th style="text-align: center">Event</th>
      </tr>
    </thead>
    <?php include "includes/claendar/mar_fun.php"; ?>
  </table>
                  
                  <br>
                  <br>
              </div>
          </div>
          
      </div>
        
        
     <div class="item">
          <!-- April-->
          <div class="jumbotron" style="background-color: orange"><h1 style="text-align: center">April 2018</h1></div>
          <div class="row" style="background-color: white">
              <div class="col-sm-1">
                  <p>  </p>
              </div>
              <div class="col-sm-10">
                    <table class="table table-bordered">
    <thead>
      <tr>
        <th style="text-align: center; text-decoration-style: solid">Date</th>
        <th style="text-align: center">Event</th>
      </tr>
    </thead>
        <?php include "includes/calendar/apr_fun.php"; ?>
  </table>
                  
                  <br>
                  <br>
              </div>
          </div>
          
      </div>
    
      
        
        <div class="item">
          <!-- May-->
          <div class="jumbotron" style="background-color: mediumpurple"><h1 style="text-align: center">May 2018</h1></div>
          <div class="row" style="background-color: white">
              <div class="col-sm-1">
                  <p>  </p>
              </div>
              <div class="col-sm-10">
                    <table class="table table-bordered">
    <thead>
      <tr>
        <th style="text-align: center; text-decoration-style: solid">Date</th>
        <th style="text-align: center">Event</th>
      </tr>
    </thead>
        <?php include "includes/calendar/may_fun.php"; ?>
  </table>
                  
                  <br>
                  <br>
              </div>
          </div>
          
      </div>
        
        
<div class="item">
          <!-- June -->
          <div class="jumbotron" style="background-color: paleturquoise"><h1 style="text-align: center">June 2018</h1></div>
          <div class="row" style="background-color: white">
              <div class="col-sm-1">
                  <p>  </p>
              </div>
              <div class="col-sm-10">
                    <table class="table table-bordered">
    <thead>
      <tr>
        <th style="text-align: center; text-decoration-style: solid">Date</th>
        <th style="text-align: center">Event</th>
      </tr>
    </thead>
        <?php include "includes/calendar/june_fun.php"; ?>
  </table>
                  <br>
                  <br>
              </div>
          </div>
          
      </div>

        
<div class="item">
          <!-- July -->
          <div class="jumbotron" style="background-color: palegreen"><h1 style="text-align: center">July 2018</h1></div>
          <div class="row" style="background-color: white">
              <div class="col-sm-1">
                  <p>  </p>
              </div>
              <div class="col-sm-10">
                    <table class="table table-bordered">
    <thead>
      <tr>
        <th style="text-align: center; text-decoration-style: solid">Date</th>
        <th style="text-align: center">Event</th>
      </tr>
    </thead>
        <?php include "includes/calendar/july_fun.php"; ?>
  </table>
                  <br>
                  <br>
              </div>
          </div>
          
      </div>

        
<div class="item">
          <!-- August -->
          <div class="jumbotron" style="background-color: sandybrown"><h1 style="text-align: center">August 2018</h1></div>
          <div class="row" style="background-color: white">
              <div class="col-sm-1">
                  <p>  </p>
              </div>
              <div class="col-sm-10">
                    <table class="table table-bordered">
    <thead>
      <tr>
        <th style="text-align: center; text-decoration-style: solid">Date</th>
        <th style="text-align: center">Event</th>
      </tr>
    </thead>
    <?php include "includes/calendar/aug_fun.php"; ?>
  </table>
                  <br>
                  <br>
              </div>
          </div>
          
      </div>

        
<div class="item">
          <!-- September -->
          <div class="jumbotron" style="background-color: khaki"><h1 style="text-align: center">September 2018</h1></div>
          <div class="row" style="background-color: white">
              <div class="col-sm-1">
                  <p>  </p>
              </div>
              <div class="col-sm-10">
                    <table class="table table-bordered">
    <thead>
      <tr>
        <th style="text-align: center; text-decoration-style: solid">Date</th>
        <th style="text-align: center">Event</th>
      </tr>
    </thead>
        <?php include "includes/calendar/sept_fun.php"; ?>
  </table>
                  <br>
                  <br>
              </div>
          </div>
          
      </div>

        
<div class="item">
          <!-- October -->
          <div class="jumbotron" style="background-color: springgreen"><h1 style="text-align: center">October 2018</h1></div>
          <div class="row" style="background-color: white">
              <div class="col-sm-1">
                  <p>  </p>
              </div>
              <div class="col-sm-10">
                    <table class="table table-bordered">
    <thead>
      <tr>
        <th style="text-align: center; text-decoration-style: solid">Date</th>
        <th style="text-align: center">Event</th>
      </tr>
    </thead>
        <?php include "includes/calendar/oct_fun.php"; ?>
  </table>
                  <br>
                  <br>
              </div>
          </div>
          
      </div>
        
        
<div class="item">
          <!-- November -->
          <div class="jumbotron" style="background-color: salmon"><h1 style="text-align: center">November 2018</h1></div>
          <div class="row" style="background-color: white">
              <div class="col-sm-1">
                  <p>  </p>
              </div>
              <div class="col-sm-10">
                    <table class="table table-bordered">
    <thead>
      <tr>
        <th style="text-align: center; text-decoration-style: solid">Date</th>
        <th style="text-align: center">Event</th>
      </tr>
    </thead>
        <?php include "includes/calendar/nov_fun.php"; ?>
  </table>
                  <br>
                  <br>
              </div>
          </div>
          
      </div>
        
        
<div class="item">
          <!-- December -->
          <div class="jumbotron" style="background-color: indianred"><h1 style="text-align: center">December 2018</h1></div>
          <div class="row" style="background-color: white">
              <div class="col-sm-1">
                  <p>  </p>
              </div>
              <div class="col-sm-10">
                    <table class="table table-bordered">
    <thead>
      <tr>
        <th style="text-align: center; text-decoration-style: solid">Date</th>
        <th style="text-align: center">Event</th>
      </tr>
    </thead>
        <?php include "includes/calendar/dec_fun.php"; ?>
  </table>
                  <br>
                  <br>
              </div>
          </div>
          
      </div>



    <!-- Left and right controls -->
    <a class="left carousel-control" href="#myCarousel" data-slide="prev">
      <span class="glyphicon glyphicon-chevron-left"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#myCarousel" data-slide="next">
      <span class="glyphicon glyphicon-chevron-right"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>
</div>
    </div>

    
    
    <!-- footer-->
<div class="footer" style="background-color: black">
    <br>
    <p>Created with <span class="glyphicon glyphicon-heart" style="color: red"></span> by <a href="http//www.namanlazarus02.wixsite.com/elit">ELIT</a></p>
    <br>
</div>
</body>
</html>
