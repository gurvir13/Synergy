
<?php session_start();  

$db['db_host']="localhost";
$db['db_user']="root";
$db['db_pass']="";
$db['db_name']="synergy";
 
foreach($db as $key => $value){
	define(strtoupper($key),$value);
	
}


$conn = mysqli_connect(DB_HOST,DB_USER,DB_PASS,DB_NAME);



include("function.php");

if(isset($_POST['login'])){

$username = $_POST['username'];
$password = $_POST['password'];
    
$username = mysqli_real_escape_string($conn, $username);
$password = mysqli_real_escape_string($conn, $password);
    

$username = string_check($username);
$password = string_check($password);



$query = "SELECT * FROM admin where username= '$username'";
	
$select_admin_query = mysqli_query($conn,$query);


if(!$select_admin_query ){
	die("Error ocurred ".mysqli_error($conn));
}

        while($row = mysqli_fetch_array($select_admin_query)){
        $user_name=$row['username'];
            //$username = $row['name'];
        $user_password = $row['user_password'];
            
    }
    
  
    $password = crypt($password,$user_password);
	$password = substr($password,0,50);
	/*echo $password."<br>";*/
	
	
	if($password !== $user_password && $username !== $user_name){
        header("Location:alogin.php");
        echo "Invalid username or password";
    }
    

	
	else	if($password == $user_password && $username == $user_name){
            
            $_SESSION['username'] = $username;
			$_SESSION['fname'] = $user_firstname;
            $_SESSION['lname'] = $user_lastname;
            $_SESSION['dob'] = $user_dob;
            $_SESSION['gender'] = $user_gender;
            $_SESSION['address'] = $user_address;
            $_SESSION['detail'] = $user_detail;
            $_SESSION['email'] = $user_email;
            $_SESSION['phone'] = $user_phone;
            $_SESSION['image'] = $user_image;
            
            
            
           
            
            
			echo"<br> password";
			header("Location:../admin/profile.php");
		}
    
		else{
			echo"<br>invalid password";
        }
    
}

	
	

?>


